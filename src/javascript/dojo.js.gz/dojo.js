/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

/*
	This is a compiled version of Dojo, built for deployment and not for
	development. To get an editable version, please visit:

		http://dojotoolkit.org

	for documentation and information on getting the source.
*/

if(typeof dojo=="undefined"){
var dj_global=this;
var dj_currentContext=this;
function dj_undef(_1,_2){
return (typeof (_2||dj_currentContext)[_1]=="undefined");
}
if(dj_undef("djConfig",this)){
var djConfig={};
}
if(dj_undef("dojo",this)){
var dojo={};
}
dojo.global=function(){
return dj_currentContext;
};
dojo.locale=djConfig.locale;
dojo.version={major:0,minor:0,patch:0,flag:"dev",revision:Number("$Rev: 5297 $".match(/[0-9]+/)[0]),toString:function(){
with(dojo.version){
return major+"."+minor+"."+patch+flag+" ("+revision+")";
}
}};
dojo.evalProp=function(_3,_4,_5){
if((!_4)||(!_3)){
return undefined;
}
if(!dj_undef(_3,_4)){
return _4[_3];
}
return (_5?(_4[_3]={}):undefined);
};
dojo.parseObjPath=function(_6,_7,_8){
var _9=(_7||dojo.global());
var _a=_6.split(".");
var _b=_a.pop();
for(var i=0,l=_a.length;i<l&&_9;i++){
_9=dojo.evalProp(_a[i],_9,_8);
}
return {obj:_9,prop:_b};
};
dojo.evalObjPath=function(_d,_e){
if(typeof _d!="string"){
return dojo.global();
}
if(_d.indexOf(".")==-1){
return dojo.evalProp(_d,dojo.global(),_e);
}
var _f=dojo.parseObjPath(_d,dojo.global(),_e);
if(_f){
return dojo.evalProp(_f.prop,_f.obj,_e);
}
return null;
};
dojo.errorToString=function(_10){
if(!dj_undef("message",_10)){
return _10.message;
}else{
if(!dj_undef("description",_10)){
return _10.description;
}else{
return _10;
}
}
};
dojo.raise=function(_11,_12){
if(_12){
_11=_11+": "+dojo.errorToString(_12);
}
try{
dojo.hostenv.println("FATAL: "+_11);
}
catch(e){
}
throw Error(_11);
};
dojo.debug=function(){
};
dojo.debugShallow=function(obj){
};
dojo.profile={start:function(){
},end:function(){
},stop:function(){
},dump:function(){
}};
function dj_eval(_14){
return dj_global.eval?dj_global.eval(_14):eval(_14);
}
dojo.unimplemented=function(_15,_16){
var _17="'"+_15+"' not implemented";
if(_16!=null){
_17+=" "+_16;
}
dojo.raise(_17);
};
dojo.deprecated=function(_18,_19,_1a){
var _1b="DEPRECATED: "+_18;
if(_19){
_1b+=" "+_19;
}
if(_1a){
_1b+=" -- will be removed in version: "+_1a;
}
dojo.debug(_1b);
};
dojo.render=(function(){
function vscaffold(_1c,_1d){
var tmp={capable:false,support:{builtin:false,plugin:false},prefixes:_1c};
for(var i=0;i<_1d.length;i++){
tmp[_1d[i]]=false;
}
return tmp;
}
return {name:"",ver:dojo.version,os:{win:false,linux:false,osx:false},html:vscaffold(["html"],["ie","opera","khtml","safari","moz"]),svg:vscaffold(["svg"],["corel","adobe","batik"]),vml:vscaffold(["vml"],["ie"]),swf:vscaffold(["Swf","Flash","Mm"],["mm"]),swt:vscaffold(["Swt"],["ibm"])};
})();
dojo.hostenv=(function(){
var _20={isDebug:false,allowQueryConfig:false,baseScriptUri:"",baseRelativePath:"",libraryScriptUri:"",iePreventClobber:false,ieClobberMinimal:true,preventBackButtonFix:true,searchIds:[],parseWidgets:true};
if(typeof djConfig=="undefined"){
djConfig=_20;
}else{
for(var _21 in _20){
if(typeof djConfig[_21]=="undefined"){
djConfig[_21]=_20[_21];
}
}
}
return {name_:"(unset)",version_:"(unset)",getName:function(){
return this.name_;
},getVersion:function(){
return this.version_;
},getText:function(uri){
dojo.unimplemented("getText","uri="+uri);
}};
})();
dojo.hostenv.getBaseScriptUri=function(){
if(djConfig.baseScriptUri.length){
return djConfig.baseScriptUri;
}
var uri=new String(djConfig.libraryScriptUri||djConfig.baseRelativePath);
if(!uri){
dojo.raise("Nothing returned by getLibraryScriptUri(): "+uri);
}
var _24=uri.lastIndexOf("/");
djConfig.baseScriptUri=djConfig.baseRelativePath;
return djConfig.baseScriptUri;
};
(function(){
var _25={pkgFileName:"__package__",loading_modules_:{},loaded_modules_:{},addedToLoadingCount:[],removedFromLoadingCount:[],inFlightCount:0,modulePrefixes_:{dojo:{name:"dojo",value:"src"}},setModulePrefix:function(_26,_27){
this.modulePrefixes_[_26]={name:_26,value:_27};
},moduleHasPrefix:function(_28){
var mp=this.modulePrefixes_;
return Boolean((mp[_28])&&(mp[_28]["value"]));
},getModulePrefix:function(_2a){
var mp=this.modulePrefixes_;
if((mp[_2a])&&(mp[_2a]["value"])){
return mp[_2a].value;
}
return _2a;
},getTextStack:[],loadUriStack:[],loadedUris:[],post_load_:false,modulesLoadedListeners:[],unloadListeners:[],loadNotifying:false};
for(var _2c in _25){
dojo.hostenv[_2c]=_25[_2c];
}
})();
dojo.hostenv.loadPath=function(_2d,_2e,cb){
var uri;
if((_2d.charAt(0)=="/")||(_2d.match(/^\w+:/))){
uri=_2d;
}else{
uri=this.getBaseScriptUri()+_2d;
}
if(djConfig.cacheBust&&dojo.render.html.capable){
uri+="?"+String(djConfig.cacheBust).replace(/\W+/g,"");
}
try{
return ((!_2e)?this.loadUri(uri,cb):this.loadUriAndCheck(uri,_2e,cb));
}
catch(e){
dojo.debug(e);
return false;
}
};
dojo.hostenv.loadUri=function(uri,cb){
if(this.loadedUris[uri]){
return 1;
}
var _33=this.getText(uri,null,true);
if(_33==null){
return 0;
}
this.loadedUris[uri]=true;
if(cb){
_33="("+_33+")";
}
var _34=dj_eval(_33);
if(cb){
cb(_34);
}
return 1;
};
dojo.hostenv.loadUriAndCheck=function(uri,_36,cb){
var ok=true;
try{
ok=this.loadUri(uri,cb);
}
catch(e){
dojo.debug("failed loading ",uri," with error: ",e);
}
return ((ok)&&(this.findModule(_36,false)))?true:false;
};
dojo.loaded=function(){
};
dojo.unloaded=function(){
};
dojo.hostenv.loaded=function(){
this.loadNotifying=true;
this.post_load_=true;
var mll=this.modulesLoadedListeners;
for(var x=0;x<mll.length;x++){
mll[x]();
}
this.modulesLoadedListeners=[];
this.loadNotifying=false;
dojo.loaded();
};
dojo.hostenv.unloaded=function(){
var mll=this.unloadListeners;
while(mll.length){
(mll.pop())();
}
dojo.unloaded();
};
dojo.addOnLoad=function(obj,_3d){
var dh=dojo.hostenv;
if(arguments.length==1){
dh.modulesLoadedListeners.push(obj);
}else{
if(arguments.length>1){
dh.modulesLoadedListeners.push(function(){
obj[_3d]();
});
}
}
if(dh.post_load_&&dh.inFlightCount==0&&!dh.loadNotifying){
dh.callLoaded();
}
};
dojo.addOnUnload=function(obj,_40){
var dh=dojo.hostenv;
if(arguments.length==1){
dh.unloadListeners.push(obj);
}else{
if(arguments.length>1){
dh.unloadListeners.push(function(){
obj[_40]();
});
}
}
};
dojo.hostenv.modulesLoaded=function(){
if(this.post_load_){
return;
}
if((this.loadUriStack.length==0)&&(this.getTextStack.length==0)){
if(this.inFlightCount>0){
dojo.debug("files still in flight!");
return;
}
dojo.hostenv.callLoaded();
}
};
dojo.hostenv.callLoaded=function(){
if(typeof setTimeout=="object"){
setTimeout("dojo.hostenv.loaded();",0);
}else{
dojo.hostenv.loaded();
}
};
dojo.hostenv.getModuleSymbols=function(_42){
var _43=_42.split(".");
for(var i=_43.length;i>0;i--){
var _45=_43.slice(0,i).join(".");
if((i==1)&&(!this.moduleHasPrefix(_45))){
_43[0]="../"+_43[0];
}else{
var _46=this.getModulePrefix(_45);
if(_46!=_45){
_43.splice(0,i,_46);
break;
}
}
}
return _43;
};
dojo.hostenv._global_omit_module_check=false;
dojo.hostenv.loadModule=function(_47,_48,_49){
if(!_47){
return;
}
_49=this._global_omit_module_check||_49;
var _4a=this.findModule(_47,false);
if(_4a){
return _4a;
}
if(dj_undef(_47,this.loading_modules_)){
this.addedToLoadingCount.push(_47);
}
this.loading_modules_[_47]=1;
var _4b=_47.replace(/\./g,"/")+".js";
var _4c=_47.split(".");
var _4d=this.getModuleSymbols(_47);
var _4e=((_4d[0].charAt(0)!="/")&&(!_4d[0].match(/^\w+:/)));
var _4f=_4d[_4d.length-1];
if(_4f=="*"){
_47=(_4c.slice(0,-1)).join(".");
while(_4d.length){
_4d.pop();
_4d.push(this.pkgFileName);
_4b=_4d.join("/")+".js";
if(_4e&&(_4b.charAt(0)=="/")){
_4b=_4b.slice(1);
}
ok=this.loadPath(_4b,((!_49)?_47:null));
if(ok){
break;
}
_4d.pop();
}
}else{
_4b=_4d.join("/")+".js";
_47=_4c.join(".");
var ok=this.loadPath(_4b,((!_49)?_47:null));
if((!ok)&&(!_48)){
_4d.pop();
while(_4d.length){
_4b=_4d.join("/")+".js";
ok=this.loadPath(_4b,((!_49)?_47:null));
if(ok){
break;
}
_4d.pop();
_4b=_4d.join("/")+"/"+this.pkgFileName+".js";
if(_4e&&(_4b.charAt(0)=="/")){
_4b=_4b.slice(1);
}
ok=this.loadPath(_4b,((!_49)?_47:null));
if(ok){
break;
}
}
}
if((!ok)&&(!_49)){
dojo.raise("Could not load '"+_47+"'; last tried '"+_4b+"'");
}
}
if(!_49&&!this["isXDomain"]){
_4a=this.findModule(_47,false);
if(!_4a){
dojo.raise("symbol '"+_47+"' is not defined after loading '"+_4b+"'");
}
}
return _4a;
};
dojo.hostenv.startPackage=function(_51){
var _52=(new String(_51)).toString();
var _53=_52;
var _54=_51.split(/\./);
if(_54[_54.length-1]=="*"){
_54.pop();
_53=_54.join(".");
}
var _55=dojo.evalObjPath(_53.toString(),true);
this.loaded_modules_[_52]=_55;
this.loaded_modules_[_53]=_55;
return _55;
};
dojo.hostenv.findModule=function(_56,_57){
var lmn=String(_56).toString();
if(this.loaded_modules_[lmn]){
return this.loaded_modules_[lmn];
}
if(_57){
dojo.raise("no loaded module named '"+_56+"'");
}
return null;
};
dojo.kwCompoundRequire=function(_59){
var _5a=_59["common"]||[];
var _5b=(_59[dojo.hostenv.name_])?_5a.concat(_59[dojo.hostenv.name_]||[]):_5a.concat(_59["default"]||[]);
for(var x=0;x<_5b.length;x++){
var _5d=_5b[x];
if(_5d.constructor==Array){
dojo.hostenv.loadModule.apply(dojo.hostenv,_5d);
}else{
dojo.hostenv.loadModule(_5d);
}
}
};
dojo.require=function(){
dojo.hostenv.loadModule.apply(dojo.hostenv,arguments);
};
dojo.requireIf=function(){
if((arguments[0]===true)||(arguments[0]=="common")||(arguments[0]&&dojo.render[arguments[0]].capable)){
var _5e=[];
for(var i=1;i<arguments.length;i++){
_5e.push(arguments[i]);
}
dojo.require.apply(dojo,_5e);
}
};
dojo.requireAfterIf=dojo.requireIf;
dojo.provide=function(){
return dojo.hostenv.startPackage.apply(dojo.hostenv,arguments);
};
dojo.registerModulePath=function(_60,_61){
return dojo.hostenv.setModulePrefix(_60,_61);
};
dojo.setModulePrefix=function(_62,_63){
dojo.deprecated("dojo.setModulePrefix(\""+_62+"\", \""+_63+"\")","replaced by dojo.registerModulePath","0.5");
return dojo.registerModulePath(_62,_63);
};
dojo.exists=function(obj,_65){
var p=_65.split(".");
for(var i=0;i<p.length;i++){
if(!(obj[p[i]])){
return false;
}
obj=obj[p[i]];
}
return true;
};
}
if(typeof window=="undefined"){
dojo.raise("no window object");
}
(function(){
if(djConfig.allowQueryConfig){
var _68=document.location.toString();
var _69=_68.split("?",2);
if(_69.length>1){
var _6a=_69[1];
var _6b=_6a.split("&");
for(var x in _6b){
var sp=_6b[x].split("=");
if((sp[0].length>9)&&(sp[0].substr(0,9)=="djConfig.")){
var opt=sp[0].substr(9);
try{
djConfig[opt]=eval(sp[1]);
}
catch(e){
djConfig[opt]=sp[1];
}
}
}
}
}
if(((djConfig["baseScriptUri"]=="")||(djConfig["baseRelativePath"]==""))&&(document&&document.getElementsByTagName)){
var _6f=document.getElementsByTagName("script");
var _70=/(__package__|dojo|bootstrap1)\.js([\?\.]|$)/i;
for(var i=0;i<_6f.length;i++){
var src=_6f[i].getAttribute("src");
if(!src){
continue;
}
var m=src.match(_70);
if(m){
var _74=src.substring(0,m.index);
if(src.indexOf("bootstrap1")>-1){
_74+="../";
}
if(!this["djConfig"]){
djConfig={};
}
if(djConfig["baseScriptUri"]==""){
djConfig["baseScriptUri"]=_74;
}
if(djConfig["baseRelativePath"]==""){
djConfig["baseRelativePath"]=_74;
}
break;
}
}
}
var dr=dojo.render;
var drh=dojo.render.html;
var drs=dojo.render.svg;
var dua=(drh.UA=navigator.userAgent);
var dav=(drh.AV=navigator.appVersion);
var t=true;
var f=false;
drh.capable=t;
drh.support.builtin=t;
dr.ver=parseFloat(drh.AV);
dr.os.mac=dav.indexOf("Macintosh")>=0;
dr.os.win=dav.indexOf("Windows")>=0;
dr.os.linux=dav.indexOf("X11")>=0;
drh.opera=dua.indexOf("Opera")>=0;
drh.khtml=(dav.indexOf("Konqueror")>=0)||(dav.indexOf("Safari")>=0);
drh.safari=dav.indexOf("Safari")>=0;
var _7c=dua.indexOf("Gecko");
drh.mozilla=drh.moz=(_7c>=0)&&(!drh.khtml);
if(drh.mozilla){
drh.geckoVersion=dua.substring(_7c+6,_7c+14);
}
drh.ie=(document.all)&&(!drh.opera);
drh.ie50=drh.ie&&dav.indexOf("MSIE 5.0")>=0;
drh.ie55=drh.ie&&dav.indexOf("MSIE 5.5")>=0;
drh.ie60=drh.ie&&dav.indexOf("MSIE 6.0")>=0;
drh.ie70=drh.ie&&dav.indexOf("MSIE 7.0")>=0;
var cm=document["compatMode"];
drh.quirks=(cm=="BackCompat")||(cm=="QuirksMode")||drh.ie55||drh.ie50;
dojo.locale=dojo.locale||(drh.ie?navigator.userLanguage:navigator.language).toLowerCase();
dr.vml.capable=drh.ie;
drs.capable=f;
drs.support.plugin=f;
drs.support.builtin=f;
var _7e=window["document"];
var tdi=_7e["implementation"];
if((tdi)&&(tdi["hasFeature"])&&(tdi.hasFeature("org.w3c.dom.svg","1.0"))){
drs.capable=t;
drs.support.builtin=t;
drs.support.plugin=f;
}
if(drh.safari){
var tmp=dua.split("AppleWebKit/")[1];
var ver=parseFloat(tmp.split(" ")[0]);
if(ver>=420){
drs.capable=t;
drs.support.builtin=t;
drs.support.plugin=f;
}
}
})();
dojo.hostenv.startPackage("dojo.hostenv");
dojo.render.name=dojo.hostenv.name_="browser";
dojo.hostenv.searchIds=[];
dojo.hostenv._XMLHTTP_PROGIDS=["Msxml2.XMLHTTP","Microsoft.XMLHTTP","Msxml2.XMLHTTP.4.0"];
dojo.hostenv.getXmlhttpObject=function(){
var _82=null;
var _83=null;
try{
_82=new XMLHttpRequest();
}
catch(e){
}
if(!_82){
for(var i=0;i<3;++i){
var _85=dojo.hostenv._XMLHTTP_PROGIDS[i];
try{
_82=new ActiveXObject(_85);
}
catch(e){
_83=e;
}
if(_82){
dojo.hostenv._XMLHTTP_PROGIDS=[_85];
break;
}
}
}
if(!_82){
return dojo.raise("XMLHTTP not available",_83);
}
return _82;
};
dojo.hostenv._blockAsync=false;
dojo.hostenv.getText=function(uri,_87,_88){
if(!_87){
this._blockAsync=true;
}
var _89=this.getXmlhttpObject();
function isDocumentOk(_8a){
var _8b=_8a["status"];
return Boolean((!_8b)||((200<=_8b)&&(300>_8b))||(_8b==304));
}
if(_87){
var _8c=this,timer=null,gbl=dojo.global();
var xhr=dojo.evalObjPath("dojo.io.XMLHTTPTransport");
_89.onreadystatechange=function(){
if(timer){
gbl.clearTimeout(timer);
timer=null;
}
if(_8c._blockAsync||(xhr&&xhr._blockAsync)){
timer=gbl.setTimeout(function(){
_89.onreadystatechange.apply(this);
},10);
}else{
if(4==_89.readyState){
if(isDocumentOk(_89)){
_87(_89.responseText);
}
}
}
};
}
_89.open("GET",uri,_87?true:false);
try{
_89.send(null);
if(_87){
return null;
}
if(!isDocumentOk(_89)){
var err=Error("Unable to load "+uri+" status:"+_89.status);
err.status=_89.status;
err.responseText=_89.responseText;
throw err;
}
}
catch(e){
this._blockAsync=false;
if((_88)&&(!_87)){
return null;
}else{
throw e;
}
}
this._blockAsync=false;
return _89.responseText;
};
dojo.hostenv.defaultDebugContainerId="dojoDebug";
dojo.hostenv._println_buffer=[];
dojo.hostenv._println_safe=false;
dojo.hostenv.println=function(_8f){
if(!dojo.hostenv._println_safe){
dojo.hostenv._println_buffer.push(_8f);
}else{
try{
var _90=document.getElementById(djConfig.debugContainerId?djConfig.debugContainerId:dojo.hostenv.defaultDebugContainerId);
if(!_90){
_90=dojo.body();
}
var div=document.createElement("div");
div.appendChild(document.createTextNode(_8f));
_90.appendChild(div);
}
catch(e){
try{
document.write("<div>"+_8f+"</div>");
}
catch(e2){
window.status=_8f;
}
}
}
};
dojo.addOnLoad(function(){
dojo.hostenv._println_safe=true;
while(dojo.hostenv._println_buffer.length>0){
dojo.hostenv.println(dojo.hostenv._println_buffer.shift());
}
});
function dj_addNodeEvtHdlr(_92,_93,fp,_95){
var _96=_92["on"+_93]||function(){
};
_92["on"+_93]=function(){
fp.apply(_92,arguments);
_96.apply(_92,arguments);
};
return true;
}
function dj_load_init(e){
var _98=(e&&e.type)?e.type.toLowerCase():"load";
if(arguments.callee.initialized||(_98!="domcontentloaded"&&_98!="load")){
return;
}
arguments.callee.initialized=true;
if(typeof (_timer)!="undefined"){
clearInterval(_timer);
delete _timer;
}
var _99=function(){
if(dojo.render.html.ie){
dojo.hostenv.makeWidgets();
}
};
if(dojo.hostenv.inFlightCount==0){
_99();
dojo.hostenv.modulesLoaded();
}else{
dojo.addOnLoad(_99);
}
}
if(document.addEventListener){
document.addEventListener("DOMContentLoaded",dj_load_init,null);
document.addEventListener("load",dj_load_init,null);
}
if(dojo.render.html.ie&&dojo.render.os.win){
document.attachEvent("onreadystatechange",function(e){
if(document.readyState=="complete"){
dj_load_init();
}
});
}
if(/(WebKit|khtml)/i.test(navigator.userAgent)){
var _timer=setInterval(function(){
if(/loaded|complete/.test(document.readyState)){
dj_load_init();
}
},10);
}
dj_addNodeEvtHdlr(window,"unload",function(){
dojo.hostenv.unloaded();
});
dojo.hostenv.makeWidgets=function(){
var _9b=[];
if(djConfig.searchIds&&djConfig.searchIds.length>0){
_9b=_9b.concat(djConfig.searchIds);
}
if(dojo.hostenv.searchIds&&dojo.hostenv.searchIds.length>0){
_9b=_9b.concat(dojo.hostenv.searchIds);
}
if((djConfig.parseWidgets)||(_9b.length>0)){
if(dojo.evalObjPath("dojo.widget.Parse")){
var _9c=new dojo.xml.Parse();
if(_9b.length>0){
for(var x=0;x<_9b.length;x++){
var _9e=document.getElementById(_9b[x]);
if(!_9e){
continue;
}
var _9f=_9c.parseElement(_9e,null,true);
dojo.widget.getParser().createComponents(_9f);
}
}else{
if(djConfig.parseWidgets){
var _9f=_9c.parseElement(dojo.body(),null,true);
dojo.widget.getParser().createComponents(_9f);
}
}
}
}
};
dojo.addOnLoad(function(){
if(!dojo.render.html.ie){
dojo.hostenv.makeWidgets();
}
});
try{
if(dojo.render.html.ie){
document.namespaces.add("v","urn:schemas-microsoft-com:vml");
document.createStyleSheet().addRule("v\\:*","behavior:url(#default#VML)");
}
}
catch(e){
}
dojo.hostenv.writeIncludes=function(){
};
if(!dj_undef("document",this)){
dj_currentDocument=this.document;
}
dojo.doc=function(){
return dj_currentDocument;
};
dojo.body=function(){
return dojo.doc().body||dojo.doc().getElementsByTagName("body")[0];
};
dojo.byId=function(id,doc){
if((id)&&((typeof id=="string")||(id instanceof String))){
return (doc||dj_currentDocument).getElementById(id);
}
return id;
};
dojo.setContext=function(_a2,_a3){
dj_currentContext=_a2;
dj_currentDocument=_a3;
};
dojo._fireCallback=function(_a4,_a5,_a6){
if((_a5)&&((typeof _a4=="string")||(_a4 instanceof String))){
_a4=_a5[_a4];
}
return (_a5?_a4.apply(_a5,_a6||[]):_a4());
};
dojo.withGlobal=function(_a7,_a8,_a9,_aa){
var _ab;
var _ac=dj_currentContext;
var _ad=dj_currentDocument;
try{
dojo.setContext(_a7,_a7.document);
_ab=dojo._fireCallback(_a8,_a9,_aa);
}
finally{
dojo.setContext(_ac,_ad);
}
return _ab;
};
dojo.withDoc=function(_ae,_af,_b0,_b1){
var _b2;
var _b3=dj_currentDocument;
try{
dj_currentDocument=_ae;
_b2=dojo._fireCallback(_af,_b0,_b1);
}
finally{
dj_currentDocument=_b3;
}
return _b2;
};
(function(){
if(typeof dj_usingBootstrap!="undefined"){
return;
}
var _b4=false;
var _b5=false;
var _b6=false;
if((typeof this["load"]=="function")&&((typeof this["Packages"]=="function")||(typeof this["Packages"]=="object"))){
_b4=true;
}else{
if(typeof this["load"]=="function"){
_b5=true;
}else{
if(window.widget){
_b6=true;
}
}
}
var _b7=[];
if((this["djConfig"])&&((djConfig["isDebug"])||(djConfig["debugAtAllCosts"]))){
_b7.push("debug.js");
}
if((this["djConfig"])&&(djConfig["debugAtAllCosts"])&&(!_b4)&&(!_b6)){
_b7.push("browser_debug.js");
}
if((this["djConfig"])&&(djConfig["compat"])){
_b7.push("compat/"+djConfig["compat"]+".js");
}
var _b8=djConfig["baseScriptUri"];
if((this["djConfig"])&&(djConfig["baseLoaderUri"])){
_b8=djConfig["baseLoaderUri"];
}
for(var x=0;x<_b7.length;x++){
var _ba=_b8+"src/"+_b7[x];
if(_b4||_b5){
load(_ba);
}else{
try{
document.write("<scr"+"ipt type='text/javascript' src='"+_ba+"'></scr"+"ipt>");
}
catch(e){
var _bb=document.createElement("script");
_bb.src=_ba;
document.getElementsByTagName("head")[0].appendChild(_bb);
}
}
}
})();
dojo.normalizeLocale=function(_bc){
return _bc?_bc.toLowerCase():dojo.locale;
};
dojo.searchLocalePath=function(_bd,_be,_bf){
_bd=dojo.normalizeLocale(_bd);
var _c0=_bd.split("-");
var _c1=[];
for(var i=_c0.length;i>0;i--){
_c1.push(_c0.slice(0,i).join("-"));
}
_c1.push(false);
if(_be){
_c1.reverse();
}
for(var j=_c1.length-1;j>=0;j--){
var loc=_c1[j]||"ROOT";
var _c5=_bf(loc);
if(_c5){
break;
}
}
};
dojo.requireLocalization=function(_c6,_c7,_c8){
var _c9=[_c6,"_nls",_c7].join(".");
var _ca=dojo.hostenv.startPackage(_c9);
dojo.hostenv.loaded_modules_[_c9]=_ca;
if(!dj_undef("dj_localesBuilt",dj_global)&&dojo.hostenv.loaded_modules_[_c9]){
_c8=dojo.normalizeLocale(_c8);
for(var i=0;i<dj_localesBuilt.length;i++){
if(dj_localesBuilt[i]==_c8){
return;
}
}
}
var _cc=dojo.hostenv.getModuleSymbols(_c6);
var _cd=_cc.concat("nls").join("/");
var _ce=false;
dojo.searchLocalePath(_c8,false,function(loc){
var pkg=_c9+"."+loc;
var _d1=false;
if(!dojo.hostenv.findModule(pkg)){
dojo.hostenv.loaded_modules_[pkg]=null;
var _d2=[_cd];
if(loc!="ROOT"){
_d2.push(loc);
}
_d2.push(_c7);
var _d3=_d2.join("/")+".js";
_d1=dojo.hostenv.loadPath(_d3,null,function(_d4){
var _d5=function(){
};
_d5.prototype=_ce;
_ca[loc]=new _d5();
for(var j in _d4){
_ca[loc][j]=_d4[j];
}
});
}else{
_d1=true;
}
if(_d1&&_ca[loc]){
_ce=_ca[loc];
}
});
};
(function(){
function preload(_d7){
if(!dj_undef("dj_localesGenerated",dj_global)){
dojo.setModulePrefix("nls","nls");
_d7=dojo.normalizeLocale(_d7);
dojo.searchLocalePath(_d7,true,function(loc){
for(var i=0;i<dj_localesGenerated.length;i++){
if(dj_localesGenerated[i]==loc){
dojo.require("nls.dojo_"+loc);
return true;
}
}
return false;
});
}
}
preload(dojo.locale);
var _da=djConfig.extraLocale;
if(_da){
if(!_da instanceof Array){
_da=[_da];
}
for(var i=0;i<_da.length;i++){
preload(_da[i]);
}
var req=dojo.requireLocalization;
dojo.requireLocalization=function(m,b,_df){
req(m,b,_df);
if(_df){
return;
}
for(var i=0;i<_da.length;i++){
req(m,b,_da[i]);
}
};
}
})();
dojo.provide("dojo.dom");
dojo.dom.ELEMENT_NODE=1;
dojo.dom.ATTRIBUTE_NODE=2;
dojo.dom.TEXT_NODE=3;
dojo.dom.CDATA_SECTION_NODE=4;
dojo.dom.ENTITY_REFERENCE_NODE=5;
dojo.dom.ENTITY_NODE=6;
dojo.dom.PROCESSING_INSTRUCTION_NODE=7;
dojo.dom.COMMENT_NODE=8;
dojo.dom.DOCUMENT_NODE=9;
dojo.dom.DOCUMENT_TYPE_NODE=10;
dojo.dom.DOCUMENT_FRAGMENT_NODE=11;
dojo.dom.NOTATION_NODE=12;
dojo.dom.dojoml="http://www.dojotoolkit.org/2004/dojoml";
dojo.dom.xmlns={svg:"http://www.w3.org/2000/svg",smil:"http://www.w3.org/2001/SMIL20/",mml:"http://www.w3.org/1998/Math/MathML",cml:"http://www.xml-cml.org",xlink:"http://www.w3.org/1999/xlink",xhtml:"http://www.w3.org/1999/xhtml",xul:"http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul",xbl:"http://www.mozilla.org/xbl",fo:"http://www.w3.org/1999/XSL/Format",xsl:"http://www.w3.org/1999/XSL/Transform",xslt:"http://www.w3.org/1999/XSL/Transform",xi:"http://www.w3.org/2001/XInclude",xforms:"http://www.w3.org/2002/01/xforms",saxon:"http://icl.com/saxon",xalan:"http://xml.apache.org/xslt",xsd:"http://www.w3.org/2001/XMLSchema",dt:"http://www.w3.org/2001/XMLSchema-datatypes",xsi:"http://www.w3.org/2001/XMLSchema-instance",rdf:"http://www.w3.org/1999/02/22-rdf-syntax-ns#",rdfs:"http://www.w3.org/2000/01/rdf-schema#",dc:"http://purl.org/dc/elements/1.1/",dcq:"http://purl.org/dc/qualifiers/1.0","soap-env":"http://schemas.xmlsoap.org/soap/envelope/",wsdl:"http://schemas.xmlsoap.org/wsdl/",AdobeExtensions:"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"};
dojo.dom.isNode=function(wh){
if(typeof Element=="function"){
try{
return wh instanceof Element;
}
catch(E){
}
}else{
return wh&&!isNaN(wh.nodeType);
}
};
dojo.dom.getUniqueId=function(){
var _e2=dojo.doc();
do{
var id="dj_unique_"+(++arguments.callee._idIncrement);
}while(_e2.getElementById(id));
return id;
};
dojo.dom.getUniqueId._idIncrement=0;
dojo.dom.firstElement=dojo.dom.getFirstChildElement=function(_e4,_e5){
var _e6=_e4.firstChild;
while(_e6&&_e6.nodeType!=dojo.dom.ELEMENT_NODE){
_e6=_e6.nextSibling;
}
if(_e5&&_e6&&_e6.tagName&&_e6.tagName.toLowerCase()!=_e5.toLowerCase()){
_e6=dojo.dom.nextElement(_e6,_e5);
}
return _e6;
};
dojo.dom.lastElement=dojo.dom.getLastChildElement=function(_e7,_e8){
var _e9=_e7.lastChild;
while(_e9&&_e9.nodeType!=dojo.dom.ELEMENT_NODE){
_e9=_e9.previousSibling;
}
if(_e8&&_e9&&_e9.tagName&&_e9.tagName.toLowerCase()!=_e8.toLowerCase()){
_e9=dojo.dom.prevElement(_e9,_e8);
}
return _e9;
};
dojo.dom.nextElement=dojo.dom.getNextSiblingElement=function(_ea,_eb){
if(!_ea){
return null;
}
do{
_ea=_ea.nextSibling;
}while(_ea&&_ea.nodeType!=dojo.dom.ELEMENT_NODE);
if(_ea&&_eb&&_eb.toLowerCase()!=_ea.tagName.toLowerCase()){
return dojo.dom.nextElement(_ea,_eb);
}
return _ea;
};
dojo.dom.prevElement=dojo.dom.getPreviousSiblingElement=function(_ec,_ed){
if(!_ec){
return null;
}
if(_ed){
_ed=_ed.toLowerCase();
}
do{
_ec=_ec.previousSibling;
}while(_ec&&_ec.nodeType!=dojo.dom.ELEMENT_NODE);
if(_ec&&_ed&&_ed.toLowerCase()!=_ec.tagName.toLowerCase()){
return dojo.dom.prevElement(_ec,_ed);
}
return _ec;
};
dojo.dom.moveChildren=function(_ee,_ef,_f0){
var _f1=0;
if(_f0){
while(_ee.hasChildNodes()&&_ee.firstChild.nodeType==dojo.dom.TEXT_NODE){
_ee.removeChild(_ee.firstChild);
}
while(_ee.hasChildNodes()&&_ee.lastChild.nodeType==dojo.dom.TEXT_NODE){
_ee.removeChild(_ee.lastChild);
}
}
while(_ee.hasChildNodes()){
_ef.appendChild(_ee.firstChild);
_f1++;
}
return _f1;
};
dojo.dom.copyChildren=function(_f2,_f3,_f4){
var _f5=_f2.cloneNode(true);
return this.moveChildren(_f5,_f3,_f4);
};
dojo.dom.removeChildren=function(_f6){
var _f7=_f6.childNodes.length;
while(_f6.hasChildNodes()){
_f6.removeChild(_f6.firstChild);
}
return _f7;
};
dojo.dom.replaceChildren=function(_f8,_f9){
dojo.dom.removeChildren(_f8);
_f8.appendChild(_f9);
};
dojo.dom.removeNode=function(_fa){
if(_fa&&_fa.parentNode){
return _fa.parentNode.removeChild(_fa);
}
};
dojo.dom.getAncestors=function(_fb,_fc,_fd){
var _fe=[];
var _ff=(_fc&&(_fc instanceof Function||typeof _fc=="function"));
while(_fb){
if(!_ff||_fc(_fb)){
_fe.push(_fb);
}
if(_fd&&_fe.length>0){
return _fe[0];
}
_fb=_fb.parentNode;
}
if(_fd){
return null;
}
return _fe;
};
dojo.dom.getAncestorsByTag=function(node,tag,_102){
tag=tag.toLowerCase();
return dojo.dom.getAncestors(node,function(el){
return ((el.tagName)&&(el.tagName.toLowerCase()==tag));
},_102);
};
dojo.dom.getFirstAncestorByTag=function(node,tag){
return dojo.dom.getAncestorsByTag(node,tag,true);
};
dojo.dom.isDescendantOf=function(node,_107,_108){
if(_108&&node){
node=node.parentNode;
}
while(node){
if(node==_107){
return true;
}
node=node.parentNode;
}
return false;
};
dojo.dom.innerXML=function(node){
if(node.innerXML){
return node.innerXML;
}else{
if(node.xml){
return node.xml;
}else{
if(typeof XMLSerializer!="undefined"){
return (new XMLSerializer()).serializeToString(node);
}
}
}
};
dojo.dom.createDocument=function(){
var doc=null;
var _10b=dojo.doc();
if(!dj_undef("ActiveXObject")){
var _10c=["MSXML2","Microsoft","MSXML","MSXML3"];
for(var i=0;i<_10c.length;i++){
try{
doc=new ActiveXObject(_10c[i]+".XMLDOM");
}
catch(e){
}
if(doc){
break;
}
}
}else{
if((_10b.implementation)&&(_10b.implementation.createDocument)){
doc=_10b.implementation.createDocument("","",null);
}
}
return doc;
};
dojo.dom.createDocumentFromText=function(str,_10f){
if(!_10f){
_10f="text/xml";
}
if(!dj_undef("DOMParser")){
var _110=new DOMParser();
return _110.parseFromString(str,_10f);
}else{
if(!dj_undef("ActiveXObject")){
var _111=dojo.dom.createDocument();
if(_111){
_111.async=false;
_111.loadXML(str);
return _111;
}else{
dojo.debug("toXml didn't work?");
}
}else{
var _112=dojo.doc();
if(_112.createElement){
var tmp=_112.createElement("xml");
tmp.innerHTML=str;
if(_112.implementation&&_112.implementation.createDocument){
var _114=_112.implementation.createDocument("foo","",null);
for(var i=0;i<tmp.childNodes.length;i++){
_114.importNode(tmp.childNodes.item(i),true);
}
return _114;
}
return ((tmp.document)&&(tmp.document.firstChild?tmp.document.firstChild:tmp));
}
}
}
return null;
};
dojo.dom.prependChild=function(node,_117){
if(_117.firstChild){
_117.insertBefore(node,_117.firstChild);
}else{
_117.appendChild(node);
}
return true;
};
dojo.dom.insertBefore=function(node,ref,_11a){
if(_11a!=true&&(node===ref||node.nextSibling===ref)){
return false;
}
var _11b=ref.parentNode;
_11b.insertBefore(node,ref);
return true;
};
dojo.dom.insertAfter=function(node,ref,_11e){
var pn=ref.parentNode;
if(ref==pn.lastChild){
if((_11e!=true)&&(node===ref)){
return false;
}
pn.appendChild(node);
}else{
return this.insertBefore(node,ref.nextSibling,_11e);
}
return true;
};
dojo.dom.insertAtPosition=function(node,ref,_122){
if((!node)||(!ref)||(!_122)){
return false;
}
switch(_122.toLowerCase()){
case "before":
return dojo.dom.insertBefore(node,ref);
case "after":
return dojo.dom.insertAfter(node,ref);
case "first":
if(ref.firstChild){
return dojo.dom.insertBefore(node,ref.firstChild);
}else{
ref.appendChild(node);
return true;
}
break;
default:
ref.appendChild(node);
return true;
}
};
dojo.dom.insertAtIndex=function(node,_124,_125){
var _126=_124.childNodes;
if(!_126.length){
_124.appendChild(node);
return true;
}
var _127=null;
for(var i=0;i<_126.length;i++){
var _129=_126.item(i)["getAttribute"]?parseInt(_126.item(i).getAttribute("dojoinsertionindex")):-1;
if(_129<_125){
_127=_126.item(i);
}
}
if(_127){
return dojo.dom.insertAfter(node,_127);
}else{
return dojo.dom.insertBefore(node,_126.item(0));
}
};
dojo.dom.textContent=function(node,text){
if(arguments.length>1){
var _12c=dojo.doc();
dojo.dom.replaceChildren(node,_12c.createTextNode(text));
return text;
}else{
if(node.textContent!=undefined){
return node.textContent;
}
var _12d="";
if(node==null){
return _12d;
}
for(var i=0;i<node.childNodes.length;i++){
switch(node.childNodes[i].nodeType){
case 1:
case 5:
_12d+=dojo.dom.textContent(node.childNodes[i]);
break;
case 3:
case 2:
case 4:
_12d+=node.childNodes[i].nodeValue;
break;
default:
break;
}
}
return _12d;
}
};
dojo.dom.hasParent=function(node){
return node&&node.parentNode&&dojo.dom.isNode(node.parentNode);
};
dojo.dom.isTag=function(node){
if(node&&node.tagName){
for(var i=1;i<arguments.length;i++){
if(node.tagName==String(arguments[i])){
return String(arguments[i]);
}
}
}
return "";
};
dojo.dom.setAttributeNS=function(elem,_133,_134,_135){
if(elem==null||((elem==undefined)&&(typeof elem=="undefined"))){
dojo.raise("No element given to dojo.dom.setAttributeNS");
}
if(!((elem.setAttributeNS==undefined)&&(typeof elem.setAttributeNS=="undefined"))){
elem.setAttributeNS(_133,_134,_135);
}else{
var _136=elem.ownerDocument;
var _137=_136.createNode(2,_134,_133);
_137.nodeValue=_135;
elem.setAttributeNode(_137);
}
};
dojo.provide("dojo.xml.Parse");
dojo.xml.Parse=function(){
function getTagName(node){
return ((node)&&(node.tagName)?node.tagName.toLowerCase():"");
}
function getDojoTagName(node){
var _13a=getTagName(node);
if(!_13a){
return "";
}
if((dojo.widget)&&(dojo.widget.tags[_13a])){
return _13a;
}
var p=_13a.indexOf(":");
if(p>=0){
return _13a;
}
if(_13a.substr(0,5)=="dojo:"){
return _13a;
}
if(dojo.render.html.capable&&dojo.render.html.ie&&node.scopeName!="HTML"){
return node.scopeName.toLowerCase()+":"+_13a;
}
if(_13a.substr(0,4)=="dojo"){
return "dojo:"+_13a.substring(4);
}
var djt=node.getAttribute("dojoType")||node.getAttribute("dojotype");
if(djt){
if(djt.indexOf(":")<0){
djt="dojo:"+djt;
}
return djt.toLowerCase();
}
if((node.getAttributeNS)&&(node.getAttributeNS(dojo.dom.dojoml,"type"))){
return "dojo:"+node.getAttributeNS(dojo.dom.dojoml,"type").toLowerCase();
}
try{
djt=node.getAttribute("dojo:type").toLowerCase();
}
catch(e){
}
if(djt){
return "dojo:"+djt;
}
if(!dj_global["djConfig"]||!djConfig["ignoreClassNames"]){
var _13d=node.className||node.getAttribute("class");
if(_13d&&_13d.indexOf&&_13d.indexOf("dojo-")!=-1){
var _13e=_13d.split(" ");
for(var x=0,c;x<_13e.length;x++){
if(_13e[x].slice(0,5)=="dojo-"){
return "dojo:"+_13e[x].substr(5).toLowerCase();
}
}
}
}
return "";
}
this.parseElement=function(node,_141,_142,_143){
var _144={};
var _145=getTagName(node);
if((_145)&&(_145.indexOf("/")==0)){
return null;
}
var _146=true;
if(_142){
var _147=getDojoTagName(node);
_145=_147||_145;
_146=Boolean(_147);
}
_144[_145]=[];
var pos=_145.indexOf(":");
if(pos>0){
var ns=_145.substring(0,pos);
_144["namespace"]=ns;
if((dojo["namespace"])&&(!dojo["namespace"].allow(ns))){
_146=false;
}
}
if(_146){
var _14a=this.parseAttributes(node);
for(var attr in _14a){
if((!_144[_145][attr])||(typeof _144[_145][attr]!="array")){
_144[_145][attr]=[];
}
_144[_145][attr].push(_14a[attr]);
}
_144[_145].nodeRef=node;
_144.tagName=_145;
_144.index=_143||0;
}
var _14c=0;
for(var i=0;i<node.childNodes.length;i++){
var tcn=node.childNodes.item(i);
switch(tcn.nodeType){
case dojo.dom.ELEMENT_NODE:
_14c++;
var ctn=getDojoTagName(tcn)||getTagName(tcn);
if(!_144[ctn]){
_144[ctn]=[];
}
_144[ctn].push(this.parseElement(tcn,true,_142,_14c));
if((tcn.childNodes.length==1)&&(tcn.childNodes.item(0).nodeType==dojo.dom.TEXT_NODE)){
_144[ctn][_144[ctn].length-1].value=tcn.childNodes.item(0).nodeValue;
}
break;
case dojo.dom.TEXT_NODE:
if(node.childNodes.length==1){
_144[_145].push({value:node.childNodes.item(0).nodeValue});
}
break;
default:
break;
}
}
return _144;
};
this.parseAttributes=function(node){
var _151={};
var atts=node.attributes;
var _153,i=0;
while((_153=atts[i++])){
if((dojo.render.html.capable)&&(dojo.render.html.ie)){
if(!_153){
continue;
}
if((typeof _153=="object")&&(typeof _153.nodeValue=="undefined")||(_153.nodeValue==null)||(_153.nodeValue=="")){
continue;
}
}
var nn=_153.nodeName.split(":");
nn=(nn.length==2)?nn[1]:_153.nodeName;
_151[nn]={value:_153.nodeValue};
}
return _151;
};
};
dojo.provide("dojo.lang.common");
dojo.lang.inherits=function(_155,_156){
if(typeof _156!="function"){
dojo.raise("dojo.inherits: superclass argument ["+_156+"] must be a function (subclass: ["+_155+"']");
}
_155.prototype=new _156();
_155.prototype.constructor=_155;
_155.superclass=_156.prototype;
_155["super"]=_156.prototype;
};
dojo.lang._mixin=function(obj,_158){
var tobj={};
for(var x in _158){
if((typeof tobj[x]=="undefined")||(tobj[x]!=_158[x])){
obj[x]=_158[x];
}
}
if(dojo.render.html.ie&&(typeof (_158["toString"])=="function")&&(_158["toString"]!=obj["toString"])&&(_158["toString"]!=tobj["toString"])){
obj.toString=_158.toString;
}
return obj;
};
dojo.lang.mixin=function(obj,_15c){
for(var i=1,l=arguments.length;i<l;i++){
dojo.lang._mixin(obj,arguments[i]);
}
return obj;
};
dojo.lang.extend=function(_15e,_15f){
for(var i=1,l=arguments.length;i<l;i++){
dojo.lang._mixin(_15e.prototype,arguments[i]);
}
return _15e;
};
dojo.inherits=dojo.lang.inherits;
dojo.mixin=dojo.lang.mixin;
dojo.extend=dojo.lang.extend;
dojo.lang.find=function(_161,_162,_163,_164){
if(!dojo.lang.isArrayLike(_161)&&dojo.lang.isArrayLike(_162)){
dojo.deprecated("dojo.lang.find(value, array)","use dojo.lang.find(array, value) instead","0.5");
var temp=_161;
_161=_162;
_162=temp;
}
var _166=dojo.lang.isString(_161);
if(_166){
_161=_161.split("");
}
if(_164){
var step=-1;
var i=_161.length-1;
var end=-1;
}else{
var step=1;
var i=0;
var end=_161.length;
}
if(_163){
while(i!=end){
if(_161[i]===_162){
return i;
}
i+=step;
}
}else{
while(i!=end){
if(_161[i]==_162){
return i;
}
i+=step;
}
}
return -1;
};
dojo.lang.indexOf=dojo.lang.find;
dojo.lang.findLast=function(_16a,_16b,_16c){
return dojo.lang.find(_16a,_16b,_16c,true);
};
dojo.lang.lastIndexOf=dojo.lang.findLast;
dojo.lang.inArray=function(_16d,_16e){
return dojo.lang.find(_16d,_16e)>-1;
};
dojo.lang.isObject=function(it){
if(typeof it=="undefined"){
return false;
}
return (typeof it=="object"||it===null||dojo.lang.isArray(it)||dojo.lang.isFunction(it));
};
dojo.lang.isArray=function(it){
return (it&&it instanceof Array||typeof it=="array");
};
dojo.lang.isArrayLike=function(it){
if((!it)||(dojo.lang.isUndefined(it))){
return false;
}
if(dojo.lang.isString(it)){
return false;
}
if(dojo.lang.isFunction(it)){
return false;
}
if(dojo.lang.isArray(it)){
return true;
}
if((it.tagName)&&(it.tagName.toLowerCase()=="form")){
return false;
}
if(dojo.lang.isNumber(it.length)&&isFinite(it.length)){
return true;
}
return false;
};
dojo.lang.isFunction=function(it){
if(!it){
return false;
}
return (it instanceof Function||typeof it=="function");
};
dojo.lang.isString=function(it){
return (it instanceof String||typeof it=="string");
};
dojo.lang.isAlien=function(it){
if(!it){
return false;
}
return !dojo.lang.isFunction()&&/\{\s*\[native code\]\s*\}/.test(String(it));
};
dojo.lang.isBoolean=function(it){
return (it instanceof Boolean||typeof it=="boolean");
};
dojo.lang.isNumber=function(it){
return (it instanceof Number||typeof it=="number");
};
dojo.lang.isUndefined=function(it){
return ((typeof (it)=="undefined")&&(it==undefined));
};
dojo.provide("dojo.lang.func");
dojo.lang.hitch=function(_178,_179){
var fcn=(dojo.lang.isString(_179)?_178[_179]:_179)||function(){
};
return function(){
return fcn.apply(_178,arguments);
};
};
dojo.lang.anonCtr=0;
dojo.lang.anon={};
dojo.lang.nameAnonFunc=function(_17b,_17c,_17d){
var nso=(_17c||dojo.lang.anon);
if((_17d)||((dj_global["djConfig"])&&(djConfig["slowAnonFuncLookups"]==true))){
for(var x in nso){
try{
if(nso[x]===_17b){
return x;
}
}
catch(e){
}
}
}
var ret="__"+dojo.lang.anonCtr++;
while(typeof nso[ret]!="undefined"){
ret="__"+dojo.lang.anonCtr++;
}
nso[ret]=_17b;
return ret;
};
dojo.lang.forward=function(_181){
return function(){
return this[_181].apply(this,arguments);
};
};
dojo.lang.curry=function(ns,func){
var _184=[];
ns=ns||dj_global;
if(dojo.lang.isString(func)){
func=ns[func];
}
for(var x=2;x<arguments.length;x++){
_184.push(arguments[x]);
}
var _186=(func["__preJoinArity"]||func.length)-_184.length;
function gather(_187,_188,_189){
var _18a=_189;
var _18b=_188.slice(0);
for(var x=0;x<_187.length;x++){
_18b.push(_187[x]);
}
_189=_189-_187.length;
if(_189<=0){
var res=func.apply(ns,_18b);
_189=_18a;
return res;
}else{
return function(){
return gather(arguments,_18b,_189);
};
}
}
return gather([],_184,_186);
};
dojo.lang.curryArguments=function(ns,func,args,_191){
var _192=[];
var x=_191||0;
for(x=_191;x<args.length;x++){
_192.push(args[x]);
}
return dojo.lang.curry.apply(dojo.lang,[ns,func].concat(_192));
};
dojo.lang.tryThese=function(){
for(var x=0;x<arguments.length;x++){
try{
if(typeof arguments[x]=="function"){
var ret=(arguments[x]());
if(ret){
return ret;
}
}
}
catch(e){
dojo.debug(e);
}
}
};
dojo.lang.delayThese=function(farr,cb,_198,_199){
if(!farr.length){
if(typeof _199=="function"){
_199();
}
return;
}
if((typeof _198=="undefined")&&(typeof cb=="number")){
_198=cb;
cb=function(){
};
}else{
if(!cb){
cb=function(){
};
if(!_198){
_198=0;
}
}
}
setTimeout(function(){
(farr.shift())();
cb();
dojo.lang.delayThese(farr,cb,_198,_199);
},_198);
};
dojo.provide("dojo.lang.array");
dojo.lang.has=function(obj,name){
try{
return (typeof obj[name]!="undefined");
}
catch(e){
return false;
}
};
dojo.lang.isEmpty=function(obj){
if(dojo.lang.isObject(obj)){
var tmp={};
var _19e=0;
for(var x in obj){
if(obj[x]&&(!tmp[x])){
_19e++;
break;
}
}
return (_19e==0);
}else{
if(dojo.lang.isArrayLike(obj)||dojo.lang.isString(obj)){
return obj.length==0;
}
}
};
dojo.lang.map=function(arr,obj,_1a2){
var _1a3=dojo.lang.isString(arr);
if(_1a3){
arr=arr.split("");
}
if(dojo.lang.isFunction(obj)&&(!_1a2)){
_1a2=obj;
obj=dj_global;
}else{
if(dojo.lang.isFunction(obj)&&_1a2){
var _1a4=obj;
obj=_1a2;
_1a2=_1a4;
}
}
if(Array.map){
var _1a5=Array.map(arr,_1a2,obj);
}else{
var _1a5=[];
for(var i=0;i<arr.length;++i){
_1a5.push(_1a2.call(obj,arr[i]));
}
}
if(_1a3){
return _1a5.join("");
}else{
return _1a5;
}
};
dojo.lang.reduce=function(arr,_1a8,obj,_1aa){
var _1ab=_1a8;
var ob=obj?obj:dj_global;
dojo.lang.map(arr,function(val){
_1ab=_1aa.call(ob,_1ab,val);
});
return _1ab;
};
dojo.lang.forEach=function(_1ae,_1af,_1b0){
if(dojo.lang.isString(_1ae)){
_1ae=_1ae.split("");
}
if(Array.forEach){
Array.forEach(_1ae,_1af,_1b0);
}else{
if(!_1b0){
_1b0=dj_global;
}
for(var i=0,l=_1ae.length;i<l;i++){
_1af.call(_1b0,_1ae[i],i,_1ae);
}
}
};
dojo.lang._everyOrSome=function(_1b2,arr,_1b4,_1b5){
if(dojo.lang.isString(arr)){
arr=arr.split("");
}
if(Array.every){
return Array[(_1b2)?"every":"some"](arr,_1b4,_1b5);
}else{
if(!_1b5){
_1b5=dj_global;
}
for(var i=0,l=arr.length;i<l;i++){
var _1b7=_1b4.call(_1b5,arr[i],i,arr);
if((_1b2)&&(!_1b7)){
return false;
}else{
if((!_1b2)&&(_1b7)){
return true;
}
}
}
return (_1b2)?true:false;
}
};
dojo.lang.every=function(arr,_1b9,_1ba){
return this._everyOrSome(true,arr,_1b9,_1ba);
};
dojo.lang.some=function(arr,_1bc,_1bd){
return this._everyOrSome(false,arr,_1bc,_1bd);
};
dojo.lang.filter=function(arr,_1bf,_1c0){
var _1c1=dojo.lang.isString(arr);
if(_1c1){
arr=arr.split("");
}
if(Array.filter){
var _1c2=Array.filter(arr,_1bf,_1c0);
}else{
if(!_1c0){
if(arguments.length>=3){
dojo.raise("thisObject doesn't exist!");
}
_1c0=dj_global;
}
var _1c2=[];
for(var i=0;i<arr.length;i++){
if(_1bf.call(_1c0,arr[i],i,arr)){
_1c2.push(arr[i]);
}
}
}
if(_1c1){
return _1c2.join("");
}else{
return _1c2;
}
};
dojo.lang.unnest=function(){
var out=[];
for(var i=0;i<arguments.length;i++){
if(dojo.lang.isArrayLike(arguments[i])){
var add=dojo.lang.unnest.apply(this,arguments[i]);
out=out.concat(add);
}else{
out.push(arguments[i]);
}
}
return out;
};
dojo.lang.toArray=function(_1c7,_1c8){
var _1c9=[];
for(var i=_1c8||0;i<_1c7.length;i++){
_1c9.push(_1c7[i]);
}
return _1c9;
};
dojo.provide("dojo.lang.extras");
dojo.lang.setTimeout=function(func,_1cc){
var _1cd=window,argsStart=2;
if(!dojo.lang.isFunction(func)){
_1cd=func;
func=_1cc;
_1cc=arguments[2];
argsStart++;
}
if(dojo.lang.isString(func)){
func=_1cd[func];
}
var args=[];
for(var i=argsStart;i<arguments.length;i++){
args.push(arguments[i]);
}
return dojo.global().setTimeout(function(){
func.apply(_1cd,args);
},_1cc);
};
dojo.lang.clearTimeout=function(_1d0){
dojo.global().clearTimeout(_1d0);
};
dojo.lang.getNameInObj=function(ns,item){
if(!ns){
ns=dj_global;
}
for(var x in ns){
if(ns[x]===item){
return new String(x);
}
}
return null;
};
dojo.lang.shallowCopy=function(obj,deep){
var i,ret;
if(obj===null){
return null;
}
if(dojo.lang.isObject(obj)){
ret=new obj.constructor();
for(i in obj){
if(dojo.lang.isUndefined(ret[i])){
ret[i]=deep?dojo.lang.shallowCopy(obj[i],deep):obj[i];
}
}
}else{
if(dojo.lang.isArray(obj)){
ret=[];
for(i=0;i<obj.length;i++){
ret[i]=deep?dojo.lang.shallowCopy(obj[i],deep):obj[i];
}
}else{
ret=obj;
}
}
return ret;
};
dojo.lang.firstValued=function(){
for(var i=0;i<arguments.length;i++){
if(typeof arguments[i]!="undefined"){
return arguments[i];
}
}
return undefined;
};
dojo.lang.getObjPathValue=function(_1d8,_1d9,_1da){
with(dojo.parseObjPath(_1d8,_1d9,_1da)){
return dojo.evalProp(prop,obj,_1da);
}
};
dojo.lang.setObjPathValue=function(_1db,_1dc,_1dd,_1de){
if(arguments.length<4){
_1de=true;
}
with(dojo.parseObjPath(_1db,_1dd,_1de)){
if(obj&&(_1de||(prop in obj))){
obj[prop]=_1dc;
}
}
};
dojo.provide("dojo.lang.declare");
dojo.lang.declare=function(_1df,_1e0,init,_1e2){
if((dojo.lang.isFunction(_1e2))||((!_1e2)&&(!dojo.lang.isFunction(init)))){
var temp=_1e2;
_1e2=init;
init=temp;
}
var _1e4=[];
if(dojo.lang.isArray(_1e0)){
_1e4=_1e0;
_1e0=_1e4.shift();
}
if(!init){
init=dojo.evalObjPath(_1df,false);
if((init)&&(!dojo.lang.isFunction(init))){
init=null;
}
}
var ctor=dojo.lang.declare._makeConstructor();
var scp=(_1e0?_1e0.prototype:null);
if(scp){
scp.prototyping=true;
ctor.prototype=new _1e0();
scp.prototyping=false;
}
ctor.superclass=scp;
ctor.mixins=_1e4;
for(var i=0,l=_1e4.length;i<l;i++){
dojo.lang.extend(ctor,_1e4[i].prototype);
}
ctor.prototype.initializer=null;
ctor.prototype.declaredClass=_1df;
if(dojo.lang.isArray(_1e2)){
dojo.lang.extend.apply(dojo.lang,[ctor].concat(_1e2));
}else{
dojo.lang.extend(ctor,(_1e2)||{});
}
dojo.lang.extend(ctor,dojo.lang.declare.base);
ctor.prototype.constructor=ctor;
ctor.prototype.initializer=(ctor.prototype.initializer)||(init)||(function(){
});
dojo.lang.setObjPathValue(_1df,ctor,null,true);
return ctor;
};
dojo.lang.declare._makeConstructor=function(){
return function(){
var self=this._getPropContext();
var s=self.constructor.superclass;
if((s)&&(s.constructor)){
if(s.constructor==arguments.callee){
this.inherited("constructor",arguments);
}else{
this._inherited(s,"constructor",arguments);
}
}
var m=(self.constructor.mixins)||([]);
for(var i=0,l=m.length;i<l;i++){
(((m[i].prototype)&&(m[i].prototype.initializer))||(m[i])).apply(this,arguments);
}
if((!this.prototyping)&&(self.initializer)){
self.initializer.apply(this,arguments);
}
};
};
dojo.lang.declare.base={_getPropContext:function(){
return (this.___proto||this);
},_inherited:function(_1ec,_1ed,args){
var _1ef,stack=this.___proto;
this.___proto=_1ec;
try{
_1ef=_1ec[_1ed].apply(this,(args||[]));
}
catch(e){
throw e;
}
finally{
this.___proto=stack;
}
return _1ef;
},inheritedFrom:function(ctor,prop,args){
var p=((ctor)&&(ctor.prototype)&&(ctor.prototype[prop]));
return (dojo.lang.isFunction(p)?p.apply(this,(args||[])):p);
},inherited:function(prop,args){
var p=this._getPropContext();
do{
if((!p.constructor)||(!p.constructor.superclass)){
return;
}
p=p.constructor.superclass;
}while(!(prop in p));
return (dojo.lang.isFunction(p[prop])?this._inherited(p,prop,args):p[prop]);
}};
dojo.declare=dojo.lang.declare;
dojo.provide("dojo.namespace");
dojo["namespace"]={dojo:"dojo",namespaces:{},failed:{},loading:{},loaded:{},register:function(name,_1f8,_1f9,_1fa){
if((!_1fa)&&(!this.namespaces[name])){
this.namespaces[name]=new dojo["namespace"].Namespace(name,_1f8,_1f9);
}
},allow:function(name){
if(this.failed[name]){
return false;
}
var excl=djConfig.excludeNamespace;
if((excl)&&(dojo.lang.inArray(excl,name))){
return false;
}
var incl=djConfig.includeNamespace;
return ((name==this.dojo)||(!incl)||(inArray(incl,name)));
},get:function(name){
return this.namespaces[name];
},require:function(name){
var ns=this.namespaces[name];
if((ns)&&(this.loaded[name])){
return ns;
}
if(!this.allow(name)){
return false;
}
if(this.loading[name]){
dojo.debug("dojo.namespace.require: re-entrant request to load namespace \""+name+"\" must fail.");
return false;
}
var req=dojo.require;
this.loading[name]=true;
try{
if(name==this.dojo){
req("dojo.namespaces.dojo");
}else{
if(!dojo.hostenv.moduleHasPrefix(name)){
dojo.registerModulePath(name,"../"+name);
}
req([name,"manifest"].join("."),false,true);
}
if(!this.namespaces[name]){
this.failed[name]=true;
}
}
finally{
this.loading[name]=false;
}
return this.namespaces[name];
}};
dojo.registerNamespace=function(name,_203,_204){
dojo["namespace"].register.apply(dojo["namespace"],arguments);
};
dojo.registerNamespaceResolver=function(name,_206){
var n=dojo["namespace"].namespaces[name];
if(n){
n.resolver=_206;
}
};
dojo.registerNamespaceManifest=function(_208,path,name,_20b,_20c){
dojo.registerModulePath(name,path);
dojo.registerNamespace(name,_20b,_20c);
};
dojo.defineNamespace=function(_20d,_20e,_20f,_210,_211){
dojo.deprecated("dojo.defineNamespace"," is replaced by other systems. See the Dojo Wiki [http://dojo.jot.com/WikiHome/Modules & Namespaces].","0.5");
dojo.registerNamespaceManifest(_20d,_20e,_20f,_211,_210);
};
dojo["namespace"].Namespace=function(name,_213,_214){
this.name=name;
this.module=_213;
this.resolver=_214;
};
dojo["namespace"].Namespace.prototype._loaded={};
dojo["namespace"].Namespace.prototype._failed={};
dojo["namespace"].Namespace.prototype.resolve=function(name,_216,_217){
if(!this.resolver){
return false;
}
var _218=this.resolver(name,_216);
if((_218)&&(!this._loaded[_218])&&(!this._failed[_218])){
var req=dojo.require;
req(_218,false,true);
if(dojo.hostenv.findModule(_218,false)){
this._loaded[_218]=true;
}else{
if(!_217){
dojo.raise("dojo.namespace.Namespace.resolve: module '"+_218+"' not found after loading via namespace '"+this.name+"'");
}
this._failed[_218]=true;
}
}
return Boolean(this._loaded[_218]);
};
dojo.registerNamespace("dojo","dojo.widget");
dojo.provide("dojo.event.common");
dojo.event=new function(){
this.canTimeout=dojo.lang.isFunction(dj_global["setTimeout"])||dojo.lang.isAlien(dj_global["setTimeout"]);
function interpolateArgs(args,_21b){
var dl=dojo.lang;
var ao={srcObj:dj_global,srcFunc:null,adviceObj:dj_global,adviceFunc:null,aroundObj:null,aroundFunc:null,adviceType:(args.length>2)?args[0]:"after",precedence:"last",once:false,delay:null,rate:0,adviceMsg:false};
switch(args.length){
case 0:
return;
case 1:
return;
case 2:
ao.srcFunc=args[0];
ao.adviceFunc=args[1];
break;
case 3:
if((dl.isObject(args[0]))&&(dl.isString(args[1]))&&(dl.isString(args[2]))){
ao.adviceType="after";
ao.srcObj=args[0];
ao.srcFunc=args[1];
ao.adviceFunc=args[2];
}else{
if((dl.isString(args[1]))&&(dl.isString(args[2]))){
ao.srcFunc=args[1];
ao.adviceFunc=args[2];
}else{
if((dl.isObject(args[0]))&&(dl.isString(args[1]))&&(dl.isFunction(args[2]))){
ao.adviceType="after";
ao.srcObj=args[0];
ao.srcFunc=args[1];
var _21e=dl.nameAnonFunc(args[2],ao.adviceObj,_21b);
ao.adviceFunc=_21e;
}else{
if((dl.isFunction(args[0]))&&(dl.isObject(args[1]))&&(dl.isString(args[2]))){
ao.adviceType="after";
ao.srcObj=dj_global;
var _21e=dl.nameAnonFunc(args[0],ao.srcObj,_21b);
ao.srcFunc=_21e;
ao.adviceObj=args[1];
ao.adviceFunc=args[2];
}
}
}
}
break;
case 4:
if((dl.isObject(args[0]))&&(dl.isObject(args[2]))){
ao.adviceType="after";
ao.srcObj=args[0];
ao.srcFunc=args[1];
ao.adviceObj=args[2];
ao.adviceFunc=args[3];
}else{
if((dl.isString(args[0]))&&(dl.isString(args[1]))&&(dl.isObject(args[2]))){
ao.adviceType=args[0];
ao.srcObj=dj_global;
ao.srcFunc=args[1];
ao.adviceObj=args[2];
ao.adviceFunc=args[3];
}else{
if((dl.isString(args[0]))&&(dl.isFunction(args[1]))&&(dl.isObject(args[2]))){
ao.adviceType=args[0];
ao.srcObj=dj_global;
var _21e=dl.nameAnonFunc(args[1],dj_global,_21b);
ao.srcFunc=_21e;
ao.adviceObj=args[2];
ao.adviceFunc=args[3];
}else{
if((dl.isString(args[0]))&&(dl.isObject(args[1]))&&(dl.isString(args[2]))&&(dl.isFunction(args[3]))){
ao.srcObj=args[1];
ao.srcFunc=args[2];
var _21e=dl.nameAnonFunc(args[3],dj_global,_21b);
ao.adviceObj=dj_global;
ao.adviceFunc=_21e;
}else{
if(dl.isObject(args[1])){
ao.srcObj=args[1];
ao.srcFunc=args[2];
ao.adviceObj=dj_global;
ao.adviceFunc=args[3];
}else{
if(dl.isObject(args[2])){
ao.srcObj=dj_global;
ao.srcFunc=args[1];
ao.adviceObj=args[2];
ao.adviceFunc=args[3];
}else{
ao.srcObj=ao.adviceObj=ao.aroundObj=dj_global;
ao.srcFunc=args[1];
ao.adviceFunc=args[2];
ao.aroundFunc=args[3];
}
}
}
}
}
}
break;
case 6:
ao.srcObj=args[1];
ao.srcFunc=args[2];
ao.adviceObj=args[3];
ao.adviceFunc=args[4];
ao.aroundFunc=args[5];
ao.aroundObj=dj_global;
break;
default:
ao.srcObj=args[1];
ao.srcFunc=args[2];
ao.adviceObj=args[3];
ao.adviceFunc=args[4];
ao.aroundObj=args[5];
ao.aroundFunc=args[6];
ao.once=args[7];
ao.delay=args[8];
ao.rate=args[9];
ao.adviceMsg=args[10];
break;
}
if(dl.isFunction(ao.aroundFunc)){
var _21e=dl.nameAnonFunc(ao.aroundFunc,ao.aroundObj,_21b);
ao.aroundFunc=_21e;
}
if(dl.isFunction(ao.srcFunc)){
ao.srcFunc=dl.getNameInObj(ao.srcObj,ao.srcFunc);
}
if(dl.isFunction(ao.adviceFunc)){
ao.adviceFunc=dl.getNameInObj(ao.adviceObj,ao.adviceFunc);
}
if((ao.aroundObj)&&(dl.isFunction(ao.aroundFunc))){
ao.aroundFunc=dl.getNameInObj(ao.aroundObj,ao.aroundFunc);
}
if(!ao.srcObj){
dojo.raise("bad srcObj for srcFunc: "+ao.srcFunc);
}
if(!ao.adviceObj){
dojo.raise("bad adviceObj for adviceFunc: "+ao.adviceFunc);
}
if(!ao.adviceFunc){
dojo.debug("bad adviceFunc for srcFunc: "+ao.srcFunc);
dojo.debugShallow(ao);
}
return ao;
}
this.connect=function(){
if(arguments.length==1){
var ao=arguments[0];
}else{
var ao=interpolateArgs(arguments,true);
}
if(dojo.lang.isString(ao.srcFunc)&&(ao.srcFunc.toLowerCase()=="onkey")){
if(dojo.render.html.ie){
ao.srcFunc="onkeydown";
this.connect(ao);
}
ao.srcFunc="onkeypress";
}
if(dojo.lang.isArray(ao.srcObj)&&ao.srcObj!=""){
var _220={};
for(var x in ao){
_220[x]=ao[x];
}
var mjps=[];
dojo.lang.forEach(ao.srcObj,function(src){
if((dojo.render.html.capable)&&(dojo.lang.isString(src))){
src=dojo.byId(src);
}
_220.srcObj=src;
mjps.push(dojo.event.connect.call(dojo.event,_220));
});
return mjps;
}
var mjp=dojo.event.MethodJoinPoint.getForMethod(ao.srcObj,ao.srcFunc);
if(ao.adviceFunc){
var mjp2=dojo.event.MethodJoinPoint.getForMethod(ao.adviceObj,ao.adviceFunc);
}
mjp.kwAddAdvice(ao);
return mjp;
};
this.log=function(a1,a2){
var _228;
if((arguments.length==1)&&(typeof a1=="object")){
_228=a1;
}else{
_228={srcObj:a1,srcFunc:a2};
}
_228.adviceFunc=function(){
var _229=[];
for(var x=0;x<arguments.length;x++){
_229.push(arguments[x]);
}
dojo.debug("("+_228.srcObj+")."+_228.srcFunc,":",_229.join(", "));
};
this.kwConnect(_228);
};
this.connectBefore=function(){
var args=["before"];
for(var i=0;i<arguments.length;i++){
args.push(arguments[i]);
}
return this.connect.apply(this,args);
};
this.connectAround=function(){
var args=["around"];
for(var i=0;i<arguments.length;i++){
args.push(arguments[i]);
}
return this.connect.apply(this,args);
};
this.connectOnce=function(){
var ao=interpolateArgs(arguments,true);
ao.once=true;
return this.connect(ao);
};
this._kwConnectImpl=function(_230,_231){
var fn=(_231)?"disconnect":"connect";
if(typeof _230["srcFunc"]=="function"){
_230.srcObj=_230["srcObj"]||dj_global;
var _233=dojo.lang.nameAnonFunc(_230.srcFunc,_230.srcObj,true);
_230.srcFunc=_233;
}
if(typeof _230["adviceFunc"]=="function"){
_230.adviceObj=_230["adviceObj"]||dj_global;
var _233=dojo.lang.nameAnonFunc(_230.adviceFunc,_230.adviceObj,true);
_230.adviceFunc=_233;
}
return dojo.event[fn]((_230["type"]||_230["adviceType"]||"after"),_230["srcObj"]||dj_global,_230["srcFunc"],_230["adviceObj"]||_230["targetObj"]||dj_global,_230["adviceFunc"]||_230["targetFunc"],_230["aroundObj"],_230["aroundFunc"],_230["once"],_230["delay"],_230["rate"],_230["adviceMsg"]||false);
};
this.kwConnect=function(_234){
return this._kwConnectImpl(_234,false);
};
this.disconnect=function(){
if(arguments.length==1){
var ao=arguments[0];
}else{
var ao=interpolateArgs(arguments,true);
}
if(!ao.adviceFunc){
return;
}
if(dojo.lang.isString(ao.srcFunc)&&(ao.srcFunc.toLowerCase()=="onkey")){
if(dojo.render.html.ie){
ao.srcFunc="onkeydown";
this.disconnect(ao);
}
ao.srcFunc="onkeypress";
}
var mjp=dojo.event.MethodJoinPoint.getForMethod(ao.srcObj,ao.srcFunc);
return mjp.removeAdvice(ao.adviceObj,ao.adviceFunc,ao.adviceType,ao.once);
};
this.kwDisconnect=function(_237){
return this._kwConnectImpl(_237,true);
};
};
dojo.event.MethodInvocation=function(_238,obj,args){
this.jp_=_238;
this.object=obj;
this.args=[];
for(var x=0;x<args.length;x++){
this.args[x]=args[x];
}
this.around_index=-1;
};
dojo.event.MethodInvocation.prototype.proceed=function(){
this.around_index++;
if(this.around_index>=this.jp_.around.length){
return this.jp_.object[this.jp_.methodname].apply(this.jp_.object,this.args);
}else{
var ti=this.jp_.around[this.around_index];
var mobj=ti[0]||dj_global;
var meth=ti[1];
return mobj[meth].call(mobj,this);
}
};
dojo.event.MethodJoinPoint=function(obj,_240){
this.object=obj||dj_global;
this.methodname=_240;
this.methodfunc=this.object[_240];
this.before=[];
this.after=[];
this.around=[];
};
dojo.event.MethodJoinPoint.getForMethod=function(obj,_242){
if(!obj){
obj=dj_global;
}
if(!obj[_242]){
obj[_242]=function(){
};
if(!obj[_242]){
dojo.raise("Cannot set do-nothing method on that object "+_242);
}
}else{
if((!dojo.lang.isFunction(obj[_242]))&&(!dojo.lang.isAlien(obj[_242]))){
return null;
}
}
var _243=_242+"$joinpoint";
var _244=_242+"$joinpoint$method";
var _245=obj[_243];
if(!_245){
var _246=false;
if(dojo.event["browser"]){
if((obj["attachEvent"])||(obj["nodeType"])||(obj["addEventListener"])){
_246=true;
dojo.event.browser.addClobberNodeAttrs(obj,[_243,_244,_242]);
}
}
var _247=obj[_242].length;
obj[_244]=obj[_242];
_245=obj[_243]=new dojo.event.MethodJoinPoint(obj,_244);
obj[_242]=function(){
var args=[];
if((_246)&&(!arguments.length)){
var evt=null;
try{
if(obj.ownerDocument){
evt=obj.ownerDocument.parentWindow.event;
}else{
if(obj.documentElement){
evt=obj.documentElement.ownerDocument.parentWindow.event;
}else{
if(obj.event){
evt=obj.event;
}else{
evt=window.event;
}
}
}
}
catch(e){
evt=window.event;
}
if(evt){
args.push(dojo.event.browser.fixEvent(evt,this));
}
}else{
for(var x=0;x<arguments.length;x++){
if((x==0)&&(_246)&&(dojo.event.browser.isEvent(arguments[x]))){
args.push(dojo.event.browser.fixEvent(arguments[x],this));
}else{
args.push(arguments[x]);
}
}
}
return _245.run.apply(_245,args);
};
obj[_242].__preJoinArity=_247;
}
return _245;
};
dojo.lang.extend(dojo.event.MethodJoinPoint,{unintercept:function(){
this.object[this.methodname]=this.methodfunc;
this.before=[];
this.after=[];
this.around=[];
},disconnect:dojo.lang.forward("unintercept"),run:function(){
var obj=this.object||dj_global;
var args=arguments;
var _24d=[];
for(var x=0;x<args.length;x++){
_24d[x]=args[x];
}
var _24f=function(marr){
if(!marr){
dojo.debug("Null argument to unrollAdvice()");
return;
}
var _251=marr[0]||dj_global;
var _252=marr[1];
if(!_251[_252]){
dojo.raise("function \""+_252+"\" does not exist on \""+_251+"\"");
}
var _253=marr[2]||dj_global;
var _254=marr[3];
var msg=marr[6];
var _256;
var to={args:[],jp_:this,object:obj,proceed:function(){
return _251[_252].apply(_251,to.args);
}};
to.args=_24d;
var _258=parseInt(marr[4]);
var _259=((!isNaN(_258))&&(marr[4]!==null)&&(typeof marr[4]!="undefined"));
if(marr[5]){
var rate=parseInt(marr[5]);
var cur=new Date();
var _25c=false;
if((marr["last"])&&((cur-marr.last)<=rate)){
if(dojo.event.canTimeout){
if(marr["delayTimer"]){
clearTimeout(marr.delayTimer);
}
var tod=parseInt(rate*2);
var mcpy=dojo.lang.shallowCopy(marr);
marr.delayTimer=setTimeout(function(){
mcpy[5]=0;
_24f(mcpy);
},tod);
}
return;
}else{
marr.last=cur;
}
}
if(_254){
_253[_254].call(_253,to);
}else{
if((_259)&&((dojo.render.html)||(dojo.render.svg))){
dj_global["setTimeout"](function(){
if(msg){
_251[_252].call(_251,to);
}else{
_251[_252].apply(_251,args);
}
},_258);
}else{
if(msg){
_251[_252].call(_251,to);
}else{
_251[_252].apply(_251,args);
}
}
}
};
if(this.before.length>0){
dojo.lang.forEach(this.before.concat(new Array()),_24f);
}
var _25f;
if(this.around.length>0){
var mi=new dojo.event.MethodInvocation(this,obj,args);
_25f=mi.proceed();
}else{
if(this.methodfunc){
_25f=this.object[this.methodname].apply(this.object,args);
}
}
if(this.after.length>0){
dojo.lang.forEach(this.after.concat(new Array()),_24f);
}
return (this.methodfunc)?_25f:null;
},getArr:function(kind){
var arr=this.after;
if((typeof kind=="string")&&(kind.indexOf("before")!=-1)){
arr=this.before;
}else{
if(kind=="around"){
arr=this.around;
}
}
return arr;
},kwAddAdvice:function(args){
this.addAdvice(args["adviceObj"],args["adviceFunc"],args["aroundObj"],args["aroundFunc"],args["adviceType"],args["precedence"],args["once"],args["delay"],args["rate"],args["adviceMsg"]);
},addAdvice:function(_264,_265,_266,_267,_268,_269,once,_26b,rate,_26d){
var arr=this.getArr(_268);
if(!arr){
dojo.raise("bad this: "+this);
}
var ao=[_264,_265,_266,_267,_26b,rate,_26d];
if(once){
if(this.hasAdvice(_264,_265,_268,arr)>=0){
return;
}
}
if(_269=="first"){
arr.unshift(ao);
}else{
arr.push(ao);
}
},hasAdvice:function(_270,_271,_272,arr){
if(!arr){
arr=this.getArr(_272);
}
var ind=-1;
for(var x=0;x<arr.length;x++){
var aao=(typeof _271=="object")?(new String(_271)).toString():_271;
var a1o=(typeof arr[x][1]=="object")?(new String(arr[x][1])).toString():arr[x][1];
if((arr[x][0]==_270)&&(a1o==aao)){
ind=x;
}
}
return ind;
},removeAdvice:function(_278,_279,_27a,once){
var arr=this.getArr(_27a);
var ind=this.hasAdvice(_278,_279,_27a,arr);
if(ind==-1){
return false;
}
while(ind!=-1){
arr.splice(ind,1);
if(once){
break;
}
ind=this.hasAdvice(_278,_279,_27a,arr);
}
return true;
}});
dojo.provide("dojo.event.topic");
dojo.event.topic=new function(){
this.topics={};
this.getTopic=function(_27e){
if(!this.topics[_27e]){
this.topics[_27e]=new this.TopicImpl(_27e);
}
return this.topics[_27e];
};
this.registerPublisher=function(_27f,obj,_281){
var _27f=this.getTopic(_27f);
_27f.registerPublisher(obj,_281);
};
this.subscribe=function(_282,obj,_284){
var _282=this.getTopic(_282);
_282.subscribe(obj,_284);
};
this.unsubscribe=function(_285,obj,_287){
var _285=this.getTopic(_285);
_285.unsubscribe(obj,_287);
};
this.destroy=function(_288){
this.getTopic(_288).destroy();
delete this.topics[_288];
};
this.publishApply=function(_289,args){
var _289=this.getTopic(_289);
_289.sendMessage.apply(_289,args);
};
this.publish=function(_28b,_28c){
var _28b=this.getTopic(_28b);
var args=[];
for(var x=1;x<arguments.length;x++){
args.push(arguments[x]);
}
_28b.sendMessage.apply(_28b,args);
};
};
dojo.event.topic.TopicImpl=function(_28f){
this.topicName=_28f;
this.subscribe=function(_290,_291){
var tf=_291||_290;
var to=(!_291)?dj_global:_290;
dojo.event.kwConnect({srcObj:this,srcFunc:"sendMessage",adviceObj:to,adviceFunc:tf});
};
this.unsubscribe=function(_294,_295){
var tf=(!_295)?_294:_295;
var to=(!_295)?null:_294;
dojo.event.kwDisconnect({srcObj:this,srcFunc:"sendMessage",adviceObj:to,adviceFunc:tf});
};
this.destroy=function(){
dojo.event.MethodJoinPoint.getForMethod(this,"sendMessage").disconnect();
};
this.registerPublisher=function(_298,_299){
dojo.event.connect(_298,_299,this,"sendMessage");
};
this.sendMessage=function(_29a){
};
};
dojo.provide("dojo.event.browser");
dojo._ie_clobber=new function(){
this.clobberNodes=[];
function nukeProp(node,prop){
try{
node[prop]=null;
}
catch(e){
}
try{
delete node[prop];
}
catch(e){
}
try{
node.removeAttribute(prop);
}
catch(e){
}
}
this.clobber=function(_29d){
var na;
var tna;
if(_29d){
tna=_29d.all||_29d.getElementsByTagName("*");
na=[_29d];
for(var x=0;x<tna.length;x++){
if(tna[x]["__doClobber__"]){
na.push(tna[x]);
}
}
}else{
try{
window.onload=null;
}
catch(e){
}
na=(this.clobberNodes.length)?this.clobberNodes:document.all;
}
tna=null;
var _2a1={};
for(var i=na.length-1;i>=0;i=i-1){
var el=na[i];
try{
if(el&&el["__clobberAttrs__"]){
for(var j=0;j<el.__clobberAttrs__.length;j++){
nukeProp(el,el.__clobberAttrs__[j]);
}
nukeProp(el,"__clobberAttrs__");
nukeProp(el,"__doClobber__");
}
}
catch(e){
}
}
na=null;
};
};
if(dojo.render.html.ie){
dojo.addOnUnload(function(){
dojo._ie_clobber.clobber();
try{
if((dojo["widget"])&&(dojo.widget["manager"])){
dojo.widget.manager.destroyAll();
}
}
catch(e){
}
try{
window.onload=null;
}
catch(e){
}
try{
window.onunload=null;
}
catch(e){
}
dojo._ie_clobber.clobberNodes=[];
});
}
dojo.event.browser=new function(){
var _2a5=0;
this.clean=function(node){
if(dojo.render.html.ie){
dojo._ie_clobber.clobber(node);
}
};
this.addClobberNode=function(node){
if(!dojo.render.html.ie){
return;
}
if(!node["__doClobber__"]){
node.__doClobber__=true;
dojo._ie_clobber.clobberNodes.push(node);
node.__clobberAttrs__=[];
}
};
this.addClobberNodeAttrs=function(node,_2a9){
if(!dojo.render.html.ie){
return;
}
this.addClobberNode(node);
for(var x=0;x<_2a9.length;x++){
node.__clobberAttrs__.push(_2a9[x]);
}
};
this.removeListener=function(node,_2ac,fp,_2ae){
if(!_2ae){
var _2ae=false;
}
_2ac=_2ac.toLowerCase();
if((_2ac=="onkey")||(_2ac=="key")){
if(dojo.render.html.ie){
this.removeListener(node,"onkeydown",fp,_2ae);
}
_2ac="onkeypress";
}
if(_2ac.substr(0,2)=="on"){
_2ac=_2ac.substr(2);
}
if(node.removeEventListener){
node.removeEventListener(_2ac,fp,_2ae);
}
};
this.addListener=function(node,_2b0,fp,_2b2,_2b3){
if(!node){
return;
}
if(!_2b2){
var _2b2=false;
}
_2b0=_2b0.toLowerCase();
if((_2b0=="onkey")||(_2b0=="key")){
if(dojo.render.html.ie){
this.addListener(node,"onkeydown",fp,_2b2,_2b3);
}
_2b0="onkeypress";
}
if(_2b0.substr(0,2)!="on"){
_2b0="on"+_2b0;
}
if(!_2b3){
var _2b4=function(evt){
if(!evt){
evt=window.event;
}
var ret=fp(dojo.event.browser.fixEvent(evt,this));
if(_2b2){
dojo.event.browser.stopEvent(evt);
}
return ret;
};
}else{
_2b4=fp;
}
if(node.addEventListener){
node.addEventListener(_2b0.substr(2),_2b4,_2b2);
return _2b4;
}else{
if(typeof node[_2b0]=="function"){
var _2b7=node[_2b0];
node[_2b0]=function(e){
_2b7(e);
return _2b4(e);
};
}else{
node[_2b0]=_2b4;
}
if(dojo.render.html.ie){
this.addClobberNodeAttrs(node,[_2b0]);
}
return _2b4;
}
};
this.isEvent=function(obj){
return (typeof obj!="undefined")&&(typeof Event!="undefined")&&(obj.eventPhase);
};
this.currentEvent=null;
this.callListener=function(_2ba,_2bb){
if(typeof _2ba!="function"){
dojo.raise("listener not a function: "+_2ba);
}
dojo.event.browser.currentEvent.currentTarget=_2bb;
return _2ba.call(_2bb,dojo.event.browser.currentEvent);
};
this.stopPropagation=function(){
dojo.event.browser.currentEvent.cancelBubble=true;
};
this.preventDefault=function(){
dojo.event.browser.currentEvent.returnValue=false;
};
this.keys={KEY_BACKSPACE:8,KEY_TAB:9,KEY_CLEAR:12,KEY_ENTER:13,KEY_SHIFT:16,KEY_CTRL:17,KEY_ALT:18,KEY_PAUSE:19,KEY_CAPS_LOCK:20,KEY_ESCAPE:27,KEY_SPACE:32,KEY_PAGE_UP:33,KEY_PAGE_DOWN:34,KEY_END:35,KEY_HOME:36,KEY_LEFT_ARROW:37,KEY_UP_ARROW:38,KEY_RIGHT_ARROW:39,KEY_DOWN_ARROW:40,KEY_INSERT:45,KEY_DELETE:46,KEY_HELP:47,KEY_LEFT_WINDOW:91,KEY_RIGHT_WINDOW:92,KEY_SELECT:93,KEY_NUMPAD_0:96,KEY_NUMPAD_1:97,KEY_NUMPAD_2:98,KEY_NUMPAD_3:99,KEY_NUMPAD_4:100,KEY_NUMPAD_5:101,KEY_NUMPAD_6:102,KEY_NUMPAD_7:103,KEY_NUMPAD_8:104,KEY_NUMPAD_9:105,KEY_NUMPAD_MULTIPLY:106,KEY_NUMPAD_PLUS:107,KEY_NUMPAD_ENTER:108,KEY_NUMPAD_MINUS:109,KEY_NUMPAD_PERIOD:110,KEY_NUMPAD_DIVIDE:111,KEY_F1:112,KEY_F2:113,KEY_F3:114,KEY_F4:115,KEY_F5:116,KEY_F6:117,KEY_F7:118,KEY_F8:119,KEY_F9:120,KEY_F10:121,KEY_F11:122,KEY_F12:123,KEY_F13:124,KEY_F14:125,KEY_F15:126,KEY_NUM_LOCK:144,KEY_SCROLL_LOCK:145};
this.revKeys=[];
for(var key in this.keys){
this.revKeys[this.keys[key]]=key;
}
this.fixEvent=function(evt,_2be){
if(!evt){
if(window["event"]){
evt=window.event;
}
}
if((evt["type"])&&(evt["type"].indexOf("key")==0)){
evt.keys=this.revKeys;
for(var key in this.keys){
evt[key]=this.keys[key];
}
if(evt["type"]=="keydown"&&dojo.render.html.ie){
switch(evt.keyCode){
case evt.KEY_SHIFT:
case evt.KEY_CTRL:
case evt.KEY_ALT:
case evt.KEY_CAPS_LOCK:
case evt.KEY_LEFT_WINDOW:
case evt.KEY_RIGHT_WINDOW:
case evt.KEY_SELECT:
case evt.KEY_NUM_LOCK:
case evt.KEY_SCROLL_LOCK:
case evt.KEY_NUMPAD_0:
case evt.KEY_NUMPAD_1:
case evt.KEY_NUMPAD_2:
case evt.KEY_NUMPAD_3:
case evt.KEY_NUMPAD_4:
case evt.KEY_NUMPAD_5:
case evt.KEY_NUMPAD_6:
case evt.KEY_NUMPAD_7:
case evt.KEY_NUMPAD_8:
case evt.KEY_NUMPAD_9:
case evt.KEY_NUMPAD_PERIOD:
break;
case evt.KEY_NUMPAD_MULTIPLY:
case evt.KEY_NUMPAD_PLUS:
case evt.KEY_NUMPAD_ENTER:
case evt.KEY_NUMPAD_MINUS:
case evt.KEY_NUMPAD_DIVIDE:
break;
case evt.KEY_PAUSE:
case evt.KEY_TAB:
case evt.KEY_BACKSPACE:
case evt.KEY_ENTER:
case evt.KEY_ESCAPE:
case evt.KEY_PAGE_UP:
case evt.KEY_PAGE_DOWN:
case evt.KEY_END:
case evt.KEY_HOME:
case evt.KEY_LEFT_ARROW:
case evt.KEY_UP_ARROW:
case evt.KEY_RIGHT_ARROW:
case evt.KEY_DOWN_ARROW:
case evt.KEY_INSERT:
case evt.KEY_DELETE:
case evt.KEY_F1:
case evt.KEY_F2:
case evt.KEY_F3:
case evt.KEY_F4:
case evt.KEY_F5:
case evt.KEY_F6:
case evt.KEY_F7:
case evt.KEY_F8:
case evt.KEY_F9:
case evt.KEY_F10:
case evt.KEY_F11:
case evt.KEY_F12:
case evt.KEY_F12:
case evt.KEY_F13:
case evt.KEY_F14:
case evt.KEY_F15:
case evt.KEY_CLEAR:
case evt.KEY_HELP:
evt.key=evt.keyCode;
break;
default:
if(evt.ctrlKey||evt.altKey){
var _2c0=evt.keyCode;
if(_2c0>=65&&_2c0<=90&&evt.shiftKey==false){
_2c0+=32;
}
if(_2c0>=1&&_2c0<=26&&evt.ctrlKey){
_2c0+=96;
}
evt.key=String.fromCharCode(_2c0);
}
}
}else{
if(evt["type"]=="keypress"){
if(dojo.render.html.opera){
if(evt.which==0){
evt.key=evt.keyCode;
}else{
if(evt.which>0){
switch(evt.which){
case evt.KEY_SHIFT:
case evt.KEY_CTRL:
case evt.KEY_ALT:
case evt.KEY_CAPS_LOCK:
case evt.KEY_NUM_LOCK:
case evt.KEY_SCROLL_LOCK:
break;
case evt.KEY_PAUSE:
case evt.KEY_TAB:
case evt.KEY_BACKSPACE:
case evt.KEY_ENTER:
case evt.KEY_ESCAPE:
evt.key=evt.which;
break;
default:
var _2c0=evt.which;
if((evt.ctrlKey||evt.altKey||evt.metaKey)&&(evt.which>=65&&evt.which<=90&&evt.shiftKey==false)){
_2c0+=32;
}
evt.key=String.fromCharCode(_2c0);
}
}
}
}else{
if(dojo.render.html.ie){
if(!evt.ctrlKey&&!evt.altKey&&evt.keyCode>=evt.KEY_SPACE){
evt.key=String.fromCharCode(evt.keyCode);
}
}else{
if(dojo.render.html.safari){
switch(evt.keyCode){
case 63232:
evt.key=evt.KEY_UP_ARROW;
break;
case 63233:
evt.key=evt.KEY_DOWN_ARROW;
break;
case 63234:
evt.key=evt.KEY_LEFT_ARROW;
break;
case 63235:
evt.key=evt.KEY_RIGHT_ARROW;
break;
default:
evt.key=evt.charCode>0?String.fromCharCode(evt.charCode):evt.keyCode;
}
}else{
evt.key=evt.charCode>0?String.fromCharCode(evt.charCode):evt.keyCode;
}
}
}
}
}
}
if(dojo.render.html.ie){
if(!evt.target){
evt.target=evt.srcElement;
}
if(!evt.currentTarget){
evt.currentTarget=(_2be?_2be:evt.srcElement);
}
if(!evt.layerX){
evt.layerX=evt.offsetX;
}
if(!evt.layerY){
evt.layerY=evt.offsetY;
}
var doc=(evt.srcElement&&evt.srcElement.ownerDocument)?evt.srcElement.ownerDocument:document;
var _2c2=((dojo.render.html.ie55)||(doc["compatMode"]=="BackCompat"))?doc.body:doc.documentElement;
if(!evt.pageX){
evt.pageX=evt.clientX+(_2c2.scrollLeft||0);
}
if(!evt.pageY){
evt.pageY=evt.clientY+(_2c2.scrollTop||0);
}
if(evt.type=="mouseover"){
evt.relatedTarget=evt.fromElement;
}
if(evt.type=="mouseout"){
evt.relatedTarget=evt.toElement;
}
this.currentEvent=evt;
evt.callListener=this.callListener;
evt.stopPropagation=this.stopPropagation;
evt.preventDefault=this.preventDefault;
}
return evt;
};
this.stopEvent=function(ev){
if(window.event){
ev.returnValue=false;
ev.cancelBubble=true;
}else{
ev.preventDefault();
ev.stopPropagation();
}
};
};
dojo.provide("dojo.event.*");
dojo.provide("dojo.widget.Manager");
dojo.widget.manager=new function(){
this.widgets=[];
this.widgetIds=[];
this.topWidgets={};
var _2c4={};
var _2c5=[];
this.getUniqueId=function(_2c6){
return _2c6+"_"+(_2c4[_2c6]!=undefined?++_2c4[_2c6]:_2c4[_2c6]=0);
};
this.add=function(_2c7){
this.widgets.push(_2c7);
if(!_2c7.extraArgs["id"]){
_2c7.extraArgs["id"]=_2c7.extraArgs["ID"];
}
if(_2c7.widgetId==""){
if(_2c7["id"]){
_2c7.widgetId=_2c7["id"];
}else{
if(_2c7.extraArgs["id"]){
_2c7.widgetId=_2c7.extraArgs["id"];
}else{
_2c7.widgetId=this.getUniqueId(_2c7.widgetType);
}
}
}
if(this.widgetIds[_2c7.widgetId]){
dojo.debug("widget ID collision on ID: "+_2c7.widgetId);
}
this.widgetIds[_2c7.widgetId]=_2c7;
};
this.destroyAll=function(){
for(var x=this.widgets.length-1;x>=0;x--){
try{
this.widgets[x].destroy(true);
delete this.widgets[x];
}
catch(e){
}
}
};
this.remove=function(_2c9){
if(dojo.lang.isNumber(_2c9)){
var tw=this.widgets[_2c9].widgetId;
delete this.widgetIds[tw];
this.widgets.splice(_2c9,1);
}else{
this.removeById(_2c9);
}
};
this.removeById=function(id){
if(!dojo.lang.isString(id)){
id=id["widgetId"];
if(!id){
dojo.debug("invalid widget or id passed to removeById");
return;
}
}
for(var i=0;i<this.widgets.length;i++){
if(this.widgets[i].widgetId==id){
this.remove(i);
break;
}
}
};
this.getWidgetById=function(id){
if(dojo.lang.isString(id)){
return this.widgetIds[id];
}
return id;
};
this.getWidgetsByType=function(type){
var lt=type.toLowerCase();
var _2d0=(type.indexOf(":")<0?function(x){
return x.widgetType.toLowerCase();
}:function(x){
return x.getNamespacedType();
});
var ret=[];
dojo.lang.forEach(this.widgets,function(x){
if(_2d0(x)==lt){
ret.push(x);
}
});
return ret;
};
this.getWidgetsByFilter=function(_2d5,_2d6){
var ret=[];
dojo.lang.every(this.widgets,function(x){
if(_2d5(x)){
ret.push(x);
if(_2d6){
return false;
}
}
return true;
});
return (_2d6?ret[0]:ret);
};
this.getAllWidgets=function(){
return this.widgets.concat();
};
this.getWidgetByNode=function(node){
var w=this.getAllWidgets();
node=dojo.byId(node);
for(var i=0;i<w.length;i++){
if(w[i].domNode==node){
return w[i];
}
}
return null;
};
this.byId=this.getWidgetById;
this.byType=this.getWidgetsByType;
this.byFilter=this.getWidgetsByFilter;
this.byNode=this.getWidgetByNode;
var _2dc={};
var _2dd=["dojo.widget"];
for(var i=0;i<_2dd.length;i++){
_2dd[_2dd[i]]=true;
}
this.registerWidgetPackage=function(_2df){
if(!_2dd[_2df]){
_2dd[_2df]=true;
_2dd.push(_2df);
}
};
this.getWidgetPackageList=function(){
return dojo.lang.map(_2dd,function(elt){
return (elt!==true?elt:undefined);
});
};
this.getImplementation=function(_2e1,_2e2,_2e3,ns){
var impl=this.getImplementationName(_2e1,ns);
if(impl){
var ret=_2e2?new impl(_2e2):new impl();
return ret;
}
};
function buildPrefixCache(){
for(var _2e7 in dojo.render){
if(dojo.render[_2e7]["capable"]===true){
var _2e8=dojo.render[_2e7].prefixes;
for(var i=0;i<_2e8.length;i++){
_2c5.push(_2e8[i].toLowerCase());
}
}
}
}
findImplementationInModule=function(_2ea,_2eb){
if(!_2eb){
return null;
}
for(var i=0,l=_2c5.length,widgetModule;i<=l;i++){
widgetModule=(i<l?_2eb[_2c5[i]]:_2eb);
if(!widgetModule){
continue;
}
for(var name in widgetModule){
if(name.toLowerCase()==_2ea){
return widgetModule[name];
}
}
}
return null;
};
findImplementation=function(_2ee,_2ef){
var _2f0=dojo.evalObjPath(_2ef,false);
return (_2f0?findImplementationInModule(_2ee,_2f0):null);
};
this.getImplementationName=function(_2f1,ns){
var _2f3=_2f1.toLowerCase();
ns=ns||"dojo";
var imps=_2dc[ns]||(_2dc[ns]={});
var impl=imps[_2f3];
if(impl){
return impl;
}
if(!_2c5.length){
buildPrefixCache();
}
var _2f6=dojo["namespace"].get(ns);
if(!_2f6){
dojo.namespace.register(ns,ns+".widget");
_2f6=dojo["namespace"].get(ns);
}
if(_2f6){
_2f6.resolve(_2f1);
}
impl=findImplementation(_2f3,_2f6.module);
if(impl){
return (imps[_2f3]=impl);
}
_2f6=dojo["namespace"].require(ns);
if((_2f6)&&(_2f6.resolver)){
_2f6.resolve(_2f1);
impl=findImplementation(_2f3,_2f6.module);
if(impl){
return (imps[_2f3]=impl);
}
}
dojo.deprecated("dojo.widget.Manager.getImplementationName","Could not locate widget implementation for \""+_2f1+"\" in \""+_2f6.module+"\" registered to namespace \""+_2f6.name+"\". "+"Developers must specify correct namespaces for all non-Dojo widgets","0.5");
for(var i=0;i<_2dd.length;i++){
impl=findImplementation(_2f3,_2dd[i]);
if(impl){
return (imps[_2f3]=impl);
}
}
throw new Error("Could not locate widget implementation for \""+_2f1+"\" in \""+_2f6.module+"\" registered to namespace \""+_2f6.name+"\"");
};
this.resizing=false;
this.onWindowResized=function(){
if(this.resizing){
return;
}
try{
this.resizing=true;
for(var id in this.topWidgets){
var _2f9=this.topWidgets[id];
if(_2f9.checkSize){
_2f9.checkSize();
}
}
}
catch(e){
}
finally{
this.resizing=false;
}
};
if(typeof window!="undefined"){
dojo.addOnLoad(this,"onWindowResized");
dojo.event.connect(window,"onresize",this,"onWindowResized");
}
};
(function(){
var dw=dojo.widget;
var dwm=dw.manager;
var h=dojo.lang.curry(dojo.lang,"hitch",dwm);
var g=function(_2fe,_2ff){
dw[(_2ff||_2fe)]=h(_2fe);
};
g("add","addWidget");
g("destroyAll","destroyAllWidgets");
g("remove","removeWidget");
g("removeById","removeWidgetById");
g("getWidgetById");
g("getWidgetById","byId");
g("getWidgetsByType");
g("getWidgetsByFilter");
g("getWidgetsByType","byType");
g("getWidgetsByFilter","byFilter");
g("getWidgetByNode","byNode");
dw.all=function(n){
var _301=dwm.getAllWidgets.apply(dwm,arguments);
if(arguments.length>0){
return _301[n];
}
return _301;
};
g("registerWidgetPackage");
g("getImplementation","getWidgetImplementation");
g("getImplementationName","getWidgetImplementationName");
dw.widgets=dwm.widgets;
dw.widgetIds=dwm.widgetIds;
dw.root=dwm.root;
})();
dojo.provide("dojo.uri.Uri");
dojo.uri=new function(){
this.dojoUri=function(uri){
return new dojo.uri.Uri(dojo.hostenv.getBaseScriptUri(),uri);
};
this.moduleUri=function(_303,uri){
var loc=dojo.hostenv.getModulePrefix(_303);
if(!loc){
return null;
}
if(loc.lastIndexOf("/")!=loc.length-1){
loc+="/";
}
return new dojo.uri.Uri(dojo.hostenv.getBaseScriptUri()+loc,uri);
};
this.nsUri=function(ns,uri){
dojo.deprecated("dojo.uri.nsUri","replaced by dojo.uri.moduleUri","0.4");
return dojo.uri.moduleUri(ns,uri);
};
this.Uri=function(){
var uri=arguments[0];
for(var i=1;i<arguments.length;i++){
if(!arguments[i]){
continue;
}
var _30a=new dojo.uri.Uri(arguments[i].toString());
var _30b=new dojo.uri.Uri(uri.toString());
if(_30a.path==""&&_30a.scheme==null&&_30a.authority==null&&_30a.query==null){
if(_30a.fragment!=null){
_30b.fragment=_30a.fragment;
}
_30a=_30b;
}else{
if(_30a.scheme==null){
_30a.scheme=_30b.scheme;
if(_30a.authority==null){
_30a.authority=_30b.authority;
if(_30a.path.charAt(0)!="/"){
var path=_30b.path.substring(0,_30b.path.lastIndexOf("/")+1)+_30a.path;
var segs=path.split("/");
for(var j=0;j<segs.length;j++){
if(segs[j]=="."){
if(j==segs.length-1){
segs[j]="";
}else{
segs.splice(j,1);
j--;
}
}else{
if(j>0&&!(j==1&&segs[0]=="")&&segs[j]==".."&&segs[j-1]!=".."){
if(j==segs.length-1){
segs.splice(j,1);
segs[j-1]="";
}else{
segs.splice(j-1,2);
j-=2;
}
}
}
}
_30a.path=segs.join("/");
}
}
}
}
uri="";
if(_30a.scheme!=null){
uri+=_30a.scheme+":";
}
if(_30a.authority!=null){
uri+="//"+_30a.authority;
}
uri+=_30a.path;
if(_30a.query!=null){
uri+="?"+_30a.query;
}
if(_30a.fragment!=null){
uri+="#"+_30a.fragment;
}
}
this.uri=uri.toString();
var _30f="^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\\?([^#]*))?(#(.*))?$";
var r=this.uri.match(new RegExp(_30f));
this.scheme=r[2]||(r[1]?"":null);
this.authority=r[4]||(r[3]?"":null);
this.path=r[5];
this.query=r[7]||(r[6]?"":null);
this.fragment=r[9]||(r[8]?"":null);
if(this.authority!=null){
_30f="^((([^:]+:)?([^@]+))@)?([^:]*)(:([0-9]+))?$";
r=this.authority.match(new RegExp(_30f));
this.user=r[3]||null;
this.password=r[4]||null;
this.host=r[5];
this.port=r[7]||null;
}
this.toString=function(){
return this.uri;
};
};
};
dojo.provide("dojo.uri.*");
dojo.provide("dojo.html.common");
dojo.lang.mixin(dojo.html,dojo.dom);
dojo.html.body=function(){
dojo.deprecated("dojo.html.body() moved to dojo.body()","0.5");
return dojo.body();
};
dojo.html.getEventTarget=function(evt){
if(!evt){
evt=dojo.global().event||{};
}
var t=(evt.srcElement?evt.srcElement:(evt.target?evt.target:null));
while((t)&&(t.nodeType!=1)){
t=t.parentNode;
}
return t;
};
dojo.html.getViewport=function(){
var _313=dojo.global();
var _314=dojo.doc();
var w=0;
var h=0;
if(dojo.render.html.mozilla){
w=_314.documentElement.clientWidth;
h=_313.innerHeight;
}else{
if(!dojo.render.html.opera&&_313.innerWidth){
w=_313.innerWidth;
h=_313.innerHeight;
}else{
if(!dojo.render.html.opera&&dojo.exists(_314,"documentElement.clientWidth")){
var w2=_314.documentElement.clientWidth;
if(!w||w2&&w2<w){
w=w2;
}
h=_314.documentElement.clientHeight;
}else{
if(dojo.body().clientWidth){
w=dojo.body().clientWidth;
h=dojo.body().clientHeight;
}
}
}
}
return {width:w,height:h};
};
dojo.html.getScroll=function(){
var _318=dojo.global();
var _319=dojo.doc();
var top=_318.pageYOffset||_319.documentElement.scrollTop||dojo.body().scrollTop||0;
var left=_318.pageXOffset||_319.documentElement.scrollLeft||dojo.body().scrollLeft||0;
return {top:top,left:left,offset:{x:left,y:top}};
};
dojo.html.getParentByType=function(node,type){
var _31e=dojo.doc();
var _31f=dojo.byId(node);
type=type.toLowerCase();
while((_31f)&&(_31f.nodeName.toLowerCase()!=type)){
if(_31f==(_31e["body"]||_31e["documentElement"])){
return null;
}
_31f=_31f.parentNode;
}
return _31f;
};
dojo.html.getAttribute=function(node,attr){
node=dojo.byId(node);
if((!node)||(!node.getAttribute)){
return null;
}
var ta=typeof attr=="string"?attr:new String(attr);
var v=node.getAttribute(ta.toUpperCase());
if((v)&&(typeof v=="string")&&(v!="")){
return v;
}
if(v&&v.value){
return v.value;
}
if((node.getAttributeNode)&&(node.getAttributeNode(ta))){
return (node.getAttributeNode(ta)).value;
}else{
if(node.getAttribute(ta)){
return node.getAttribute(ta);
}else{
if(node.getAttribute(ta.toLowerCase())){
return node.getAttribute(ta.toLowerCase());
}
}
}
return null;
};
dojo.html.hasAttribute=function(node,attr){
return dojo.html.getAttribute(dojo.byId(node),attr)?true:false;
};
dojo.html.getCursorPosition=function(e){
e=e||dojo.global().event;
var _327={x:0,y:0};
if(e.pageX||e.pageY){
_327.x=e.pageX;
_327.y=e.pageY;
}else{
var de=dojo.doc().documentElement;
var db=dojo.body();
_327.x=e.clientX+((de||db)["scrollLeft"])-((de||db)["clientLeft"]);
_327.y=e.clientY+((de||db)["scrollTop"])-((de||db)["clientTop"]);
}
return _327;
};
dojo.html.isTag=function(node){
node=dojo.byId(node);
if(node&&node.tagName){
for(var i=1;i<arguments.length;i++){
if(node.tagName.toLowerCase()==String(arguments[i]).toLowerCase()){
return String(arguments[i]).toLowerCase();
}
}
}
return "";
};
if(dojo.render.html.ie){
if(window.location.href.substr(0,6).toLowerCase()!="https:"){
(function(){
var _32c=dojo.doc().createElement("script");
_32c.src="javascript:'dojo.html.createExternalElement=function(doc, tag){ return doc.createElement(tag); }'";
dojo.doc().getElementsByTagName("head")[0].appendChild(_32c);
})();
}
}else{
dojo.html.createExternalElement=function(doc,tag){
return doc.createElement(tag);
};
}
dojo.html._callDeprecated=function(_32f,_330,args,_332,_333){
dojo.deprecated("dojo.html."+_32f,"replaced by dojo.html."+_330+"("+(_332?"node, {"+_332+": "+_332+"}":"")+")"+(_333?"."+_333:""),"0.5");
var _334=[];
if(_332){
var _335={};
_335[_332]=args[1];
_334.push(args[0]);
_334.push(_335);
}else{
_334=args;
}
var ret=dojo.html[_330].apply(dojo.html,args);
if(_333){
return ret[_333];
}else{
return ret;
}
};
dojo.html.getViewportWidth=function(){
return dojo.html._callDeprecated("getViewportWidth","getViewport",arguments,null,"width");
};
dojo.html.getViewportHeight=function(){
return dojo.html._callDeprecated("getViewportHeight","getViewport",arguments,null,"height");
};
dojo.html.getViewportSize=function(){
return dojo.html._callDeprecated("getViewportSize","getViewport",arguments);
};
dojo.html.getScrollTop=function(){
return dojo.html._callDeprecated("getScrollTop","getScroll",arguments,null,"top");
};
dojo.html.getScrollLeft=function(){
return dojo.html._callDeprecated("getScrollLeft","getScroll",arguments,null,"left");
};
dojo.html.getScrollOffset=function(){
return dojo.html._callDeprecated("getScrollOffset","getScroll",arguments,null,"offset");
};
dojo.provide("dojo.a11y");
dojo.a11y={imgPath:dojo.uri.dojoUri("src/widget/templates/images"),doAccessibleCheck:true,accessible:null,checkAccessible:function(){
if(this.accessible===null){
this.accessible=false;
if(this.doAccessibleCheck==true){
this.accessible=this.testAccessible();
}
}
return this.accessible;
},testAccessible:function(){
this.accessible=false;
if(dojo.render.html.ie||dojo.render.html.mozilla){
var div=document.createElement("div");
div.style.backgroundImage="url(\""+this.imgPath+"/tab_close.gif\")";
dojo.body().appendChild(div);
var _338=null;
if(window.getComputedStyle){
var _339=getComputedStyle(div,"");
_338=_339.getPropertyValue("background-image");
}else{
_338=div.currentStyle.backgroundImage;
}
var _33a=false;
if(_338!=null&&(_338=="none"||_338=="url(invalid-url:)")){
this.accessible=true;
}
dojo.body().removeChild(div);
}
return this.accessible;
},setCheckAccessible:function(_33b){
this.doAccessibleCheck=_33b;
},setAccessibleMode:function(){
if(this.accessible===null){
if(this.checkAccessible()){
dojo.render.html.prefixes.unshift("a11y");
}
}
return this.accessible;
}};
dojo.provide("dojo.widget.Widget");
dojo.provide("dojo.widget.tags");
dojo.declare("dojo.widget.Widget",null,function(){
this.children=[];
this.extraArgs={};
},{parent:null,children:[],extraArgs:{},isTopLevel:false,isModal:false,isEnabled:true,isHidden:false,isContainer:false,widgetId:"",widgetType:"Widget","namespace":"dojo",getNamespacedType:function(){
return (this.namespace?this.namespace+":"+this.widgetType:this.widgetType).toLowerCase();
return (this["namespace"]?this["namespace"]+":"+this.widgetType:this.widgetType).toLowerCase();
},toString:function(){
return "[Widget "+this.getNamespacedType()+", "+(this.widgetId||"NO ID")+"]";
},repr:function(){
return this.toString();
},enable:function(){
this.isEnabled=true;
},disable:function(){
this.isEnabled=false;
},hide:function(){
this.isHidden=true;
},show:function(){
this.isHidden=false;
},onResized:function(){
this.notifyChildrenOfResize();
},notifyChildrenOfResize:function(){
for(var i=0;i<this.children.length;i++){
var _33d=this.children[i];
if(_33d.onResized){
_33d.onResized();
}
}
},create:function(args,_33f,_340,ns){
if(ns){
this["namespace"]=ns;
}
this.satisfyPropertySets(args,_33f,_340);
this.mixInProperties(args,_33f,_340);
this.postMixInProperties(args,_33f,_340);
dojo.widget.manager.add(this);
this.buildRendering(args,_33f,_340);
this.initialize(args,_33f,_340);
this.postInitialize(args,_33f,_340);
this.postCreate(args,_33f,_340);
return this;
},destroy:function(_342){
this.destroyChildren();
this.uninitialize();
this.destroyRendering(_342);
dojo.widget.manager.removeById(this.widgetId);
},destroyChildren:function(){
var _343;
var i=0;
while(this.children.length>i){
_343=this.children[i];
if(_343 instanceof dojo.widget.Widget){
this.removeChild(_343);
_343.destroy();
continue;
}
i++;
}
},getChildrenOfType:function(type,_346){
var ret=[];
var _348=dojo.lang.isFunction(type);
if(!_348){
type=type.toLowerCase();
}
for(var x=0;x<this.children.length;x++){
if(_348){
if(this.children[x] instanceof type){
ret.push(this.children[x]);
}
}else{
if(this.children[x].widgetType.toLowerCase()==type){
ret.push(this.children[x]);
}
}
if(_346){
ret=ret.concat(this.children[x].getChildrenOfType(type,_346));
}
}
return ret;
},getDescendants:function(){
var _34a=[];
var _34b=[this];
var elem;
while((elem=_34b.pop())){
_34a.push(elem);
if(elem.children){
dojo.lang.forEach(elem.children,function(elem){
_34b.push(elem);
});
}
}
return _34a;
},isFirstChild:function(){
return this===this.parent.children[0];
},isLastChild:function(){
return this===this.parent.children[this.parent.children.length-1];
},satisfyPropertySets:function(args){
return args;
},mixInProperties:function(args,frag){
if((args["fastMixIn"])||(frag["fastMixIn"])){
for(var x in args){
this[x]=args[x];
}
return;
}
var _352;
var _353=dojo.widget.lcArgsCache[this.widgetType];
if(_353==null){
_353={};
for(var y in this){
_353[((new String(y)).toLowerCase())]=y;
}
dojo.widget.lcArgsCache[this.widgetType]=_353;
}
var _355={};
for(var x in args){
if(!this[x]){
var y=_353[(new String(x)).toLowerCase()];
if(y){
args[y]=args[x];
x=y;
}
}
if(_355[x]){
continue;
}
_355[x]=true;
if((typeof this[x])!=(typeof _352)){
if(typeof args[x]!="string"){
this[x]=args[x];
}else{
if(dojo.lang.isString(this[x])){
this[x]=args[x];
}else{
if(dojo.lang.isNumber(this[x])){
this[x]=new Number(args[x]);
}else{
if(dojo.lang.isBoolean(this[x])){
this[x]=(args[x].toLowerCase()=="false")?false:true;
}else{
if(dojo.lang.isFunction(this[x])){
if(args[x].search(/[^\w\.]+/i)==-1){
this[x]=dojo.evalObjPath(args[x],false);
}else{
var tn=dojo.lang.nameAnonFunc(new Function(args[x]),this);
dojo.event.connect(this,x,this,tn);
}
}else{
if(dojo.lang.isArray(this[x])){
this[x]=args[x].split(";");
}else{
if(this[x] instanceof Date){
this[x]=new Date(Number(args[x]));
}else{
if(typeof this[x]=="object"){
if(this[x] instanceof dojo.uri.Uri){
this[x]=args[x];
}else{
var _357=args[x].split(";");
for(var y=0;y<_357.length;y++){
var si=_357[y].indexOf(":");
if((si!=-1)&&(_357[y].length>si)){
this[x][_357[y].substr(0,si).replace(/^\s+|\s+$/g,"")]=_357[y].substr(si+1);
}
}
}
}else{
this[x]=args[x];
}
}
}
}
}
}
}
}
}else{
this.extraArgs[x.toLowerCase()]=args[x];
}
}
},postMixInProperties:function(args,frag,_35b){
},initialize:function(args,frag,_35e){
return false;
},postInitialize:function(args,frag,_361){
return false;
},postCreate:function(args,frag,_364){
return false;
},uninitialize:function(){
return false;
},buildRendering:function(args,frag,_367){
dojo.unimplemented("dojo.widget.Widget.buildRendering, on "+this.toString()+", ");
return false;
},destroyRendering:function(){
dojo.unimplemented("dojo.widget.Widget.destroyRendering");
return false;
},cleanUp:function(){
dojo.unimplemented("dojo.widget.Widget.cleanUp");
return false;
},addedTo:function(_368){
},addChild:function(_369){
dojo.unimplemented("dojo.widget.Widget.addChild");
return false;
},removeChild:function(_36a){
for(var x=0;x<this.children.length;x++){
if(this.children[x]===_36a){
this.children.splice(x,1);
break;
}
}
return _36a;
},resize:function(_36c,_36d){
this.setWidth(_36c);
this.setHeight(_36d);
},setWidth:function(_36e){
if((typeof _36e=="string")&&(_36e.substr(-1)=="%")){
this.setPercentageWidth(_36e);
}else{
this.setNativeWidth(_36e);
}
},setHeight:function(_36f){
if((typeof _36f=="string")&&(_36f.substr(-1)=="%")){
this.setPercentageHeight(_36f);
}else{
this.setNativeHeight(_36f);
}
},setPercentageHeight:function(_370){
return false;
},setNativeHeight:function(_371){
return false;
},setPercentageWidth:function(_372){
return false;
},setNativeWidth:function(_373){
return false;
},getPreviousSibling:function(){
var idx=this.getParentIndex();
if(idx<=0){
return null;
}
return this.parent.children[idx-1];
},getSiblings:function(){
return this.parent.children;
},getParentIndex:function(){
return dojo.lang.indexOf(this.parent.children,this,true);
},getNextSibling:function(){
var idx=this.getParentIndex();
if(idx==this.parent.children.length-1){
return null;
}
if(idx<0){
return null;
}
return this.parent.children[idx+1];
}});
dojo.widget.lcArgsCache={};
dojo.widget.tags={};
dojo.widget.tags.addParseTreeHandler=function(type){
dojo.deprecated("addParseTreeHandler",". ParseTreeHandlers are now reserved for components. Any unfiltered DojoML tag without a ParseTreeHandler is assumed to be a widget","0.5");
};
dojo.widget.tags["dojo:propertyset"]=function(_377,_378,_379){
var _37a=_378.parseProperties(_377["dojo:propertyset"]);
};
dojo.widget.tags["dojo:connect"]=function(_37b,_37c,_37d){
var _37e=_37c.parseProperties(_37b["dojo:connect"]);
};
dojo.widget.buildWidgetFromParseTree=function(type,frag,_381,_382,_383,_384){
dojo.a11y.setAccessibleMode();
var _385=type.split(":");
_385=(_385.length==2)?_385[1]:type;
var _386=_384||_381.parseProperties(frag[frag["namespace"]+":"+_385]);
var _387=dojo.widget.manager.getImplementation(_385,null,null,frag["namespace"]);
if(!_387){
throw new Error("cannot find \""+type+"\" widget");
}else{
if(!_387.create){
throw new Error("\""+type+"\" widget object has no \"create\" method and does not appear to implement *Widget");
}
}
_386["dojoinsertionindex"]=_383;
var ret=_387.create(_386,frag,_382,frag["namespace"]);
return ret;
};
dojo.widget.defineWidget=function(_389,_38a,_38b,init,_38d){
if(dojo.lang.isString(arguments[3])){
dojo.widget._defineWidget(arguments[0],arguments[3],arguments[1],arguments[4],arguments[2]);
}else{
var args=[arguments[0]],p=3;
if(dojo.lang.isString(arguments[1])){
args.push(arguments[1],arguments[2]);
}else{
args.push("",arguments[1]);
p=2;
}
if(dojo.lang.isFunction(arguments[p])){
args.push(arguments[p],arguments[p+1]);
}else{
args.push(null,arguments[p]);
}
dojo.widget._defineWidget.apply(this,args);
}
};
dojo.widget.defineWidget.renderers="html|svg|vml";
dojo.widget._defineWidget=function(_38f,_390,_391,init,_393){
var _394=_38f.split(".");
var type=_394.pop();
var regx="\\.("+(_390?_390+"|":"")+dojo.widget.defineWidget.renderers+")\\.";
var r=_38f.search(new RegExp(regx));
_394=(r<0?_394.join("."):_38f.substr(0,r));
dojo.widget.manager.registerWidgetPackage(_394);
var pos=_394.indexOf(".");
var _399=(pos>-1)?_394.substring(0,pos):_394;
_393=(_393)||{};
_393.widgetType=type;
if((!init)&&(_393["classConstructor"])){
init=_393.classConstructor;
delete _393.classConstructor;
}
dojo.declare(_38f,_391,init,_393);
};
dojo.provide("dojo.widget.Parse");
dojo.widget.Parse=function(_39a){
this.propertySetsList=[];
this.fragment=_39a;
this.createComponents=function(frag,_39c){
var _39d=[];
var _39e=false;
try{
if((frag)&&(frag["tagName"])&&(frag!=frag["nodeRef"])){
var _39f=dojo.widget.tags;
var tna=String(frag["tagName"]).split(";");
for(var x=0;x<tna.length;x++){
var ltn=(tna[x].replace(/^\s+|\s+$/g,"")).toLowerCase();
frag.tagName=ltn;
if(_39f[ltn]){
_39e=true;
var ret=_39f[ltn](frag,this,_39c,frag["index"]);
_39d.push(ret);
}else{
if(ltn.indexOf(":")==-1){
ltn="dojo:"+ltn;
}
var ret=dojo.widget.buildWidgetFromParseTree(ltn,frag,this,_39c,frag["index"]);
if(ret){
_39e=true;
_39d.push(ret);
}
}
}
}
}
catch(e){
dojo.debug("dojo.widget.Parse: error:"+e);
}
if(!_39e){
_39d=_39d.concat(this.createSubComponents(frag,_39c));
}
return _39d;
};
this.createSubComponents=function(_3a4,_3a5){
var frag,comps=[];
for(var item in _3a4){
frag=_3a4[item];
if((frag)&&(typeof frag=="object")&&(frag!=_3a4.nodeRef)&&(frag!=_3a4["tagName"])){
comps=comps.concat(this.createComponents(frag,_3a5));
}
}
return comps;
};
this.parsePropertySets=function(_3a8){
return [];
};
this.parseProperties=function(_3a9){
var _3aa={};
for(var item in _3a9){
if((_3a9[item]==_3a9["tagName"])||(_3a9[item]==_3a9.nodeRef)){
}else{
if((_3a9[item]["tagName"])&&(dojo.widget.tags[_3a9[item].tagName.toLowerCase()])){
}else{
if((_3a9[item][0])&&(_3a9[item][0].value!="")&&(_3a9[item][0].value!=null)){
try{
if(item.toLowerCase()=="dataprovider"){
var _3ac=this;
this.getDataProvider(_3ac,_3a9[item][0].value);
_3aa.dataProvider=this.dataProvider;
}
_3aa[item]=_3a9[item][0].value;
var _3ad=this.parseProperties(_3a9[item]);
for(var _3ae in _3ad){
_3aa[_3ae]=_3ad[_3ae];
}
}
catch(e){
dojo.debug(e);
}
}
}
}
}
return _3aa;
};
this.getDataProvider=function(_3af,_3b0){
dojo.io.bind({url:_3b0,load:function(type,_3b2){
if(type=="load"){
_3af.dataProvider=_3b2;
}
},mimetype:"text/javascript",sync:true});
};
this.getPropertySetById=function(_3b3){
for(var x=0;x<this.propertySetsList.length;x++){
if(_3b3==this.propertySetsList[x]["id"][0].value){
return this.propertySetsList[x];
}
}
return "";
};
this.getPropertySetsByType=function(_3b5){
var _3b6=[];
for(var x=0;x<this.propertySetsList.length;x++){
var cpl=this.propertySetsList[x];
var cpcc=cpl["componentClass"]||cpl["componentType"]||null;
var _3ba=this.propertySetsList[x]["id"][0].value;
if((cpcc)&&(_3ba==cpcc[0].value)){
_3b6.push(cpl);
}
}
return _3b6;
};
this.getPropertySets=function(_3bb){
var ppl="dojo:propertyproviderlist";
var _3bd=[];
var _3be=_3bb["tagName"];
if(_3bb[ppl]){
var _3bf=_3bb[ppl].value.split(" ");
for(var _3c0 in _3bf){
if((_3c0.indexOf("..")==-1)&&(_3c0.indexOf("://")==-1)){
var _3c1=this.getPropertySetById(_3c0);
if(_3c1!=""){
_3bd.push(_3c1);
}
}else{
}
}
}
return (this.getPropertySetsByType(_3be)).concat(_3bd);
};
this.createComponentFromScript=function(_3c2,_3c3,_3c4,ns){
_3c4.fastMixIn=true;
var ltn=(ns||"dojo")+":"+_3c3.toLowerCase();
if(dojo.widget.tags[ltn]){
return [dojo.widget.tags[ltn](_3c4,this,null,null,_3c4)];
}
return [dojo.widget.buildWidgetFromParseTree(ltn,_3c4,this,null,null,_3c4)];
};
};
dojo.widget._parser_collection={"dojo":new dojo.widget.Parse()};
dojo.widget.getParser=function(name){
if(!name){
name="dojo";
}
if(!this._parser_collection[name]){
this._parser_collection[name]=new dojo.widget.Parse();
}
return this._parser_collection[name];
};
dojo.widget.createWidget=function(name,_3c9,_3ca,_3cb){
var _3cc=false;
var _3cd=(typeof name=="string");
if(_3cd){
var pos=name.indexOf(":");
var ns=(pos>-1)?name.substring(0,pos):"dojo";
if(pos>-1){
name=name.substring(pos+1);
}
var _3d0=name.toLowerCase();
var _3d1=ns+":"+_3d0;
_3cc=(dojo.byId(name)&&(!dojo.widget.tags[_3d1]));
}
if((arguments.length==1)&&((_3cc)||(!_3cd))){
var xp=new dojo.xml.Parse();
var tn=(_3cc)?dojo.byId(name):name;
return dojo.widget.getParser().createComponents(xp.parseElement(tn,null,true))[0];
}
function fromScript(_3d4,name,_3d6,ns){
_3d6[_3d1]={dojotype:[{value:_3d0}],nodeRef:_3d4,fastMixIn:true};
_3d6["namespace"]=ns;
return dojo.widget.getParser().createComponentFromScript(_3d4,name,_3d6,ns);
}
_3c9=_3c9||{};
var _3d8=false;
var tn=null;
var h=dojo.render.html.capable;
if(h){
tn=document.createElement("span");
}
if(!_3ca){
_3d8=true;
_3ca=tn;
if(h){
dojo.body().appendChild(_3ca);
}
}else{
if(_3cb){
dojo.dom.insertAtPosition(tn,_3ca,_3cb);
}else{
tn=_3ca;
}
}
var _3da=fromScript(tn,name.toLowerCase(),_3c9,ns);
if(!_3da||!_3da[0]||typeof _3da[0].widgetType=="undefined"){
throw new Error("createWidget: Creation of \""+name+"\" widget failed.");
}
if(_3d8){
if(_3da[0].domNode.parentNode){
_3da[0].domNode.parentNode.removeChild(_3da[0].domNode);
}
}
return _3da[0];
};
dojo.provide("dojo.html.style");
dojo.html.getClass=function(node){
node=dojo.byId(node);
if(!node){
return "";
}
var cs="";
if(node.className){
cs=node.className;
}else{
if(dojo.html.hasAttribute(node,"class")){
cs=dojo.html.getAttribute(node,"class");
}
}
return cs.replace(/^\s+|\s+$/g,"");
};
dojo.html.getClasses=function(node){
var c=dojo.html.getClass(node);
return (c=="")?[]:c.split(/\s+/g);
};
dojo.html.hasClass=function(node,_3e0){
return (new RegExp("(^|\\s+)"+_3e0+"(\\s+|$)")).test(dojo.html.getClass(node));
};
dojo.html.prependClass=function(node,_3e2){
_3e2+=" "+dojo.html.getClass(node);
return dojo.html.setClass(node,_3e2);
};
dojo.html.addClass=function(node,_3e4){
if(dojo.html.hasClass(node,_3e4)){
return false;
}
_3e4=(dojo.html.getClass(node)+" "+_3e4).replace(/^\s+|\s+$/g,"");
return dojo.html.setClass(node,_3e4);
};
dojo.html.setClass=function(node,_3e6){
node=dojo.byId(node);
var cs=new String(_3e6);
try{
if(typeof node.className=="string"){
node.className=cs;
}else{
if(node.setAttribute){
node.setAttribute("class",_3e6);
node.className=cs;
}else{
return false;
}
}
}
catch(e){
dojo.debug("dojo.html.setClass() failed",e);
}
return true;
};
dojo.html.removeClass=function(node,_3e9,_3ea){
try{
if(!_3ea){
var _3eb=dojo.html.getClass(node).replace(new RegExp("(^|\\s+)"+_3e9+"(\\s+|$)"),"$1$2");
}else{
var _3eb=dojo.html.getClass(node).replace(_3e9,"");
}
dojo.html.setClass(node,_3eb);
}
catch(e){
dojo.debug("dojo.html.removeClass() failed",e);
}
return true;
};
dojo.html.replaceClass=function(node,_3ed,_3ee){
dojo.html.removeClass(node,_3ee);
dojo.html.addClass(node,_3ed);
};
dojo.html.classMatchType={ContainsAll:0,ContainsAny:1,IsOnly:2};
dojo.html.getElementsByClass=function(_3ef,_3f0,_3f1,_3f2,_3f3){
var _3f4=dojo.doc();
_3f0=dojo.byId(_3f0)||_3f4;
var _3f5=_3ef.split(/\s+/g);
var _3f6=[];
if(_3f2!=1&&_3f2!=2){
_3f2=0;
}
var _3f7=new RegExp("(\\s|^)(("+_3f5.join(")|(")+"))(\\s|$)");
var _3f8=_3f5.join(" ").length;
var _3f9=[];
if(!_3f3&&_3f4.evaluate){
var _3fa=".//"+(_3f1||"*")+"[contains(";
if(_3f2!=dojo.html.classMatchType.ContainsAny){
_3fa+="concat(' ',@class,' '), ' "+_3f5.join(" ') and contains(concat(' ',@class,' '), ' ")+" ')";
if(_3f2==2){
_3fa+=" and string-length(@class)="+_3f8+"]";
}else{
_3fa+="]";
}
}else{
_3fa+="concat(' ',@class,' '), ' "+_3f5.join(" ') or contains(concat(' ',@class,' '), ' ")+" ')]";
}
var _3fb=_3f4.evaluate(_3fa,_3f0,null,XPathResult.ANY_TYPE,null);
var _3fc=_3fb.iterateNext();
while(_3fc){
try{
_3f9.push(_3fc);
_3fc=_3fb.iterateNext();
}
catch(e){
break;
}
}
return _3f9;
}else{
if(!_3f1){
_3f1="*";
}
_3f9=_3f0.getElementsByTagName(_3f1);
var node,i=0;
outer:
while(node=_3f9[i++]){
var _3fe=dojo.html.getClasses(node);
if(_3fe.length==0){
continue outer;
}
var _3ff=0;
for(var j=0;j<_3fe.length;j++){
if(_3f7.test(_3fe[j])){
if(_3f2==dojo.html.classMatchType.ContainsAny){
_3f6.push(node);
continue outer;
}else{
_3ff++;
}
}else{
if(_3f2==dojo.html.classMatchType.IsOnly){
continue outer;
}
}
}
if(_3ff==_3f5.length){
if((_3f2==dojo.html.classMatchType.IsOnly)&&(_3ff==_3fe.length)){
_3f6.push(node);
}else{
if(_3f2==dojo.html.classMatchType.ContainsAll){
_3f6.push(node);
}
}
}
}
return _3f6;
}
};
dojo.html.getElementsByClassName=dojo.html.getElementsByClass;
dojo.html.toCamelCase=function(_401){
var arr=_401.split("-"),cc=arr[0];
for(var i=1;i<arr.length;i++){
cc+=arr[i].charAt(0).toUpperCase()+arr[i].substring(1);
}
return cc;
};
dojo.html.toSelectorCase=function(_404){
return _404.replace(/([A-Z])/g,"-$1").toLowerCase();
};
dojo.html.getComputedStyle=function(node,_406,_407){
node=dojo.byId(node);
var _406=dojo.html.toSelectorCase(_406);
var _408=dojo.html.toCamelCase(_406);
if(!node||!node.style){
return _407;
}else{
if(document.defaultView&&dojo.dom.isDescendantOf(node,node.ownerDocument)){
try{
var cs=document.defaultView.getComputedStyle(node,"");
if(cs){
return cs.getPropertyValue(_406);
}
}
catch(e){
if(node.style.getPropertyValue){
return node.style.getPropertyValue(_406);
}else{
return _407;
}
}
}else{
if(node.currentStyle){
return node.currentStyle[_408];
}
}
}
if(node.style.getPropertyValue){
return node.style.getPropertyValue(_406);
}else{
return _407;
}
};
dojo.html.getStyleProperty=function(node,_40b){
node=dojo.byId(node);
return (node&&node.style?node.style[dojo.html.toCamelCase(_40b)]:undefined);
};
dojo.html.getStyle=function(node,_40d){
var _40e=dojo.html.getStyleProperty(node,_40d);
return (_40e?_40e:dojo.html.getComputedStyle(node,_40d));
};
dojo.html.setStyle=function(node,_410,_411){
node=dojo.byId(node);
if(node&&node.style){
var _412=dojo.html.toCamelCase(_410);
node.style[_412]=_411;
}
};
dojo.html.setStyleText=function(_413,text){
try{
_413.style.cssText=text;
}
catch(e){
_413.setAttribute("style",text);
}
};
dojo.html.copyStyle=function(_415,_416){
if(!_416.style.cssText){
_415.setAttribute("style",_416.getAttribute("style"));
}else{
_415.style.cssText=_416.style.cssText;
}
dojo.html.addClass(_415,dojo.html.getClass(_416));
};
dojo.html.getUnitValue=function(node,_418,_419){
var s=dojo.html.getComputedStyle(node,_418);
if((!s)||((s=="auto")&&(_419))){
return {value:0,units:"px"};
}
var _41b=s.match(/(\-?[\d.]+)([a-z%]*)/i);
if(!_41b){
return dojo.html.getUnitValue.bad;
}
return {value:Number(_41b[1]),units:_41b[2].toLowerCase()};
};
dojo.html.getUnitValue.bad={value:NaN,units:""};
dojo.html.getPixelValue=function(node,_41d,_41e){
var _41f=dojo.html.getUnitValue(node,_41d,_41e);
if(isNaN(_41f.value)){
return 0;
}
if((_41f.value)&&(_41f.units!="px")){
return NaN;
}
return _41f.value;
};
dojo.html.setPositivePixelValue=function(node,_421,_422){
if(isNaN(_422)){
return false;
}
node.style[_421]=Math.max(0,_422)+"px";
return true;
};
dojo.html.styleSheet=null;
dojo.html.insertCssRule=function(_423,_424,_425){
if(!dojo.html.styleSheet){
if(document.createStyleSheet){
dojo.html.styleSheet=document.createStyleSheet();
}else{
if(document.styleSheets[0]){
dojo.html.styleSheet=document.styleSheets[0];
}else{
return null;
}
}
}
if(arguments.length<3){
if(dojo.html.styleSheet.cssRules){
_425=dojo.html.styleSheet.cssRules.length;
}else{
if(dojo.html.styleSheet.rules){
_425=dojo.html.styleSheet.rules.length;
}else{
return null;
}
}
}
if(dojo.html.styleSheet.insertRule){
var rule=_423+" { "+_424+" }";
return dojo.html.styleSheet.insertRule(rule,_425);
}else{
if(dojo.html.styleSheet.addRule){
return dojo.html.styleSheet.addRule(_423,_424,_425);
}else{
return null;
}
}
};
dojo.html.removeCssRule=function(_427){
if(!dojo.html.styleSheet){
dojo.debug("no stylesheet defined for removing rules");
return false;
}
if(dojo.render.html.ie){
if(!_427){
_427=dojo.html.styleSheet.rules.length;
dojo.html.styleSheet.removeRule(_427);
}
}else{
if(document.styleSheets[0]){
if(!_427){
_427=dojo.html.styleSheet.cssRules.length;
}
dojo.html.styleSheet.deleteRule(_427);
}
}
return true;
};
dojo.html._insertedCssFiles=[];
dojo.html.insertCssFile=function(URI,doc,_42a){
if(!URI){
return;
}
if(!doc){
doc=document;
}
var _42b=dojo.hostenv.getText(URI);
_42b=dojo.html.fixPathsInCssText(_42b,URI);
if(_42a){
var idx=-1,node,ent=dojo.html._insertedCssFiles;
for(var i=0;i<ent.length;i++){
if((ent[i].doc==doc)&&(ent[i].cssText==_42b)){
idx=i;
node=ent[i].nodeRef;
break;
}
}
if(node){
var _42e=doc.getElementsByTagName("style");
for(var i=0;i<_42e.length;i++){
if(_42e[i]==node){
return;
}
}
dojo.html._insertedCssFiles.shift(idx,1);
}
}
var _42f=dojo.html.insertCssText(_42b);
dojo.html._insertedCssFiles.push({"doc":doc,"cssText":_42b,"nodeRef":_42f});
if(_42f&&djConfig.isDebug){
_42f.setAttribute("dbgHref",URI);
}
return _42f;
};
dojo.html.insertCssText=function(_430,doc,URI){
if(!_430){
return;
}
if(!doc){
doc=document;
}
if(URI){
_430=dojo.html.fixPathsInCssText(_430,URI);
}
var _433=doc.createElement("style");
_433.setAttribute("type","text/css");
var head=doc.getElementsByTagName("head")[0];
if(!head){
dojo.debug("No head tag in document, aborting styles");
return;
}else{
head.appendChild(_433);
}
if(_433.styleSheet){
_433.styleSheet.cssText=_430;
}else{
var _435=doc.createTextNode(_430);
_433.appendChild(_435);
}
return _433;
};
dojo.html.fixPathsInCssText=function(_436,URI){
function iefixPathsInCssText(){
var _438=/AlphaImageLoader\(src\=['"]([\t\s\w()\/.\\'"-:#=&?]*)['"]/;
while(match=_438.exec(_436)){
url=match[1].replace(regexTrim,"$2");
if(!regexProtocol.exec(url)){
url=(new dojo.uri.Uri(URI,url).toString());
}
str+=_436.substring(0,match.index)+"AlphaImageLoader(src='"+url+"'";
_436=_436.substr(match.index+match[0].length);
}
return str+_436;
}
if(!_436||!URI){
return;
}
var _439,str="",url="";
var _43a=/url\(\s*([\t\s\w()\/.\\'"-:#=&?]+)\s*\)/;
var _43b=/(file|https?|ftps?):\/\//;
var _43c=/^[\s]*(['"]?)([\w()\/.\\'"-:#=&?]*)\1[\s]*?$/;
if(dojo.render.html.ie55||dojo.render.html.ie60){
_436=iefixPathsInCssText();
}
while(_439=_43a.exec(_436)){
url=_439[1].replace(_43c,"$2");
if(!_43b.exec(url)){
url=(new dojo.uri.Uri(URI,url).toString());
}
str+=_436.substring(0,_439.index)+"url("+url+")";
_436=_436.substr(_439.index+_439[0].length);
}
return str+_436;
};
dojo.html.setActiveStyleSheet=function(_43d){
var i=0,a,els=dojo.doc().getElementsByTagName("link");
while(a=els[i++]){
if(a.getAttribute("rel").indexOf("style")!=-1&&a.getAttribute("title")){
a.disabled=true;
if(a.getAttribute("title")==_43d){
a.disabled=false;
}
}
}
};
dojo.html.getActiveStyleSheet=function(){
var i=0,a,els=dojo.doc().getElementsByTagName("link");
while(a=els[i++]){
if(a.getAttribute("rel").indexOf("style")!=-1&&a.getAttribute("title")&&!a.disabled){
return a.getAttribute("title");
}
}
return null;
};
dojo.html.getPreferredStyleSheet=function(){
var i=0,a,els=dojo.doc().getElementsByTagName("link");
while(a=els[i++]){
if(a.getAttribute("rel").indexOf("style")!=-1&&a.getAttribute("rel").indexOf("alt")==-1&&a.getAttribute("title")){
return a.getAttribute("title");
}
}
return null;
};
dojo.html.applyBrowserClass=function(node){
var drh=dojo.render.html;
var _443={dj_ie:drh.ie,dj_ie55:drh.ie55,dj_ie6:drh.ie60,dj_ie7:drh.ie70,dj_iequirks:drh.ie&&drh.quirks,dj_opera:drh.opera,dj_opera8:drh.opera&&(Math.floor(dojo.render.version)==8),dj_opera9:drh.opera&&(Math.floor(dojo.render.version)==9),dj_khtml:drh.khtml,dj_safari:drh.safari,dj_gecko:drh.mozilla};
for(var p in _443){
if(_443[p]){
dojo.html.addClass(node,p);
}
}
};
dojo.provide("dojo.widget.DomWidget");
dojo.widget._cssFiles={};
dojo.widget._cssStrings={};
dojo.widget._templateCache={};
dojo.widget.defaultStrings={dojoRoot:dojo.hostenv.getBaseScriptUri(),baseScriptUri:dojo.hostenv.getBaseScriptUri()};
dojo.widget.buildFromTemplate=function(){
dojo.lang.forward("fillFromTemplateCache");
};
dojo.widget.fillFromTemplateCache=function(obj,_446,_447,_448){
var _449=_446||obj.templatePath;
if(_449&&!(_449 instanceof dojo.uri.Uri)){
_449=dojo.uri.dojoUri(_449);
dojo.deprecated("templatePath should be of type dojo.uri.Uri",null,"0.4");
}
var _44a=dojo.widget._templateCache;
if(!obj["widgetType"]){
do{
var _44b="__dummyTemplate__"+dojo.widget._templateCache.dummyCount++;
}while(_44a[_44b]);
obj.widgetType=_44b;
}
var wt=obj.widgetType;
var ts=_44a[wt];
if(!ts){
_44a[wt]={"string":null,"node":null};
if(_448){
ts={};
}else{
ts=_44a[wt];
}
}
if((!obj.templateString)&&(!_448)){
obj.templateString=_447||ts["string"];
}
if((!obj.templateNode)&&(!_448)){
obj.templateNode=ts["node"];
}
if((!obj.templateNode)&&(!obj.templateString)&&(_449)){
var _44e=dojo.hostenv.getText(_449);
if(_44e){
_44e=_44e.replace(/^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im,"");
var _44f=_44e.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_44f){
_44e=_44f[1];
}
}else{
_44e="";
}
obj.templateString=_44e;
if(!_448){
_44a[wt]["string"]=_44e;
}
}
if((!ts["string"])&&(!_448)){
ts.string=obj.templateString;
}
};
dojo.widget._templateCache.dummyCount=0;
dojo.widget.attachProperties=["dojoAttachPoint","id"];
dojo.widget.eventAttachProperty="dojoAttachEvent";
dojo.widget.onBuildProperty="dojoOnBuild";
dojo.widget.waiNames=["waiRole","waiState"];
dojo.widget.wai={waiRole:{name:"waiRole","namespace":"http://www.w3.org/TR/xhtml2",alias:"x2",prefix:"wairole:"},waiState:{name:"waiState","namespace":"http://www.w3.org/2005/07/aaa",alias:"aaa",prefix:""},setAttr:function(node,ns,attr,_453){
if(dojo.render.html.ie){
node.setAttribute(this[ns].alias+":"+attr,this[ns].prefix+_453);
}else{
node.setAttributeNS(this[ns]["namespace"],attr,this[ns].prefix+_453);
}
},getAttr:function(node,ns,attr){
if(dojo.render.html.ie){
return node.getAttribute(this[ns].alias+":"+attr);
}else{
return node.getAttributeNS(this[ns]["namespace"],attr);
}
}};
dojo.widget.attachTemplateNodes=function(_457,_458,_459){
var _45a=dojo.dom.ELEMENT_NODE;
function trim(str){
return str.replace(/^\s+|\s+$/g,"");
}
if(!_457){
_457=_458.domNode;
}
if(_457.nodeType!=_45a){
return;
}
var _45c=_457.all||_457.getElementsByTagName("*");
var _45d=_458;
for(var x=-1;x<_45c.length;x++){
var _45f=(x==-1)?_457:_45c[x];
var _460=[];
if(!_458.enableSubWidgets||!_45f.getAttribute("dojoType")){
for(var y=0;y<this.attachProperties.length;y++){
var _462=_45f.getAttribute(this.attachProperties[y]);
if(_462){
_460=_462.split(";");
for(var z=0;z<_460.length;z++){
if(dojo.lang.isArray(_458[_460[z]])){
_458[_460[z]].push(_45f);
}else{
_458[_460[z]]=_45f;
}
}
break;
}
}
var _464=_45f.getAttribute(this.eventAttachProperty);
if(_464){
var evts=_464.split(";");
for(var y=0;y<evts.length;y++){
if((!evts[y])||(!evts[y].length)){
continue;
}
var _466=null;
var tevt=trim(evts[y]);
if(evts[y].indexOf(":")>=0){
var _468=tevt.split(":");
tevt=trim(_468[0]);
_466=trim(_468[1]);
}
if(!_466){
_466=tevt;
}
var tf=function(){
var ntf=new String(_466);
return function(evt){
if(_45d[ntf]){
_45d[ntf](dojo.event.browser.fixEvent(evt,this));
}
};
}();
dojo.event.browser.addListener(_45f,tevt,tf,false,true);
}
}
for(var y=0;y<_459.length;y++){
var _46c=_45f.getAttribute(_459[y]);
if((_46c)&&(_46c.length)){
var _466=null;
var _46d=_459[y].substr(4);
_466=trim(_46c);
var _46e=[_466];
if(_466.indexOf(";")>=0){
_46e=dojo.lang.map(_466.split(";"),trim);
}
for(var z=0;z<_46e.length;z++){
if(!_46e[z].length){
continue;
}
var tf=function(){
var ntf=new String(_46e[z]);
return function(evt){
if(_45d[ntf]){
_45d[ntf](dojo.event.browser.fixEvent(evt,this));
}
};
}();
dojo.event.browser.addListener(_45f,_46d,tf,false,true);
}
}
}
}
var _471=_45f.getAttribute(this.templateProperty);
if(_471){
_458[_471]=_45f;
}
dojo.lang.forEach(dojo.widget.waiNames,function(name){
var wai=dojo.widget.wai[name];
var val=_45f.getAttribute(wai.name);
if(val){
if(val.indexOf("-")==-1){
dojo.widget.wai.setAttr(_45f,wai.name,"role",val);
}else{
var _475=val.split("-");
dojo.widget.wai.setAttr(_45f,wai.name,_475[0],_475[1]);
}
}
},this);
var _476=_45f.getAttribute(this.onBuildProperty);
if(_476){
eval("var node = baseNode; var widget = targetObj; "+_476);
}
}
};
dojo.widget.getDojoEventsFromStr=function(str){
var re=/(dojoOn([a-z]+)(\s?))=/gi;
var evts=str?str.match(re)||[]:[];
var ret=[];
var lem={};
for(var x=0;x<evts.length;x++){
if(evts[x].length<1){
continue;
}
var cm=evts[x].replace(/\s/,"");
cm=(cm.slice(0,cm.length-1));
if(!lem[cm]){
lem[cm]=true;
ret.push(cm);
}
}
return ret;
};
dojo.declare("dojo.widget.DomWidget",dojo.widget.Widget,function(){
if((arguments.length>0)&&(typeof arguments[0]=="object")){
this.create(arguments[0]);
}
},{templateNode:null,templateString:null,templateCssString:null,preventClobber:false,domNode:null,containerNode:null,enableSubWidgets:false,addChild:function(_47e,_47f,pos,ref,_482){
if(!this.isContainer){
dojo.debug("dojo.widget.DomWidget.addChild() attempted on non-container widget");
return null;
}else{
if(_482==undefined){
_482=this.children.length;
}
this.addWidgetAsDirectChild(_47e,_47f,pos,ref,_482);
this.registerChild(_47e,_482);
}
return _47e;
},addWidgetAsDirectChild:function(_483,_484,pos,ref,_487){
if((!this.containerNode)&&(!_484)){
this.containerNode=this.domNode;
}
var cn=(_484)?_484:this.containerNode;
if(!pos){
pos="after";
}
if(!ref){
if(!cn){
cn=dojo.body();
}
ref=cn.lastChild;
}
if(!_487){
_487=0;
}
_483.domNode.setAttribute("dojoinsertionindex",_487);
if(!ref){
cn.appendChild(_483.domNode);
}else{
if(pos=="insertAtIndex"){
dojo.dom.insertAtIndex(_483.domNode,ref.parentNode,_487);
}else{
if((pos=="after")&&(ref===cn.lastChild)){
cn.appendChild(_483.domNode);
}else{
dojo.dom.insertAtPosition(_483.domNode,cn,pos);
}
}
}
},registerChild:function(_489,_48a){
_489.dojoInsertionIndex=_48a;
var idx=-1;
for(var i=0;i<this.children.length;i++){
if(this.children[i].dojoInsertionIndex<=_48a){
idx=i;
}
}
this.children.splice(idx+1,0,_489);
_489.parent=this;
_489.addedTo(this,idx+1);
delete dojo.widget.manager.topWidgets[_489.widgetId];
},removeChild:function(_48d){
dojo.dom.removeNode(_48d.domNode);
return dojo.widget.DomWidget.superclass.removeChild.call(this,_48d);
},getFragNodeRef:function(frag){
if(!frag){
return null;
}
if(!frag[this.getNamespacedType()]){
dojo.raise("Error: no frag for widget type "+this.getNamespacedType()+", id "+this.widgetId+" (maybe a widget has set it's type incorrectly)");
}
return frag[this.getNamespacedType()]["nodeRef"];
},postInitialize:function(args,frag,_491){
var _492=this.getFragNodeRef(frag);
if(_491&&(_491.snarfChildDomOutput||!_492)){
_491.addWidgetAsDirectChild(this,"","insertAtIndex","",args["dojoinsertionindex"],_492);
}else{
if(_492){
if(this.domNode&&(this.domNode!==_492)){
var _493=_492.parentNode.replaceChild(this.domNode,_492);
}
}
}
if(_491){
_491.registerChild(this,args.dojoinsertionindex);
}else{
dojo.widget.manager.topWidgets[this.widgetId]=this;
}
if(this.isContainer&&!frag["dojoDontFollow"]){
dojo.widget.getParser().createSubComponents(frag,this);
}
},buildRendering:function(args,frag){
var ts=dojo.widget._templateCache[this.widgetType];
if(args["templatecsspath"]){
args["templateCssPath"]=args["templatecsspath"];
}
var _497=args["templateCssPath"]||this.templateCssPath;
if(_497&&!(_497 instanceof dojo.uri.Uri)){
_497=dojo.uri.dojoUri(_497);
dojo.deprecated("templateCssPath should be of type dojo.uri.Uri",null,"0.4");
}
if(_497&&!dojo.widget._cssFiles[_497.toString()]){
if((!this.templateCssString)&&(_497)){
this.templateCssString=dojo.hostenv.getText(_497);
this.templateCssPath=null;
}
dojo.widget._cssFiles[_497.toString()]=true;
}
if((this["templateCssString"])&&(!this.templateCssString["loaded"])){
dojo.html.insertCssText(this.templateCssString,null,_497);
if(!this.templateCssString){
this.templateCssString="";
}
this.templateCssString.loaded=true;
}
if((!this.preventClobber)&&((this.templatePath)||(this.templateNode)||((this["templateString"])&&(this.templateString.length))||((typeof ts!="undefined")&&((ts["string"])||(ts["node"]))))){
this.buildFromTemplate(args,frag);
}else{
this.domNode=this.getFragNodeRef(frag);
}
this.fillInTemplate(args,frag);
if(this.enableSubWidgets){
var _498=new dojo.xml.Parse();
var frag=_498.parseElement(this.domNode,null,true);
dojo.widget.getParser().createSubComponents(frag,this);
for(var i=0;i<this.children.length;i++){
var _49a=this.children[i];
if(_49a.extraArgs["dojoattachevent"]){
var evts=_49a.extraArgs["dojoattachevent"].split(";");
for(var j=0;j<evts.length;j++){
var _49d=null;
var tevt=dojo.string.trim(evts[j]);
if(tevt.indexOf(":")>=0){
var _49f=tevt.split(":");
tevt=dojo.string.trim(_49f[0]);
_49d=dojo.string.trim(_49f[1]);
}
if(!_49d){
_49d=tevt;
}
if(dojo.lang.isFunction(_49a[tevt])){
dojo.event.connect(_49a,tevt,this,_49d);
}else{
alert(tevt+" is not a function in widget "+_49a);
}
}
}
if(_49a.extraArgs["dojoattachpoint"]){
this[_49a.extraArgs["dojoattachpoint"]]=_49a;
}
}
}
},buildFromTemplate:function(args,frag){
var _4a2=false;
if(args["templatepath"]){
_4a2=true;
args["templatePath"]=args["templatepath"];
}
dojo.widget.fillFromTemplateCache(this,args["templatePath"],null,_4a2);
var ts=dojo.widget._templateCache[this.widgetType];
if((ts)&&(!_4a2)){
if(!this.templateString.length){
this.templateString=ts["string"];
}
if(!this.templateNode){
this.templateNode=ts["node"];
}
}
var _4a4=false;
var node=null;
var tstr=this.templateString;
if((!this.templateNode)&&(this.templateString)){
_4a4=this.templateString.match(/\$\{([^\}]+)\}/g);
if(_4a4){
var hash=this.strings||{};
for(var key in dojo.widget.defaultStrings){
if(dojo.lang.isUndefined(hash[key])){
hash[key]=dojo.widget.defaultStrings[key];
}
}
for(var i=0;i<_4a4.length;i++){
var key=_4a4[i];
key=key.substring(2,key.length-1);
var kval=(key.substring(0,5)=="this.")?dojo.lang.getObjPathValue(key.substring(5),this):hash[key];
var _4ab;
if((kval)||(dojo.lang.isString(kval))){
_4ab=new String((dojo.lang.isFunction(kval))?kval.call(this,key,this.templateString):kval);
while(_4ab.indexOf("\"")>-1){
_4ab=_4ab.replace("\"","&quot;");
}
tstr=tstr.replace(_4a4[i],_4ab);
}
}
}else{
this.templateNode=this.createNodesFromText(this.templateString,true)[0];
if(!_4a2){
ts.node=this.templateNode;
}
}
}
if((!this.templateNode)&&(!_4a4)){
dojo.debug("DomWidget.buildFromTemplate: could not create template");
return false;
}else{
if(!_4a4){
node=this.templateNode.cloneNode(true);
if(!node){
return false;
}
}else{
node=this.createNodesFromText(tstr,true)[0];
}
}
this.domNode=node;
this.attachTemplateNodes();
if(this.isContainer&&this.containerNode){
var src=this.getFragNodeRef(frag);
if(src){
dojo.dom.moveChildren(src,this.containerNode);
}
}
},attachTemplateNodes:function(_4ad,_4ae){
if(!_4ad){
_4ad=this.domNode;
}
if(!_4ae){
_4ae=this;
}
return dojo.widget.attachTemplateNodes(_4ad,_4ae,dojo.widget.getDojoEventsFromStr(this.templateString));
},fillInTemplate:function(){
},destroyRendering:function(){
try{
delete this.domNode;
}
catch(e){
}
},cleanUp:function(){
},getContainerHeight:function(){
dojo.unimplemented("dojo.widget.DomWidget.getContainerHeight");
},getContainerWidth:function(){
dojo.unimplemented("dojo.widget.DomWidget.getContainerWidth");
},createNodesFromText:function(){
dojo.unimplemented("dojo.widget.DomWidget.createNodesFromText");
}});
dojo.provide("dojo.html.display");
dojo.html._toggle=function(node,_4b0,_4b1){
node=dojo.byId(node);
_4b1(node,!_4b0(node));
return _4b0(node);
};
dojo.html.show=function(node){
node=dojo.byId(node);
if(dojo.html.getStyleProperty(node,"display")=="none"){
dojo.html.setStyle(node,"display",(node.dojoDisplayCache||""));
node.dojoDisplayCache=undefined;
}
};
dojo.html.hide=function(node){
node=dojo.byId(node);
if(typeof node["dojoDisplayCache"]=="undefined"){
var d=dojo.html.getStyleProperty(node,"display");
if(d!="none"){
node.dojoDisplayCache=d;
}
}
dojo.html.setStyle(node,"display","none");
};
dojo.html.setShowing=function(node,_4b6){
dojo.html[(_4b6?"show":"hide")](node);
};
dojo.html.isShowing=function(node){
return (dojo.html.getStyleProperty(node,"display")!="none");
};
dojo.html.toggleShowing=function(node){
return dojo.html._toggle(node,dojo.html.isShowing,dojo.html.setShowing);
};
dojo.html.displayMap={tr:"",td:"",th:"",img:"inline",span:"inline",input:"inline",button:"inline"};
dojo.html.suggestDisplayByTagName=function(node){
node=dojo.byId(node);
if(node&&node.tagName){
var tag=node.tagName.toLowerCase();
return (tag in dojo.html.displayMap?dojo.html.displayMap[tag]:"block");
}
};
dojo.html.setDisplay=function(node,_4bc){
dojo.html.setStyle(node,"display",((_4bc instanceof String||typeof _4bc=="string")?_4bc:(_4bc?dojo.html.suggestDisplayByTagName(node):"none")));
};
dojo.html.isDisplayed=function(node){
return (dojo.html.getComputedStyle(node,"display")!="none");
};
dojo.html.toggleDisplay=function(node){
return dojo.html._toggle(node,dojo.html.isDisplayed,dojo.html.setDisplay);
};
dojo.html.setVisibility=function(node,_4c0){
dojo.html.setStyle(node,"visibility",((_4c0 instanceof String||typeof _4c0=="string")?_4c0:(_4c0?"visible":"hidden")));
};
dojo.html.isVisible=function(node){
return (dojo.html.getComputedStyle(node,"visibility")!="hidden");
};
dojo.html.toggleVisibility=function(node){
return dojo.html._toggle(node,dojo.html.isVisible,dojo.html.setVisibility);
};
dojo.html.setOpacity=function(node,_4c4,_4c5){
node=dojo.byId(node);
var h=dojo.render.html;
if(!_4c5){
if(_4c4>=1){
if(h.ie){
dojo.html.clearOpacity(node);
return;
}else{
_4c4=0.999999;
}
}else{
if(_4c4<0){
_4c4=0;
}
}
}
if(h.ie){
if(node.nodeName.toLowerCase()=="tr"){
var tds=node.getElementsByTagName("td");
for(var x=0;x<tds.length;x++){
tds[x].style.filter="Alpha(Opacity="+_4c4*100+")";
}
}
node.style.filter="Alpha(Opacity="+_4c4*100+")";
}else{
if(h.moz){
node.style.opacity=_4c4;
node.style.MozOpacity=_4c4;
}else{
if(h.safari){
node.style.opacity=_4c4;
node.style.KhtmlOpacity=_4c4;
}else{
node.style.opacity=_4c4;
}
}
}
};
dojo.html.clearOpacity=function clearOpacity(node){
node=dojo.byId(node);
var ns=node.style;
var h=dojo.render.html;
if(h.ie){
try{
if(node.filters&&node.filters.alpha){
ns.filter="";
}
}
catch(e){
}
}else{
if(h.moz){
ns.opacity=1;
ns.MozOpacity=1;
}else{
if(h.safari){
ns.opacity=1;
ns.KhtmlOpacity=1;
}else{
ns.opacity=1;
}
}
}
};
dojo.html.getOpacity=function getOpacity(node){
node=dojo.byId(node);
var h=dojo.render.html;
if(h.ie){
var opac=(node.filters&&node.filters.alpha&&typeof node.filters.alpha.opacity=="number"?node.filters.alpha.opacity:100)/100;
}else{
var opac=node.style.opacity||node.style.MozOpacity||node.style.KhtmlOpacity||1;
}
return opac>=0.999999?1:Number(opac);
};
dojo.provide("dojo.html.layout");
dojo.html.sumAncestorProperties=function(node,prop){
node=dojo.byId(node);
if(!node){
return 0;
}
var _4d1=0;
while(node){
if(dojo.html.getComputedStyle(node,"position")=="fixed"){
return 0;
}
var val=node[prop];
if(val){
_4d1+=val-0;
if(node==dojo.body()){
break;
}
}
node=node.parentNode;
}
return _4d1;
};
dojo.html.setStyleAttributes=function(node,_4d4){
node=dojo.byId(node);
var _4d5=_4d4.replace(/(;)?\s*$/,"").split(";");
for(var i=0;i<_4d5.length;i++){
var _4d7=_4d5[i].split(":");
var name=_4d7[0].replace(/\s*$/,"").replace(/^\s*/,"").toLowerCase();
var _4d9=_4d7[1].replace(/\s*$/,"").replace(/^\s*/,"");
switch(name){
case "opacity":
dojo.html.setOpacity(node,_4d9);
break;
case "content-height":
dojo.html.setContentBox(node,{height:_4d9});
break;
case "content-width":
dojo.html.setContentBox(node,{width:_4d9});
break;
case "outer-height":
dojo.html.setMarginBox(node,{height:_4d9});
break;
case "outer-width":
dojo.html.setMarginBox(node,{width:_4d9});
break;
default:
node.style[dojo.html.toCamelCase(name)]=_4d9;
}
}
};
dojo.html.boxSizing={MARGIN_BOX:"margin-box",BORDER_BOX:"border-box",PADDING_BOX:"padding-box",CONTENT_BOX:"content-box"};
dojo.html.getAbsolutePosition=dojo.html.abs=function(node,_4db,_4dc){
node=dojo.byId(node,node.ownerDocument);
var ret={x:0,y:0};
var bs=dojo.html.boxSizing;
if(!_4dc){
_4dc=bs.CONTENT_BOX;
}
var _4df=2;
var _4e0;
switch(_4dc){
case bs.MARGIN_BOX:
_4e0=3;
break;
case bs.BORDER_BOX:
_4e0=2;
break;
case bs.PADDING_BOX:
default:
_4e0=1;
break;
case bs.CONTENT_BOX:
_4e0=0;
break;
}
var h=dojo.render.html;
var db=document["body"]||document["documentElement"];
if(h.ie){
with(node.getBoundingClientRect()){
ret.x=left-2;
ret.y=top-2;
}
}else{
if(document.getBoxObjectFor){
_4df=1;
try{
var bo=document.getBoxObjectFor(node);
ret.x=bo.x-dojo.html.sumAncestorProperties(node,"scrollLeft");
ret.y=bo.y-dojo.html.sumAncestorProperties(node,"scrollTop");
}
catch(e){
}
}else{
if(node["offsetParent"]){
var _4e4;
if((h.safari)&&(node.style.getPropertyValue("position")=="absolute")&&(node.parentNode==db)){
_4e4=db;
}else{
_4e4=db.parentNode;
}
if(node.parentNode!=db){
var nd=node;
if(dojo.render.html.opera){
nd=db;
}
ret.x-=dojo.html.sumAncestorProperties(nd,"scrollLeft");
ret.y-=dojo.html.sumAncestorProperties(nd,"scrollTop");
}
var _4e6=node;
do{
var n=_4e6["offsetLeft"];
if(!h.opera||n>0){
ret.x+=isNaN(n)?0:n;
}
var m=_4e6["offsetTop"];
ret.y+=isNaN(m)?0:m;
_4e6=_4e6.offsetParent;
}while((_4e6!=_4e4)&&(_4e6!=null));
}else{
if(node["x"]&&node["y"]){
ret.x+=isNaN(node.x)?0:node.x;
ret.y+=isNaN(node.y)?0:node.y;
}
}
}
}
if(_4db){
var _4e9=dojo.html.getScroll();
ret.y+=_4e9.top;
ret.x+=_4e9.left;
}
var _4ea=[dojo.html.getPaddingExtent,dojo.html.getBorderExtent,dojo.html.getMarginExtent];
if(_4df>_4e0){
for(var i=_4e0;i<_4df;++i){
ret.y+=_4ea[i](node,"top");
ret.x+=_4ea[i](node,"left");
}
}else{
if(_4df<_4e0){
for(var i=_4e0;i>_4df;--i){
ret.y-=_4ea[i-1](node,"top");
ret.x-=_4ea[i-1](node,"left");
}
}
}
ret.top=ret.y;
ret.left=ret.x;
return ret;
};
dojo.html.isPositionAbsolute=function(node){
return (dojo.html.getComputedStyle(node,"position")=="absolute");
};
dojo.html._sumPixelValues=function(node,_4ee,_4ef){
var _4f0=0;
for(var x=0;x<_4ee.length;x++){
_4f0+=dojo.html.getPixelValue(node,_4ee[x],_4ef);
}
return _4f0;
};
dojo.html.getMargin=function(node){
return {width:dojo.html._sumPixelValues(node,["margin-left","margin-right"],(dojo.html.getComputedStyle(node,"position")=="absolute")),height:dojo.html._sumPixelValues(node,["margin-top","margin-bottom"],(dojo.html.getComputedStyle(node,"position")=="absolute"))};
};
dojo.html.getBorder=function(node){
return {width:dojo.html.getBorderExtent(node,"left")+dojo.html.getBorderExtent(node,"right"),height:dojo.html.getBorderExtent(node,"top")+dojo.html.getBorderExtent(node,"bottom")};
};
dojo.html.getBorderExtent=function(node,side){
return (dojo.html.getStyle(node,"border-"+side+"-style")=="none"?0:dojo.html.getPixelValue(node,"border-"+side+"-width"));
};
dojo.html.getMarginExtent=function(node,side){
return dojo.html._sumPixelValues(node,["margin-"+side],dojo.html.isPositionAbsolute(node));
};
dojo.html.getPaddingExtent=function(node,side){
return dojo.html._sumPixelValues(node,["padding-"+side],true);
};
dojo.html.getPadding=function(node){
return {width:dojo.html._sumPixelValues(node,["padding-left","padding-right"],true),height:dojo.html._sumPixelValues(node,["padding-top","padding-bottom"],true)};
};
dojo.html.getPadBorder=function(node){
var pad=dojo.html.getPadding(node);
var _4fd=dojo.html.getBorder(node);
return {width:pad.width+_4fd.width,height:pad.height+_4fd.height};
};
dojo.html.getBoxSizing=function(node){
var h=dojo.render.html;
var bs=dojo.html.boxSizing;
if((h.ie)||(h.opera)){
var cm=document["compatMode"];
if((cm=="BackCompat")||(cm=="QuirksMode")){
return bs.BORDER_BOX;
}else{
return bs.CONTENT_BOX;
}
}else{
if(arguments.length==0){
node=document.documentElement;
}
var _502=dojo.html.getStyle(node,"-moz-box-sizing");
if(!_502){
_502=dojo.html.getStyle(node,"box-sizing");
}
return (_502?_502:bs.CONTENT_BOX);
}
};
dojo.html.isBorderBox=function(node){
return (dojo.html.getBoxSizing(node)==dojo.html.boxSizing.BORDER_BOX);
};
dojo.html.getBorderBox=function(node){
node=dojo.byId(node);
return {width:node.offsetWidth,height:node.offsetHeight};
};
dojo.html.getPaddingBox=function(node){
var box=dojo.html.getBorderBox(node);
var _507=dojo.html.getBorder(node);
return {width:box.width-_507.width,height:box.height-_507.height};
};
dojo.html.getContentBox=function(node){
node=dojo.byId(node);
var _509=dojo.html.getPadBorder(node);
return {width:node.offsetWidth-_509.width,height:node.offsetHeight-_509.height};
};
dojo.html.setContentBox=function(node,args){
node=dojo.byId(node);
var _50c=0;
var _50d=0;
var isbb=dojo.html.isBorderBox(node);
var _50f=(isbb?dojo.html.getPadBorder(node):{width:0,height:0});
var ret={};
if(typeof args.width!="undefined"){
_50c=args.width+_50f.width;
ret.width=dojo.html.setPositivePixelValue(node,"width",_50c);
}
if(typeof args.height!="undefined"){
_50d=args.height+_50f.height;
ret.height=dojo.html.setPositivePixelValue(node,"height",_50d);
}
return ret;
};
dojo.html.getMarginBox=function(node){
var _512=dojo.html.getBorderBox(node);
var _513=dojo.html.getMargin(node);
return {width:_512.width+_513.width,height:_512.height+_513.height};
};
dojo.html.setMarginBox=function(node,args){
node=dojo.byId(node);
var _516=0;
var _517=0;
var isbb=dojo.html.isBorderBox(node);
var _519=(!isbb?dojo.html.getPadBorder(node):{width:0,height:0});
var _51a=dojo.html.getMargin(node);
var ret={};
if(typeof args.width!="undefined"){
_516=args.width-_519.width;
_516-=_51a.width;
ret.width=dojo.html.setPositivePixelValue(node,"width",_516);
}
if(typeof args.height!="undefined"){
_517=args.height-_519.height;
_517-=_51a.height;
ret.height=dojo.html.setPositivePixelValue(node,"height",_517);
}
return ret;
};
dojo.html.getElementBox=function(node,type){
var bs=dojo.html.boxSizing;
switch(type){
case bs.MARGIN_BOX:
return dojo.html.getMarginBox(node);
case bs.BORDER_BOX:
return dojo.html.getBorderBox(node);
case bs.PADDING_BOX:
return dojo.html.getPaddingBox(node);
case bs.CONTENT_BOX:
default:
return dojo.html.getContentBox(node);
}
};
dojo.html.toCoordinateObject=dojo.html.toCoordinateArray=function(_51f,_520,_521){
if(_51f instanceof Array||typeof _51f=="array"){
dojo.deprecated("dojo.html.toCoordinateArray","use dojo.html.toCoordinateObject({left: , top: , width: , height: }) instead","0.5");
while(_51f.length<4){
_51f.push(0);
}
while(_51f.length>4){
_51f.pop();
}
var ret={left:_51f[0],top:_51f[1],width:_51f[2],height:_51f[3]};
}else{
if(!_51f.nodeType&&!(_51f instanceof String||typeof _51f=="string")&&("width" in _51f||"height" in _51f||"left" in _51f||"x" in _51f||"top" in _51f||"y" in _51f)){
var ret={left:_51f.left||_51f.x||0,top:_51f.top||_51f.y||0,width:_51f.width||0,height:_51f.height||0};
}else{
var node=dojo.byId(_51f);
var pos=dojo.html.abs(node,_520,_521);
var _525=dojo.html.getMarginBox(node);
var ret={left:pos.left,top:pos.top,width:_525.width,height:_525.height};
}
}
ret.x=ret.left;
ret.y=ret.top;
return ret;
};
dojo.html.setMarginBoxWidth=dojo.html.setOuterWidth=function(node,_527){
return dojo.html._callDeprecated("setMarginBoxWidth","setMarginBox",arguments,"width");
};
dojo.html.setMarginBoxHeight=dojo.html.setOuterHeight=function(){
return dojo.html._callDeprecated("setMarginBoxHeight","setMarginBox",arguments,"height");
};
dojo.html.getMarginBoxWidth=dojo.html.getOuterWidth=function(){
return dojo.html._callDeprecated("getMarginBoxWidth","getMarginBox",arguments,null,"width");
};
dojo.html.getMarginBoxHeight=dojo.html.getOuterHeight=function(){
return dojo.html._callDeprecated("getMarginBoxHeight","getMarginBox",arguments,null,"height");
};
dojo.html.getTotalOffset=function(node,type,_52a){
return dojo.html._callDeprecated("getTotalOffset","getAbsolutePosition",arguments,null,type);
};
dojo.html.getAbsoluteX=function(node,_52c){
return dojo.html._callDeprecated("getAbsoluteX","getAbsolutePosition",arguments,null,"x");
};
dojo.html.getAbsoluteY=function(node,_52e){
return dojo.html._callDeprecated("getAbsoluteY","getAbsolutePosition",arguments,null,"y");
};
dojo.html.totalOffsetLeft=function(node,_530){
return dojo.html._callDeprecated("totalOffsetLeft","getAbsolutePosition",arguments,null,"left");
};
dojo.html.totalOffsetTop=function(node,_532){
return dojo.html._callDeprecated("totalOffsetTop","getAbsolutePosition",arguments,null,"top");
};
dojo.html.getMarginWidth=function(node){
return dojo.html._callDeprecated("getMarginWidth","getMargin",arguments,null,"width");
};
dojo.html.getMarginHeight=function(node){
return dojo.html._callDeprecated("getMarginHeight","getMargin",arguments,null,"height");
};
dojo.html.getBorderWidth=function(node){
return dojo.html._callDeprecated("getBorderWidth","getBorder",arguments,null,"width");
};
dojo.html.getBorderHeight=function(node){
return dojo.html._callDeprecated("getBorderHeight","getBorder",arguments,null,"height");
};
dojo.html.getPaddingWidth=function(node){
return dojo.html._callDeprecated("getPaddingWidth","getPadding",arguments,null,"width");
};
dojo.html.getPaddingHeight=function(node){
return dojo.html._callDeprecated("getPaddingHeight","getPadding",arguments,null,"height");
};
dojo.html.getPadBorderWidth=function(node){
return dojo.html._callDeprecated("getPadBorderWidth","getPadBorder",arguments,null,"width");
};
dojo.html.getPadBorderHeight=function(node){
return dojo.html._callDeprecated("getPadBorderHeight","getPadBorder",arguments,null,"height");
};
dojo.html.getBorderBoxWidth=dojo.html.getInnerWidth=function(){
return dojo.html._callDeprecated("getBorderBoxWidth","getBorderBox",arguments,null,"width");
};
dojo.html.getBorderBoxHeight=dojo.html.getInnerHeight=function(){
return dojo.html._callDeprecated("getBorderBoxHeight","getBorderBox",arguments,null,"height");
};
dojo.html.getContentBoxWidth=dojo.html.getContentWidth=function(){
return dojo.html._callDeprecated("getContentBoxWidth","getContentBox",arguments,null,"width");
};
dojo.html.getContentBoxHeight=dojo.html.getContentHeight=function(){
return dojo.html._callDeprecated("getContentBoxHeight","getContentBox",arguments,null,"height");
};
dojo.html.setContentBoxWidth=dojo.html.setContentWidth=function(node,_53c){
return dojo.html._callDeprecated("setContentBoxWidth","setContentBox",arguments,"width");
};
dojo.html.setContentBoxHeight=dojo.html.setContentHeight=function(node,_53e){
return dojo.html._callDeprecated("setContentBoxHeight","setContentBox",arguments,"height");
};
dojo.provide("dojo.html.util");
dojo.html.getElementWindow=function(_53f){
return dojo.html.getDocumentWindow(_53f.ownerDocument);
};
dojo.html.getDocumentWindow=function(doc){
if(dojo.render.html.safari&&!doc._parentWindow){
var fix=function(win){
win.document._parentWindow=win;
for(var i=0;i<win.frames.length;i++){
fix(win.frames[i]);
}
};
fix(window.top);
}
if(dojo.render.html.ie&&window!==document.parentWindow&&!doc._parentWindow){
doc.parentWindow.execScript("document._parentWindow = window;","Javascript");
var win=doc._parentWindow;
doc._parentWindow=null;
return win;
}
return doc._parentWindow||doc.parentWindow||doc.defaultView;
};
dojo.html.gravity=function(node,e){
node=dojo.byId(node);
var _547=dojo.html.getCursorPosition(e);
with(dojo.html){
var _548=getAbsolutePosition(node,true);
var bb=getBorderBox(node);
var _54a=_548.x+(bb.width/2);
var _54b=_548.y+(bb.height/2);
}
with(dojo.html.gravity){
return ((_547.x<_54a?WEST:EAST)|(_547.y<_54b?NORTH:SOUTH));
}
};
dojo.html.gravity.NORTH=1;
dojo.html.gravity.SOUTH=1<<1;
dojo.html.gravity.EAST=1<<2;
dojo.html.gravity.WEST=1<<3;
dojo.html.overElement=function(_54c,e){
_54c=dojo.byId(_54c);
var _54e=dojo.html.getCursorPosition(e);
with(dojo.html){
var bb=getBorderBox(_54c);
var _550=getAbsolutePosition(_54c,true,dojo.html.boxSizing.BORDER_BOX);
var top=_550.y;
var _552=top+bb.height;
var left=_550.x;
var _554=left+bb.width;
}
return (_54e.x>=left&&_54e.x<=_554&&_54e.y>=top&&_54e.y<=_552);
};
dojo.html.renderedTextContent=function(node){
node=dojo.byId(node);
var _556="";
if(node==null){
return _556;
}
for(var i=0;i<node.childNodes.length;i++){
switch(node.childNodes[i].nodeType){
case 1:
case 5:
var _558="unknown";
try{
_558=dojo.html.getStyle(node.childNodes[i],"display");
}
catch(E){
}
switch(_558){
case "block":
case "list-item":
case "run-in":
case "table":
case "table-row-group":
case "table-header-group":
case "table-footer-group":
case "table-row":
case "table-column-group":
case "table-column":
case "table-cell":
case "table-caption":
_556+="\n";
_556+=dojo.html.renderedTextContent(node.childNodes[i]);
_556+="\n";
break;
case "none":
break;
default:
if(node.childNodes[i].tagName&&node.childNodes[i].tagName.toLowerCase()=="br"){
_556+="\n";
}else{
_556+=dojo.html.renderedTextContent(node.childNodes[i]);
}
break;
}
break;
case 3:
case 2:
case 4:
var text=node.childNodes[i].nodeValue;
var _55a="unknown";
try{
_55a=dojo.html.getStyle(node,"text-transform");
}
catch(E){
}
switch(_55a){
case "capitalize":
var _55b=text.split(" ");
for(var i=0;i<_55b.length;i++){
_55b[i]=_55b[i].charAt(0).toUpperCase()+_55b[i].substring(1);
}
text=_55b.join(" ");
break;
case "uppercase":
text=text.toUpperCase();
break;
case "lowercase":
text=text.toLowerCase();
break;
default:
break;
}
switch(_55a){
case "nowrap":
break;
case "pre-wrap":
break;
case "pre-line":
break;
case "pre":
break;
default:
text=text.replace(/\s+/," ");
if(/\s$/.test(_556)){
text.replace(/^\s/,"");
}
break;
}
_556+=text;
break;
default:
break;
}
}
return _556;
};
dojo.html.createNodesFromText=function(txt,trim){
if(trim){
txt=txt.replace(/^\s+|\s+$/g,"");
}
var tn=dojo.doc().createElement("div");
tn.style.visibility="hidden";
dojo.body().appendChild(tn);
var _55f="none";
if((/^<t[dh][\s\r\n>]/i).test(txt.replace(/^\s+/))){
txt="<table><tbody><tr>"+txt+"</tr></tbody></table>";
_55f="cell";
}else{
if((/^<tr[\s\r\n>]/i).test(txt.replace(/^\s+/))){
txt="<table><tbody>"+txt+"</tbody></table>";
_55f="row";
}else{
if((/^<(thead|tbody|tfoot)[\s\r\n>]/i).test(txt.replace(/^\s+/))){
txt="<table>"+txt+"</table>";
_55f="section";
}
}
}
tn.innerHTML=txt;
if(tn["normalize"]){
tn.normalize();
}
var _560=null;
switch(_55f){
case "cell":
_560=tn.getElementsByTagName("tr")[0];
break;
case "row":
_560=tn.getElementsByTagName("tbody")[0];
break;
case "section":
_560=tn.getElementsByTagName("table")[0];
break;
default:
_560=tn;
break;
}
var _561=[];
for(var x=0;x<_560.childNodes.length;x++){
_561.push(_560.childNodes[x].cloneNode(true));
}
tn.style.display="none";
dojo.body().removeChild(tn);
return _561;
};
dojo.html.placeOnScreen=function(node,_564,_565,_566,_567,_568,_569){
if(_564 instanceof Array||typeof _564=="array"){
_569=_568;
_568=_567;
_567=_566;
_566=_565;
_565=_564[1];
_564=_564[0];
}
if(_568 instanceof String||typeof _568=="string"){
_568=_568.split(",");
}
if(!isNaN(_566)){
_566=[Number(_566),Number(_566)];
}else{
if(!(_566 instanceof Array||typeof _566=="array")){
_566=[0,0];
}
}
var _56a=dojo.html.getScroll().offset;
var view=dojo.html.getViewport();
node=dojo.byId(node);
var _56c=node.style.display;
node.style.display="";
var bb=dojo.html.getBorderBox(node);
var w=bb.width;
var h=bb.height;
node.style.display=_56c;
if(!(_568 instanceof Array||typeof _568=="array")){
_568=["TL"];
}
var _570,besty,bestDistance=Infinity;
for(var _571=0;_571<_568.length;++_571){
var _572=_568[_571];
var _573=true;
var tryX=_564-(_572.charAt(1)=="L"?0:w)+_566[0]*(_572.charAt(1)=="L"?1:-1);
var tryY=_565-(_572.charAt(0)=="T"?0:h)+_566[1]*(_572.charAt(0)=="T"?1:-1);
if(_567){
tryX-=_56a.x;
tryY-=_56a.y;
}
var x=tryX+w;
if(x>view.width){
x=view.width-w;
_573=false;
}else{
x=tryX;
}
x=Math.max(_566[0],x)+_56a.x;
var y=tryY+h;
if(y>view.height){
y=view.height-h;
_573=false;
}else{
y=tryY;
}
y=Math.max(_566[1],y)+_56a.y;
if(_573){
_570=x;
besty=y;
bestDistance=0;
break;
}else{
var dist=Math.pow(x-tryX-_56a.x,2)+Math.pow(y-tryY-_56a.y,2);
if(bestDistance>dist){
bestDistance=dist;
_570=x;
besty=y;
}
}
}
if(!_569){
node.style.left=_570+"px";
node.style.top=besty+"px";
}
return {left:_570,top:besty,x:_570,y:besty,dist:bestDistance};
};
dojo.html.placeOnScreenPoint=function(node,_57a,_57b,_57c,_57d){
dojo.deprecated("dojo.html.placeOnScreenPoint","use dojo.html.placeOnScreen() instead","0.5");
return dojo.html.placeOnScreen(node,_57a,_57b,_57c,_57d,["TL","TR","BL","BR"]);
};
dojo.html.placeOnScreenAroundElement=function(node,_57f,_580,_581,_582,_583){
var best,bestDistance=Infinity;
_57f=dojo.byId(_57f);
var _585=_57f.style.display;
_57f.style.display="";
var mb=dojo.html.getElementBox(_57f,_581);
var _587=mb.width;
var _588=mb.height;
var _589=dojo.html.getAbsolutePosition(_57f,true,_581);
_57f.style.display=_585;
for(var _58a in _582){
var pos,desiredX,desiredY;
var _58c=_582[_58a];
desiredX=_589.x+(_58a.charAt(1)=="L"?0:_587);
desiredY=_589.y+(_58a.charAt(0)=="T"?0:_588);
pos=dojo.html.placeOnScreen(node,desiredX,desiredY,_580,true,_58c,true);
if(pos.dist==0){
best=pos;
break;
}else{
if(bestDistance>pos.dist){
bestDistance=pos.dist;
best=pos;
}
}
}
if(!_583){
node.style.left=best.left+"px";
node.style.top=best.top+"px";
}
return best;
};
dojo.html.scrollIntoView=function(node){
if(!node){
return;
}
if(dojo.render.html.ie){
if(dojo.html.getBorderBox(node.parentNode).height<node.parentNode.scrollHeight){
node.scrollIntoView(false);
}
}else{
if(dojo.render.html.mozilla){
node.scrollIntoView(false);
}else{
var _58e=node.parentNode;
var _58f=_58e.scrollTop+dojo.html.getBorderBox(_58e).height;
var _590=node.offsetTop+dojo.html.getMarginBox(node).height;
if(_58f<_590){
_58e.scrollTop+=(_590-_58f);
}else{
if(_58e.scrollTop>node.offsetTop){
_58e.scrollTop-=(_58e.scrollTop-node.offsetTop);
}
}
}
}
};
dojo.provide("dojo.gfx.color");
dojo.gfx.color.Color=function(r,g,b,a){
if(dojo.lang.isArray(r)){
this.r=r[0];
this.g=r[1];
this.b=r[2];
this.a=r[3]||1;
}else{
if(dojo.lang.isString(r)){
var rgb=dojo.gfx.color.extractRGB(r);
this.r=rgb[0];
this.g=rgb[1];
this.b=rgb[2];
this.a=g||1;
}else{
if(r instanceof dojo.gfx.color.Color){
this.r=r.r;
this.b=r.b;
this.g=r.g;
this.a=r.a;
}else{
this.r=r;
this.g=g;
this.b=b;
this.a=a;
}
}
}
};
dojo.gfx.color.Color.fromArray=function(arr){
return new dojo.gfx.color.Color(arr[0],arr[1],arr[2],arr[3]);
};
dojo.extend(dojo.gfx.color.Color,{toRgb:function(_597){
if(_597){
return this.toRgba();
}else{
return [this.r,this.g,this.b];
}
},toRgba:function(){
return [this.r,this.g,this.b,this.a];
},toHex:function(){
return dojo.gfx.color.rgb2hex(this.toRgb());
},toCss:function(){
return "rgb("+this.toRgb().join()+")";
},toString:function(){
return this.toHex();
},blend:function(_598,_599){
var rgb=null;
if(dojo.lang.isArray(_598)){
rgb=_598;
}else{
if(_598 instanceof dojo.gfx.color.Color){
rgb=_598.toRgb();
}else{
rgb=new dojo.gfx.color.Color(_598).toRgb();
}
}
return dojo.gfx.color.blend(this.toRgb(),rgb,_599);
}});
dojo.gfx.color.named={white:[255,255,255],black:[0,0,0],red:[255,0,0],green:[0,255,0],blue:[0,0,255],navy:[0,0,128],gray:[128,128,128],silver:[192,192,192]};
dojo.gfx.color.blend=function(a,b,_59d){
if(typeof a=="string"){
return dojo.gfx.color.blendHex(a,b,_59d);
}
if(!_59d){
_59d=0;
}
_59d=Math.min(Math.max(-1,_59d),1);
_59d=((_59d+1)/2);
var c=[];
for(var x=0;x<3;x++){
c[x]=parseInt(b[x]+((a[x]-b[x])*_59d));
}
return c;
};
dojo.gfx.color.blendHex=function(a,b,_5a2){
return dojo.gfx.color.rgb2hex(dojo.gfx.color.blend(dojo.gfx.color.hex2rgb(a),dojo.gfx.color.hex2rgb(b),_5a2));
};
dojo.gfx.color.extractRGB=function(_5a3){
var hex="0123456789abcdef";
_5a3=_5a3.toLowerCase();
if(_5a3.indexOf("rgb")==0){
var _5a5=_5a3.match(/rgba*\((\d+), *(\d+), *(\d+)/i);
var ret=_5a5.splice(1,3);
return ret;
}else{
var _5a7=dojo.gfx.color.hex2rgb(_5a3);
if(_5a7){
return _5a7;
}else{
return dojo.gfx.color.named[_5a3]||[255,255,255];
}
}
};
dojo.gfx.color.hex2rgb=function(hex){
var _5a9="0123456789ABCDEF";
var rgb=new Array(3);
if(hex.indexOf("#")==0){
hex=hex.substring(1);
}
hex=hex.toUpperCase();
if(hex.replace(new RegExp("["+_5a9+"]","g"),"")!=""){
return null;
}
if(hex.length==3){
rgb[0]=hex.charAt(0)+hex.charAt(0);
rgb[1]=hex.charAt(1)+hex.charAt(1);
rgb[2]=hex.charAt(2)+hex.charAt(2);
}else{
rgb[0]=hex.substring(0,2);
rgb[1]=hex.substring(2,4);
rgb[2]=hex.substring(4);
}
for(var i=0;i<rgb.length;i++){
rgb[i]=_5a9.indexOf(rgb[i].charAt(0))*16+_5a9.indexOf(rgb[i].charAt(1));
}
return rgb;
};
dojo.gfx.color.rgb2hex=function(r,g,b){
if(dojo.lang.isArray(r)){
g=r[1]||0;
b=r[2]||0;
r=r[0]||0;
}
var ret=dojo.lang.map([r,g,b],function(x){
x=new Number(x);
var s=x.toString(16);
while(s.length<2){
s="0"+s;
}
return s;
});
ret.unshift("#");
return ret.join("");
};
dojo.provide("dojo.lfx.Animation");
dojo.provide("dojo.lfx.Line");
dojo.lfx.Line=function(_5b2,end){
this.start=_5b2;
this.end=end;
if(dojo.lang.isArray(_5b2)){
var diff=[];
dojo.lang.forEach(this.start,function(s,i){
diff[i]=this.end[i]-s;
},this);
this.getValue=function(n){
var res=[];
dojo.lang.forEach(this.start,function(s,i){
res[i]=(diff[i]*n)+s;
},this);
return res;
};
}else{
var diff=end-_5b2;
this.getValue=function(n){
return (diff*n)+this.start;
};
}
};
dojo.lfx.easeDefault=function(n){
if(dojo.render.html.khtml){
return (parseFloat("0.5")+((Math.sin((n+parseFloat("1.5"))*Math.PI))/2));
}else{
return (0.5+((Math.sin((n+1.5)*Math.PI))/2));
dojo.debug(ret);
}
};
dojo.lfx.easeIn=function(n){
return Math.pow(n,3);
};
dojo.lfx.easeOut=function(n){
return (1-Math.pow(1-n,3));
};
dojo.lfx.easeInOut=function(n){
return ((3*Math.pow(n,2))-(2*Math.pow(n,3)));
};
dojo.lfx.IAnimation=function(){
};
dojo.lang.extend(dojo.lfx.IAnimation,{curve:null,duration:1000,easing:null,repeatCount:0,rate:25,handler:null,beforeBegin:null,onBegin:null,onAnimate:null,onEnd:null,onPlay:null,onPause:null,onStop:null,play:null,pause:null,stop:null,connect:function(evt,_5c1,_5c2){
if(!_5c2){
_5c2=_5c1;
_5c1=this;
}
_5c2=dojo.lang.hitch(_5c1,_5c2);
var _5c3=this[evt]||function(){
};
this[evt]=function(){
var ret=_5c3.apply(this,arguments);
_5c2.apply(this,arguments);
return ret;
};
return this;
},fire:function(evt,args){
if(this[evt]){
this[evt].apply(this,(args||[]));
}
return this;
},repeat:function(_5c7){
this.repeatCount=_5c7;
return this;
},_active:false,_paused:false});
dojo.lfx.Animation=function(_5c8,_5c9,_5ca,_5cb,_5cc,rate){
dojo.lfx.IAnimation.call(this);
if(dojo.lang.isNumber(_5c8)||(!_5c8&&_5c9.getValue)){
rate=_5cc;
_5cc=_5cb;
_5cb=_5ca;
_5ca=_5c9;
_5c9=_5c8;
_5c8=null;
}else{
if(_5c8.getValue||dojo.lang.isArray(_5c8)){
rate=_5cb;
_5cc=_5ca;
_5cb=_5c9;
_5ca=_5c8;
_5c9=null;
_5c8=null;
}
}
if(dojo.lang.isArray(_5ca)){
this.curve=new dojo.lfx.Line(_5ca[0],_5ca[1]);
}else{
this.curve=_5ca;
}
if(_5c9!=null&&_5c9>0){
this.duration=_5c9;
}
if(_5cc){
this.repeatCount=_5cc;
}
if(rate){
this.rate=rate;
}
if(_5c8){
dojo.lang.forEach(["handler","beforeBegin","onBegin","onEnd","onPlay","onStop","onAnimate"],function(item){
if(_5c8[item]){
this.connect(item,_5c8[item]);
}
},this);
}
if(_5cb&&dojo.lang.isFunction(_5cb)){
this.easing=_5cb;
}
};
dojo.inherits(dojo.lfx.Animation,dojo.lfx.IAnimation);
dojo.lang.extend(dojo.lfx.Animation,{_startTime:null,_endTime:null,_timer:null,_percent:0,_startRepeatCount:0,play:function(_5cf,_5d0){
if(_5d0){
clearTimeout(this._timer);
this._active=false;
this._paused=false;
this._percent=0;
}else{
if(this._active&&!this._paused){
return this;
}
}
this.fire("handler",["beforeBegin"]);
this.fire("beforeBegin");
if(_5cf>0){
setTimeout(dojo.lang.hitch(this,function(){
this.play(null,_5d0);
}),_5cf);
return this;
}
this._startTime=new Date().valueOf();
if(this._paused){
this._startTime-=(this.duration*this._percent/100);
}
this._endTime=this._startTime+this.duration;
this._active=true;
this._paused=false;
var step=this._percent/100;
var _5d2=this.curve.getValue(step);
if(this._percent==0){
if(!this._startRepeatCount){
this._startRepeatCount=this.repeatCount;
}
this.fire("handler",["begin",_5d2]);
this.fire("onBegin",[_5d2]);
}
this.fire("handler",["play",_5d2]);
this.fire("onPlay",[_5d2]);
this._cycle();
return this;
},pause:function(){
clearTimeout(this._timer);
if(!this._active){
return this;
}
this._paused=true;
var _5d3=this.curve.getValue(this._percent/100);
this.fire("handler",["pause",_5d3]);
this.fire("onPause",[_5d3]);
return this;
},gotoPercent:function(pct,_5d5){
clearTimeout(this._timer);
this._active=true;
this._paused=true;
this._percent=pct;
if(_5d5){
this.play();
}
return this;
},stop:function(_5d6){
clearTimeout(this._timer);
var step=this._percent/100;
if(_5d6){
step=1;
}
var _5d8=this.curve.getValue(step);
this.fire("handler",["stop",_5d8]);
this.fire("onStop",[_5d8]);
this._active=false;
this._paused=false;
return this;
},status:function(){
if(this._active){
return this._paused?"paused":"playing";
}else{
return "stopped";
}
return this;
},_cycle:function(){
clearTimeout(this._timer);
if(this._active){
var curr=new Date().valueOf();
var step=(curr-this._startTime)/(this._endTime-this._startTime);
if(step>=1){
step=1;
this._percent=100;
}else{
this._percent=step*100;
}
if((this.easing)&&(dojo.lang.isFunction(this.easing))){
step=this.easing(step);
}
var _5db=this.curve.getValue(step);
this.fire("handler",["animate",_5db]);
this.fire("onAnimate",[_5db]);
if(step<1){
this._timer=setTimeout(dojo.lang.hitch(this,"_cycle"),this.rate);
}else{
this._active=false;
this.fire("handler",["end"]);
this.fire("onEnd");
if(this.repeatCount>0){
this.repeatCount--;
this.play(null,true);
}else{
if(this.repeatCount==-1){
this.play(null,true);
}else{
if(this._startRepeatCount){
this.repeatCount=this._startRepeatCount;
this._startRepeatCount=0;
}
}
}
}
}
return this;
}});
dojo.lfx.Combine=function(){
dojo.lfx.IAnimation.call(this);
this._anims=[];
this._animsEnded=0;
var _5dc=arguments;
if(_5dc.length==1&&(dojo.lang.isArray(_5dc[0])||dojo.lang.isArrayLike(_5dc[0]))){
_5dc=_5dc[0];
}
dojo.lang.forEach(_5dc,function(anim){
this._anims.push(anim);
anim.connect("onEnd",dojo.lang.hitch(this,"_onAnimsEnded"));
},this);
};
dojo.inherits(dojo.lfx.Combine,dojo.lfx.IAnimation);
dojo.lang.extend(dojo.lfx.Combine,{_animsEnded:0,play:function(_5de,_5df){
if(!this._anims.length){
return this;
}
this.fire("beforeBegin");
if(_5de>0){
setTimeout(dojo.lang.hitch(this,function(){
this.play(null,_5df);
}),_5de);
return this;
}
if(_5df||this._anims[0].percent==0){
this.fire("onBegin");
}
this.fire("onPlay");
this._animsCall("play",null,_5df);
return this;
},pause:function(){
this.fire("onPause");
this._animsCall("pause");
return this;
},stop:function(_5e0){
this.fire("onStop");
this._animsCall("stop",_5e0);
return this;
},_onAnimsEnded:function(){
this._animsEnded++;
if(this._animsEnded>=this._anims.length){
this.fire("onEnd");
}
return this;
},_animsCall:function(_5e1){
var args=[];
if(arguments.length>1){
for(var i=1;i<arguments.length;i++){
args.push(arguments[i]);
}
}
var _5e4=this;
dojo.lang.forEach(this._anims,function(anim){
anim[_5e1](args);
},_5e4);
return this;
}});
dojo.lfx.Chain=function(){
dojo.lfx.IAnimation.call(this);
this._anims=[];
this._currAnim=-1;
var _5e6=arguments;
if(_5e6.length==1&&(dojo.lang.isArray(_5e6[0])||dojo.lang.isArrayLike(_5e6[0]))){
_5e6=_5e6[0];
}
var _5e7=this;
dojo.lang.forEach(_5e6,function(anim,i,_5ea){
this._anims.push(anim);
if(i<_5ea.length-1){
anim.connect("onEnd",dojo.lang.hitch(this,"_playNext"));
}else{
anim.connect("onEnd",dojo.lang.hitch(this,function(){
this.fire("onEnd");
}));
}
},this);
};
dojo.inherits(dojo.lfx.Chain,dojo.lfx.IAnimation);
dojo.lang.extend(dojo.lfx.Chain,{_currAnim:-1,play:function(_5eb,_5ec){
if(!this._anims.length){
return this;
}
if(_5ec||!this._anims[this._currAnim]){
this._currAnim=0;
}
var _5ed=this._anims[this._currAnim];
this.fire("beforeBegin");
if(_5eb>0){
setTimeout(dojo.lang.hitch(this,function(){
this.play(null,_5ec);
}),_5eb);
return this;
}
if(_5ed){
if(this._currAnim==0){
this.fire("handler",["begin",this._currAnim]);
this.fire("onBegin",[this._currAnim]);
}
this.fire("onPlay",[this._currAnim]);
_5ed.play(null,_5ec);
}
return this;
},pause:function(){
if(this._anims[this._currAnim]){
this._anims[this._currAnim].pause();
this.fire("onPause",[this._currAnim]);
}
return this;
},playPause:function(){
if(this._anims.length==0){
return this;
}
if(this._currAnim==-1){
this._currAnim=0;
}
var _5ee=this._anims[this._currAnim];
if(_5ee){
if(!_5ee._active||_5ee._paused){
this.play();
}else{
this.pause();
}
}
return this;
},stop:function(){
var _5ef=this._anims[this._currAnim];
if(_5ef){
_5ef.stop();
this.fire("onStop",[this._currAnim]);
}
return _5ef;
},_playNext:function(){
if(this._currAnim==-1||this._anims.length==0){
return this;
}
this._currAnim++;
if(this._anims[this._currAnim]){
this._anims[this._currAnim].play(null,true);
}
return this;
}});
dojo.lfx.combine=function(){
var _5f0=arguments;
if(dojo.lang.isArray(arguments[0])){
_5f0=arguments[0];
}
if(_5f0.length==1){
return _5f0[0];
}
return new dojo.lfx.Combine(_5f0);
};
dojo.lfx.chain=function(){
var _5f1=arguments;
if(dojo.lang.isArray(arguments[0])){
_5f1=arguments[0];
}
if(_5f1.length==1){
return _5f1[0];
}
return new dojo.lfx.Chain(_5f1);
};
dojo.provide("dojo.html.color");
dojo.html.getBackgroundColor=function(node){
node=dojo.byId(node);
var _5f3;
do{
_5f3=dojo.html.getStyle(node,"background-color");
if(_5f3.toLowerCase()=="rgba(0, 0, 0, 0)"){
_5f3="transparent";
}
if(node==document.getElementsByTagName("body")[0]){
node=null;
break;
}
node=node.parentNode;
}while(node&&dojo.lang.inArray(["transparent",""],_5f3));
if(_5f3=="transparent"){
_5f3=[255,255,255,0];
}else{
_5f3=dojo.gfx.color.extractRGB(_5f3);
}
return _5f3;
};
dojo.provide("dojo.lfx.html");
dojo.lfx.html._byId=function(_5f4){
if(!_5f4){
return [];
}
if(dojo.lang.isArrayLike(_5f4)){
if(!_5f4.alreadyChecked){
var n=[];
dojo.lang.forEach(_5f4,function(node){
n.push(dojo.byId(node));
});
n.alreadyChecked=true;
return n;
}else{
return _5f4;
}
}else{
var n=[];
n.push(dojo.byId(_5f4));
n.alreadyChecked=true;
return n;
}
};
dojo.lfx.html.propertyAnimation=function(_5f7,_5f8,_5f9,_5fa,_5fb){
_5f7=dojo.lfx.html._byId(_5f7);
var _5fc={"propertyMap":_5f8,"nodes":_5f7,"duration":_5f9,"easing":_5fa||dojo.lfx.easeDefault};
var _5fd=function(args){
if(args.nodes.length==1){
var pm=args.propertyMap;
if(!dojo.lang.isArray(args.propertyMap)){
var parr=[];
for(var _601 in pm){
pm[_601].property=_601;
parr.push(pm[_601]);
}
pm=args.propertyMap=parr;
}
dojo.lang.forEach(pm,function(prop){
if(dj_undef("start",prop)){
if(prop.property!="opacity"){
prop.start=parseInt(dojo.html.getComputedStyle(args.nodes[0],prop.property));
}else{
prop.start=dojo.html.getOpacity(args.nodes[0]);
}
}
});
}
};
var _603=function(_604){
var _605=[];
dojo.lang.forEach(_604,function(c){
_605.push(Math.round(c));
});
return _605;
};
var _607=function(n,_609){
n=dojo.byId(n);
if(!n||!n.style){
return;
}
for(var s in _609){
if(s=="opacity"){
dojo.html.setOpacity(n,_609[s]);
}else{
n.style[s]=_609[s];
}
}
};
var _60b=function(_60c){
this._properties=_60c;
this.diffs=new Array(_60c.length);
dojo.lang.forEach(_60c,function(prop,i){
if(dojo.lang.isFunction(prop.start)){
prop.start=prop.start(prop,i);
}
if(dojo.lang.isFunction(prop.end)){
prop.end=prop.end(prop,i);
}
if(dojo.lang.isArray(prop.start)){
this.diffs[i]=null;
}else{
if(prop.start instanceof dojo.gfx.color.Color){
prop.startRgb=prop.start.toRgb();
prop.endRgb=prop.end.toRgb();
}else{
this.diffs[i]=prop.end-prop.start;
}
}
},this);
this.getValue=function(n){
var ret={};
dojo.lang.forEach(this._properties,function(prop,i){
var _613=null;
if(dojo.lang.isArray(prop.start)){
}else{
if(prop.start instanceof dojo.gfx.color.Color){
_613=(prop.units||"rgb")+"(";
for(var j=0;j<prop.startRgb.length;j++){
_613+=Math.round(((prop.endRgb[j]-prop.startRgb[j])*n)+prop.startRgb[j])+(j<prop.startRgb.length-1?",":"");
}
_613+=")";
}else{
_613=((this.diffs[i])*n)+prop.start+(prop.property!="opacity"?prop.units||"px":"");
}
}
ret[dojo.html.toCamelCase(prop.property)]=_613;
},this);
return ret;
};
};
var anim=new dojo.lfx.Animation({beforeBegin:function(){
_5fd(_5fc);
anim.curve=new _60b(_5fc.propertyMap);
},onAnimate:function(_616){
dojo.lang.forEach(_5fc.nodes,function(node){
_607(node,_616);
});
}},_5fc.duration,null,_5fc.easing);
if(_5fb){
for(var x in _5fb){
if(dojo.lang.isFunction(_5fb[x])){
anim.connect(x,anim,_5fb[x]);
}
}
}
return anim;
};
dojo.lfx.html._makeFadeable=function(_619){
var _61a=function(node){
if(dojo.render.html.ie){
if((node.style.zoom.length==0)&&(dojo.html.getStyle(node,"zoom")=="normal")){
node.style.zoom="1";
}
if((node.style.width.length==0)&&(dojo.html.getStyle(node,"width")=="auto")){
node.style.width="auto";
}
}
};
if(dojo.lang.isArrayLike(_619)){
dojo.lang.forEach(_619,_61a);
}else{
_61a(_619);
}
};
dojo.lfx.html.fade=function(_61c,_61d,_61e,_61f,_620){
_61c=dojo.lfx.html._byId(_61c);
var _621={property:"opacity"};
if(!dj_undef("start",_61d)){
_621.start=_61d.start;
}else{
_621.start=function(){
return dojo.html.getOpacity(_61c[0]);
};
}
if(!dj_undef("end",_61d)){
_621.end=_61d.end;
}else{
dojo.raise("dojo.lfx.html.fade needs an end value");
}
var anim=dojo.lfx.propertyAnimation(_61c,[_621],_61e,_61f);
anim.connect("beforeBegin",function(){
dojo.lfx.html._makeFadeable(_61c);
});
if(_620){
anim.connect("onEnd",function(){
_620(_61c,anim);
});
}
return anim;
};
dojo.lfx.html.fadeIn=function(_623,_624,_625,_626){
return dojo.lfx.html.fade(_623,{end:1},_624,_625,_626);
};
dojo.lfx.html.fadeOut=function(_627,_628,_629,_62a){
return dojo.lfx.html.fade(_627,{end:0},_628,_629,_62a);
};
dojo.lfx.html.fadeShow=function(_62b,_62c,_62d,_62e){
_62b=dojo.lfx.html._byId(_62b);
dojo.lang.forEach(_62b,function(node){
dojo.html.setOpacity(node,0);
});
var anim=dojo.lfx.html.fadeIn(_62b,_62c,_62d,_62e);
anim.connect("beforeBegin",function(){
if(dojo.lang.isArrayLike(_62b)){
dojo.lang.forEach(_62b,dojo.html.show);
}else{
dojo.html.show(_62b);
}
});
return anim;
};
dojo.lfx.html.fadeHide=function(_631,_632,_633,_634){
var anim=dojo.lfx.html.fadeOut(_631,_632,_633,function(){
if(dojo.lang.isArrayLike(_631)){
dojo.lang.forEach(_631,dojo.html.hide);
}else{
dojo.html.hide(_631);
}
if(_634){
_634(_631,anim);
}
});
return anim;
};
dojo.lfx.html.wipeIn=function(_636,_637,_638,_639){
_636=dojo.lfx.html._byId(_636);
var _63a=[];
dojo.lang.forEach(_636,function(node){
var _63c={overflow:null};
var anim=dojo.lfx.propertyAnimation(node,{"height":{start:0,end:function(){
return node.scrollHeight;
}}},_637,_638);
anim.connect("beforeBegin",function(){
_63c.overflow=dojo.html.getStyle(node,"overflow");
with(node.style){
if(_63c.overflow=="visible"){
overflow="hidden";
}
visibility="visible";
height="0px";
}
dojo.html.show(node);
});
anim.connect("onEnd",function(){
with(node.style){
overflow=_63c.overflow;
height="";
visibility="visible";
}
if(_639){
_639(node,anim);
}
});
_63a.push(anim);
});
return dojo.lfx.combine(_63a);
};
dojo.lfx.html.wipeOut=function(_63e,_63f,_640,_641){
_63e=dojo.lfx.html._byId(_63e);
var _642=[];
dojo.lang.forEach(_63e,function(node){
var _644={overflow:null};
var anim=dojo.lfx.propertyAnimation(node,{"height":{start:function(){
return dojo.html.getContentBox(node).height;
},end:0}},_63f,_640,{"beforeBegin":function(){
_644.overflow=dojo.html.getStyle(node,"overflow");
if(_644.overflow=="visible"){
node.style.overflow="hidden";
}
node.style.visibility="visible";
dojo.html.show(node);
},"onEnd":function(){
with(node.style){
overflow=_644.overflow;
visibility="hidden";
height="";
}
if(_641){
_641(node,anim);
}
}});
_642.push(anim);
});
return dojo.lfx.combine(_642);
};
dojo.lfx.html.slideTo=function(_646,_647,_648,_649,_64a){
_646=dojo.lfx.html._byId(_646);
var _64b=[];
var _64c=dojo.html.getComputedStyle;
if(dojo.lang.isArray(_647)){
dojo.deprecated("dojo.lfx.html.slideTo(node, array)","use dojo.lfx.html.slideTo(node, {top: value, left: value});","0.5");
_647={top:_647[0],left:_647[1]};
}
dojo.lang.forEach(_646,function(node){
var top=null;
var left=null;
var init=(function(){
var _651=node;
return function(){
var pos=_64c(_651,"position");
top=(pos=="absolute"?node.offsetTop:parseInt(_64c(node,"top"))||0);
left=(pos=="absolute"?node.offsetLeft:parseInt(_64c(node,"left"))||0);
if(!dojo.lang.inArray(["absolute","relative"],pos)){
var ret=dojo.html.abs(_651,true);
dojo.html.setStyleAttributes(_651,"position:absolute;top:"+ret.y+"px;left:"+ret.x+"px;");
top=ret.y;
left=ret.x;
}
};
})();
init();
var anim=dojo.lfx.propertyAnimation(node,{"top":{start:top,end:(_647.top||0)},"left":{start:left,end:(_647.left||0)}},_648,_649,{"beforeBegin":init});
if(_64a){
anim.connect("onEnd",function(){
_64a(_646,anim);
});
}
_64b.push(anim);
});
return dojo.lfx.combine(_64b);
};
dojo.lfx.html.slideBy=function(_655,_656,_657,_658,_659){
_655=dojo.lfx.html._byId(_655);
var _65a=[];
var _65b=dojo.html.getComputedStyle;
if(dojo.lang.isArray(_656)){
dojo.deprecated("dojo.lfx.html.slideBy(node, array)","use dojo.lfx.html.slideBy(node, {top: value, left: value});","0.5");
_656={top:_656[0],left:_656[1]};
}
dojo.lang.forEach(_655,function(node){
var top=null;
var left=null;
var init=(function(){
var _660=node;
return function(){
var pos=_65b(_660,"position");
top=(pos=="absolute"?node.offsetTop:parseInt(_65b(node,"top"))||0);
left=(pos=="absolute"?node.offsetLeft:parseInt(_65b(node,"left"))||0);
if(!dojo.lang.inArray(["absolute","relative"],pos)){
var ret=dojo.html.abs(_660,true);
dojo.html.setStyleAttributes(_660,"position:absolute;top:"+ret.y+"px;left:"+ret.x+"px;");
top=ret.y;
left=ret.x;
}
};
})();
init();
var anim=dojo.lfx.propertyAnimation(node,{"top":{start:top,end:top+(_656.top||0)},"left":{start:left,end:left+(_656.left||0)}},_657,_658).connect("beforeBegin",init);
if(_659){
anim.connect("onEnd",function(){
_659(_655,anim);
});
}
_65a.push(anim);
});
return dojo.lfx.combine(_65a);
};
dojo.lfx.html.explode=function(_664,_665,_666,_667,_668){
var h=dojo.html;
_664=dojo.byId(_664);
_665=dojo.byId(_665);
var _66a=h.toCoordinateObject(_664,true);
var _66b=document.createElement("div");
h.copyStyle(_66b,_665);
with(_66b.style){
position="absolute";
display="none";
}
dojo.body().appendChild(_66b);
with(_665.style){
visibility="hidden";
display="block";
}
var _66c=h.toCoordinateObject(_665,true);
_66b.style.backgroundColor=h.getStyle(_665,"background-color").toLowerCase();
with(_665.style){
display="none";
visibility="visible";
}
var _66d={opacity:{start:0.5,end:1}};
dojo.lang.forEach(["height","width","top","left"],function(type){
_66d[type]={start:_66a[type],end:_66c[type]};
});
var anim=new dojo.lfx.propertyAnimation(_66b,_66d,_666,_667,{"beforeBegin":function(){
h.setDisplay(_66b,"block");
},"onEnd":function(){
h.setDisplay(_665,"block");
_66b.parentNode.removeChild(_66b);
}});
if(_668){
anim.connect("onEnd",function(){
_668(_665,anim);
});
}
return anim;
};
dojo.lfx.html.implode=function(_670,end,_672,_673,_674){
var h=dojo.html;
_670=dojo.byId(_670);
end=dojo.byId(end);
var _676=dojo.html.toCoordinateObject(_670,true);
var _677=dojo.html.toCoordinateObject(end,true);
var _678=document.createElement("div");
dojo.html.copyStyle(_678,_670);
dojo.html.setOpacity(_678,0.3);
with(_678.style){
position="absolute";
display="none";
backgroundColor=h.getStyle(_670,"background-color").toLowerCase();
}
dojo.body().appendChild(_678);
var _679={opacity:{start:1,end:0.5}};
dojo.lang.forEach(["height","width","top","left"],function(type){
_679[type]={start:_676[type],end:_677[type]};
});
var anim=new dojo.lfx.propertyAnimation(_678,_679,_672,_673,{"beforeBegin":function(){
dojo.html.hide(_670);
dojo.html.show(_678);
},"onEnd":function(){
_678.parentNode.removeChild(_678);
}});
if(_674){
anim.connect("onEnd",function(){
_674(_670,anim);
});
}
return anim;
};
dojo.lfx.html.highlight=function(_67c,_67d,_67e,_67f,_680){
_67c=dojo.lfx.html._byId(_67c);
var _681=[];
dojo.lang.forEach(_67c,function(node){
var _683=dojo.html.getBackgroundColor(node);
var bg=dojo.html.getStyle(node,"background-color").toLowerCase();
var _685=dojo.html.getStyle(node,"background-image");
var _686=(bg=="transparent"||bg=="rgba(0, 0, 0, 0)");
while(_683.length>3){
_683.pop();
}
var rgb=new dojo.gfx.color.Color(_67d);
var _688=new dojo.gfx.color.Color(_683);
var anim=dojo.lfx.propertyAnimation(node,{"background-color":{start:rgb,end:_688}},_67e,_67f,{"beforeBegin":function(){
if(_685){
node.style.backgroundImage="none";
}
node.style.backgroundColor="rgb("+rgb.toRgb().join(",")+")";
},"onEnd":function(){
if(_685){
node.style.backgroundImage=_685;
}
if(_686){
node.style.backgroundColor="transparent";
}
if(_680){
_680(node,anim);
}
}});
_681.push(anim);
});
return dojo.lfx.combine(_681);
};
dojo.lfx.html.unhighlight=function(_68a,_68b,_68c,_68d,_68e){
_68a=dojo.lfx.html._byId(_68a);
var _68f=[];
dojo.lang.forEach(_68a,function(node){
var _691=new dojo.gfx.color.Color(dojo.html.getBackgroundColor(node));
var rgb=new dojo.gfx.color.Color(_68b);
var _693=dojo.html.getStyle(node,"background-image");
var anim=dojo.lfx.propertyAnimation(node,{"background-color":{start:_691,end:rgb}},_68c,_68d,{"beforeBegin":function(){
if(_693){
node.style.backgroundImage="none";
}
node.style.backgroundColor="rgb("+_691.toRgb().join(",")+")";
},"onEnd":function(){
if(_68e){
_68e(node,anim);
}
}});
_68f.push(anim);
});
return dojo.lfx.combine(_68f);
};
dojo.lang.mixin(dojo.lfx,dojo.lfx.html);
dojo.provide("dojo.lfx.*");
dojo.provide("dojo.lfx.toggle");
dojo.lfx.toggle.plain={show:function(node,_696,_697,_698){
dojo.html.show(node);
if(dojo.lang.isFunction(_698)){
_698();
}
},hide:function(node,_69a,_69b,_69c){
dojo.html.hide(node);
if(dojo.lang.isFunction(_69c)){
_69c();
}
}};
dojo.lfx.toggle.fade={show:function(node,_69e,_69f,_6a0){
dojo.lfx.fadeShow(node,_69e,_69f,_6a0).play();
},hide:function(node,_6a2,_6a3,_6a4){
dojo.lfx.fadeHide(node,_6a2,_6a3,_6a4).play();
}};
dojo.lfx.toggle.wipe={show:function(node,_6a6,_6a7,_6a8){
dojo.lfx.wipeIn(node,_6a6,_6a7,_6a8).play();
},hide:function(node,_6aa,_6ab,_6ac){
dojo.lfx.wipeOut(node,_6aa,_6ab,_6ac).play();
}};
dojo.lfx.toggle.explode={show:function(node,_6ae,_6af,_6b0,_6b1){
dojo.lfx.explode(_6b1||{x:0,y:0,width:0,height:0},node,_6ae,_6af,_6b0).play();
},hide:function(node,_6b3,_6b4,_6b5,_6b6){
dojo.lfx.implode(node,_6b6||{x:0,y:0,width:0,height:0},_6b3,_6b4,_6b5).play();
}};
dojo.provide("dojo.widget.HtmlWidget");
dojo.declare("dojo.widget.HtmlWidget",dojo.widget.DomWidget,{widgetType:"HtmlWidget",templateCssPath:null,templatePath:null,lang:"",toggle:"plain",toggleDuration:150,animationInProgress:false,initialize:function(args,frag){
},postMixInProperties:function(args,frag){
if(this.lang===""){
this.lang=null;
}
this.toggleObj=dojo.lfx.toggle[this.toggle.toLowerCase()]||dojo.lfx.toggle.plain;
},getContainerHeight:function(){
dojo.unimplemented("dojo.widget.HtmlWidget.getContainerHeight");
},getContainerWidth:function(){
return this.parent.domNode.offsetWidth;
},setNativeHeight:function(_6bb){
var ch=this.getContainerHeight();
},createNodesFromText:function(txt,wrap){
return dojo.html.createNodesFromText(txt,wrap);
},destroyRendering:function(_6bf){
try{
if(!_6bf&&this.domNode){
dojo.event.browser.clean(this.domNode);
}
this.domNode.parentNode.removeChild(this.domNode);
delete this.domNode;
}
catch(e){
}
},isShowing:function(){
return dojo.html.isShowing(this.domNode);
},toggleShowing:function(){
if(this.isHidden){
this.show();
}else{
this.hide();
}
},show:function(){
this.animationInProgress=true;
this.isHidden=false;
this.toggleObj.show(this.domNode,this.toggleDuration,null,dojo.lang.hitch(this,this.onShow),this.explodeSrc);
},onShow:function(){
this.animationInProgress=false;
this.checkSize();
},hide:function(){
this.animationInProgress=true;
this.isHidden=true;
this.toggleObj.hide(this.domNode,this.toggleDuration,null,dojo.lang.hitch(this,this.onHide),this.explodeSrc);
},onHide:function(){
this.animationInProgress=false;
},_isResized:function(w,h){
if(!this.isShowing()){
return false;
}
var wh=dojo.html.getMarginBox(this.domNode);
var _6c3=w||wh.width;
var _6c4=h||wh.height;
if(this.width==_6c3&&this.height==_6c4){
return false;
}
this.width=_6c3;
this.height=_6c4;
return true;
},checkSize:function(){
if(!this._isResized()){
return;
}
this.onResized();
},resizeTo:function(w,h){
if(!this._isResized(w,h)){
return;
}
dojo.html.setMarginBox(this.domNode,{width:w,height:h});
this.onResized();
},resizeSoon:function(){
if(this.isShowing()){
dojo.lang.setTimeout(this,this.onResized,0);
}
},onResized:function(){
dojo.lang.forEach(this.children,function(_6c7){
if(_6c7.checkSize){
_6c7.checkSize();
}
});
}});
dojo.provide("dojo.widget.*");
dojo.provide("dojo.string.common");
dojo.string.trim=function(str,wh){
if(!str.replace){
return str;
}
if(!str.length){
return str;
}
var re=(wh>0)?(/^\s+/):(wh<0)?(/\s+$/):(/^\s+|\s+$/g);
return str.replace(re,"");
};
dojo.string.trimStart=function(str){
return dojo.string.trim(str,1);
};
dojo.string.trimEnd=function(str){
return dojo.string.trim(str,-1);
};
dojo.string.repeat=function(str,_6ce,_6cf){
var out="";
for(var i=0;i<_6ce;i++){
out+=str;
if(_6cf&&i<_6ce-1){
out+=_6cf;
}
}
return out;
};
dojo.string.pad=function(str,len,c,dir){
var out=String(str);
if(!c){
c="0";
}
if(!dir){
dir=1;
}
while(out.length<len){
if(dir>0){
out=c+out;
}else{
out+=c;
}
}
return out;
};
dojo.string.padLeft=function(str,len,c){
return dojo.string.pad(str,len,c,1);
};
dojo.string.padRight=function(str,len,c){
return dojo.string.pad(str,len,c,-1);
};
dojo.provide("dojo.string");
dojo.provide("dojo.io.common");
dojo.io.transports=[];
dojo.io.hdlrFuncNames=["load","error","timeout"];
dojo.io.Request=function(url,_6de,_6df,_6e0){
if((arguments.length==1)&&(arguments[0].constructor==Object)){
this.fromKwArgs(arguments[0]);
}else{
this.url=url;
if(_6de){
this.mimetype=_6de;
}
if(_6df){
this.transport=_6df;
}
if(arguments.length>=4){
this.changeUrl=_6e0;
}
}
};
dojo.lang.extend(dojo.io.Request,{url:"",mimetype:"text/plain",method:"GET",content:undefined,transport:undefined,changeUrl:undefined,formNode:undefined,sync:false,bindSuccess:false,useCache:false,preventCache:false,load:function(type,data,evt){
},error:function(type,_6e5){
},timeout:function(type){
},handle:function(){
},timeoutSeconds:0,abort:function(){
},fromKwArgs:function(_6e7){
if(_6e7["url"]){
_6e7.url=_6e7.url.toString();
}
if(_6e7["formNode"]){
_6e7.formNode=dojo.byId(_6e7.formNode);
}
if(!_6e7["method"]&&_6e7["formNode"]&&_6e7["formNode"].method){
_6e7.method=_6e7["formNode"].method;
}
if(!_6e7["handle"]&&_6e7["handler"]){
_6e7.handle=_6e7.handler;
}
if(!_6e7["load"]&&_6e7["loaded"]){
_6e7.load=_6e7.loaded;
}
if(!_6e7["changeUrl"]&&_6e7["changeURL"]){
_6e7.changeUrl=_6e7.changeURL;
}
_6e7.encoding=dojo.lang.firstValued(_6e7["encoding"],djConfig["bindEncoding"],"");
_6e7.sendTransport=dojo.lang.firstValued(_6e7["sendTransport"],djConfig["ioSendTransport"],false);
var _6e8=dojo.lang.isFunction;
for(var x=0;x<dojo.io.hdlrFuncNames.length;x++){
var fn=dojo.io.hdlrFuncNames[x];
if(_6e7[fn]&&_6e8(_6e7[fn])){
continue;
}
if(_6e7["handle"]&&_6e8(_6e7["handle"])){
_6e7[fn]=_6e7.handle;
}
}
dojo.lang.mixin(this,_6e7);
}});
dojo.io.Error=function(msg,type,num){
this.message=msg;
this.type=type||"unknown";
this.number=num||0;
};
dojo.io.transports.addTransport=function(name){
this.push(name);
this[name]=dojo.io[name];
};
dojo.io.bind=function(_6ef){
if(!(_6ef instanceof dojo.io.Request)){
try{
_6ef=new dojo.io.Request(_6ef);
}
catch(e){
dojo.debug(e);
}
}
var _6f0="";
if(_6ef["transport"]){
_6f0=_6ef["transport"];
if(!this[_6f0]){
return _6ef;
}
}else{
for(var x=0;x<dojo.io.transports.length;x++){
var tmp=dojo.io.transports[x];
if((this[tmp])&&(this[tmp].canHandle(_6ef))){
_6f0=tmp;
}
}
if(_6f0==""){
return _6ef;
}
}
this[_6f0].bind(_6ef);
_6ef.bindSuccess=true;
return _6ef;
};
dojo.io.queueBind=function(_6f3){
if(!(_6f3 instanceof dojo.io.Request)){
try{
_6f3=new dojo.io.Request(_6f3);
}
catch(e){
dojo.debug(e);
}
}
var _6f4=_6f3.load;
_6f3.load=function(){
dojo.io._queueBindInFlight=false;
var ret=_6f4.apply(this,arguments);
dojo.io._dispatchNextQueueBind();
return ret;
};
var _6f6=_6f3.error;
_6f3.error=function(){
dojo.io._queueBindInFlight=false;
var ret=_6f6.apply(this,arguments);
dojo.io._dispatchNextQueueBind();
return ret;
};
dojo.io._bindQueue.push(_6f3);
dojo.io._dispatchNextQueueBind();
return _6f3;
};
dojo.io._dispatchNextQueueBind=function(){
if(!dojo.io._queueBindInFlight){
dojo.io._queueBindInFlight=true;
if(dojo.io._bindQueue.length>0){
dojo.io.bind(dojo.io._bindQueue.shift());
}else{
dojo.io._queueBindInFlight=false;
}
}
};
dojo.io._bindQueue=[];
dojo.io._queueBindInFlight=false;
dojo.io.argsFromMap=function(map,_6f9,last){
var enc=/utf/i.test(_6f9||"")?encodeURIComponent:dojo.string.encodeAscii;
var _6fc=[];
var _6fd=new Object();
for(var name in map){
var _6ff=function(elt){
var val=enc(name)+"="+enc(elt);
_6fc[(last==name)?"push":"unshift"](val);
};
if(!_6fd[name]){
var _702=map[name];
if(dojo.lang.isArray(_702)){
dojo.lang.forEach(_702,_6ff);
}else{
_6ff(_702);
}
}
}
return _6fc.join("&");
};
dojo.io.setIFrameSrc=function(_703,src,_705){
try{
var r=dojo.render.html;
if(!_705){
if(r.safari){
_703.location=src;
}else{
frames[_703.name].location=src;
}
}else{
var idoc;
if(r.ie){
idoc=_703.contentWindow.document;
}else{
if(r.safari){
idoc=_703.document;
}else{
idoc=_703.contentWindow;
}
}
if(!idoc){
_703.location=src;
return;
}else{
idoc.location.replace(src);
}
}
}
catch(e){
dojo.debug(e);
dojo.debug("setIFrameSrc: "+e);
}
};
dojo.provide("dojo.string.extras");
dojo.string.substituteParams=function(_708,hash){
var map=(typeof hash=="object")?hash:dojo.lang.toArray(arguments,1);
return _708.replace(/\%\{(\w+)\}/g,function(_70b,key){
if(typeof (map[key])!="undefined"&&map[key]!=null){
return map[key];
}
dojo.raise("Substitution not found: "+key);
});
};
dojo.string.capitalize=function(str){
if(!dojo.lang.isString(str)){
return "";
}
if(arguments.length==0){
str=this;
}
var _70e=str.split(" ");
for(var i=0;i<_70e.length;i++){
_70e[i]=_70e[i].charAt(0).toUpperCase()+_70e[i].substring(1);
}
return _70e.join(" ");
};
dojo.string.isBlank=function(str){
if(!dojo.lang.isString(str)){
return true;
}
return (dojo.string.trim(str).length==0);
};
dojo.string.encodeAscii=function(str){
if(!dojo.lang.isString(str)){
return str;
}
var ret="";
var _713=escape(str);
var _714,re=/%u([0-9A-F]{4})/i;
while((_714=_713.match(re))){
var num=Number("0x"+_714[1]);
var _716=escape("&#"+num+";");
ret+=_713.substring(0,_714.index)+_716;
_713=_713.substring(_714.index+_714[0].length);
}
ret+=_713.replace(/\+/g,"%2B");
return ret;
};
dojo.string.escape=function(type,str){
var args=dojo.lang.toArray(arguments,1);
switch(type.toLowerCase()){
case "xml":
case "html":
case "xhtml":
return dojo.string.escapeXml.apply(this,args);
case "sql":
return dojo.string.escapeSql.apply(this,args);
case "regexp":
case "regex":
return dojo.string.escapeRegExp.apply(this,args);
case "javascript":
case "jscript":
case "js":
return dojo.string.escapeJavaScript.apply(this,args);
case "ascii":
return dojo.string.encodeAscii.apply(this,args);
default:
return str;
}
};
dojo.string.escapeXml=function(str,_71b){
str=str.replace(/&/gm,"&amp;").replace(/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
if(!_71b){
str=str.replace(/'/gm,"&#39;");
}
return str;
};
dojo.string.escapeSql=function(str){
return str.replace(/'/gm,"''");
};
dojo.string.escapeRegExp=function(str){
return str.replace(/\\/gm,"\\\\").replace(/([\f\b\n\t\r[\^$|?*+(){}])/gm,"\\$1");
};
dojo.string.escapeJavaScript=function(str){
return str.replace(/(["'\f\b\n\t\r])/gm,"\\$1");
};
dojo.string.escapeString=function(str){
return ("\""+str.replace(/(["\\])/g,"\\$1")+"\"").replace(/[\f]/g,"\\f").replace(/[\b]/g,"\\b").replace(/[\n]/g,"\\n").replace(/[\t]/g,"\\t").replace(/[\r]/g,"\\r");
};
dojo.string.summary=function(str,len){
if(!len||str.length<=len){
return str;
}else{
return str.substring(0,len).replace(/\.+$/,"")+"...";
}
};
dojo.string.endsWith=function(str,end,_724){
if(_724){
str=str.toLowerCase();
end=end.toLowerCase();
}
if((str.length-end.length)<0){
return false;
}
return str.lastIndexOf(end)==str.length-end.length;
};
dojo.string.endsWithAny=function(str){
for(var i=1;i<arguments.length;i++){
if(dojo.string.endsWith(str,arguments[i])){
return true;
}
}
return false;
};
dojo.string.startsWith=function(str,_728,_729){
if(_729){
str=str.toLowerCase();
_728=_728.toLowerCase();
}
return str.indexOf(_728)==0;
};
dojo.string.startsWithAny=function(str){
for(var i=1;i<arguments.length;i++){
if(dojo.string.startsWith(str,arguments[i])){
return true;
}
}
return false;
};
dojo.string.has=function(str){
for(var i=1;i<arguments.length;i++){
if(str.indexOf(arguments[i])>-1){
return true;
}
}
return false;
};
dojo.string.normalizeNewlines=function(text,_72f){
if(_72f=="\n"){
text=text.replace(/\r\n/g,"\n");
text=text.replace(/\r/g,"\n");
}else{
if(_72f=="\r"){
text=text.replace(/\r\n/g,"\r");
text=text.replace(/\n/g,"\r");
}else{
text=text.replace(/([^\r])\n/g,"$1\r\n");
text=text.replace(/\r([^\n])/g,"\r\n$1");
}
}
return text;
};
dojo.string.splitEscaped=function(str,_731){
var _732=[];
for(var i=0,prevcomma=0;i<str.length;i++){
if(str.charAt(i)=="\\"){
i++;
continue;
}
if(str.charAt(i)==_731){
_732.push(str.substring(prevcomma,i));
prevcomma=i+1;
}
}
_732.push(str.substr(prevcomma));
return _732;
};
dojo.provide("dojo.undo.browser");
try{
if((!djConfig["preventBackButtonFix"])&&(!dojo.hostenv.post_load_)){
document.write("<iframe style='border: 0px; width: 1px; height: 1px; position: absolute; bottom: 0px; right: 0px; visibility: visible;' name='djhistory' id='djhistory' src='"+(dojo.hostenv.getBaseScriptUri()+"iframe_history.html")+"'></iframe>");
}
}
catch(e){
}
if(dojo.render.html.opera){
dojo.debug("Opera is not supported with dojo.undo.browser, so back/forward detection will not work.");
}
dojo.undo.browser={initialHref:window.location.href,initialHash:window.location.hash,moveForward:false,historyStack:[],forwardStack:[],historyIframe:null,bookmarkAnchor:null,locationTimer:null,setInitialState:function(args){
this.initialState=this._createState(this.initialHref,args,this.initialHash);
},addToHistory:function(args){
this.forwardStack=[];
var hash=null;
var url=null;
if(!this.historyIframe){
this.historyIframe=window.frames["djhistory"];
}
if(!this.bookmarkAnchor){
this.bookmarkAnchor=document.createElement("a");
dojo.body().appendChild(this.bookmarkAnchor);
this.bookmarkAnchor.style.display="none";
}
if(args["changeUrl"]){
hash="#"+((args["changeUrl"]!==true)?args["changeUrl"]:(new Date()).getTime());
if(this.historyStack.length==0&&this.initialState.urlHash==hash){
this.initialState=this._createState(url,args,hash);
return;
}else{
if(this.historyStack.length>0&&this.historyStack[this.historyStack.length-1].urlHash==hash){
this.historyStack[this.historyStack.length-1]=this._createState(url,args,hash);
return;
}
}
this.changingUrl=true;
setTimeout("window.location.href = '"+hash+"'; dojo.undo.browser.changingUrl = false;",1);
this.bookmarkAnchor.href=hash;
if(dojo.render.html.ie){
url=this._loadIframeHistory();
var _738=args["back"]||args["backButton"]||args["handle"];
var tcb=function(_73a){
if(window.location.hash!=""){
setTimeout("window.location.href = '"+hash+"';",1);
}
_738.apply(this,[_73a]);
};
if(args["back"]){
args.back=tcb;
}else{
if(args["backButton"]){
args.backButton=tcb;
}else{
if(args["handle"]){
args.handle=tcb;
}
}
}
var _73b=args["forward"]||args["forwardButton"]||args["handle"];
var tfw=function(_73d){
if(window.location.hash!=""){
window.location.href=hash;
}
if(_73b){
_73b.apply(this,[_73d]);
}
};
if(args["forward"]){
args.forward=tfw;
}else{
if(args["forwardButton"]){
args.forwardButton=tfw;
}else{
if(args["handle"]){
args.handle=tfw;
}
}
}
}else{
if(dojo.render.html.moz){
if(!this.locationTimer){
this.locationTimer=setInterval("dojo.undo.browser.checkLocation();",200);
}
}
}
}else{
url=this._loadIframeHistory();
}
this.historyStack.push(this._createState(url,args,hash));
},checkLocation:function(){
if(!this.changingUrl){
var hsl=this.historyStack.length;
if((window.location.hash==this.initialHash||window.location.href==this.initialHref)&&(hsl==1)){
this.handleBackButton();
return;
}
if(this.forwardStack.length>0){
if(this.forwardStack[this.forwardStack.length-1].urlHash==window.location.hash){
this.handleForwardButton();
return;
}
}
if((hsl>=2)&&(this.historyStack[hsl-2])){
if(this.historyStack[hsl-2].urlHash==window.location.hash){
this.handleBackButton();
return;
}
}
}
},iframeLoaded:function(evt,_740){
if(!dojo.render.html.opera){
var _741=this._getUrlQuery(_740.href);
if(_741==null){
if(this.historyStack.length==1){
this.handleBackButton();
}
return;
}
if(this.moveForward){
this.moveForward=false;
return;
}
if(this.historyStack.length>=2&&_741==this._getUrlQuery(this.historyStack[this.historyStack.length-2].url)){
this.handleBackButton();
}else{
if(this.forwardStack.length>0&&_741==this._getUrlQuery(this.forwardStack[this.forwardStack.length-1].url)){
this.handleForwardButton();
}
}
}
},handleBackButton:function(){
var _742=this.historyStack.pop();
if(!_742){
return;
}
var last=this.historyStack[this.historyStack.length-1];
if(!last&&this.historyStack.length==0){
last=this.initialState;
}
if(last){
if(last.kwArgs["back"]){
last.kwArgs["back"]();
}else{
if(last.kwArgs["backButton"]){
last.kwArgs["backButton"]();
}else{
if(last.kwArgs["handle"]){
last.kwArgs.handle("back");
}
}
}
}
this.forwardStack.push(_742);
},handleForwardButton:function(){
var last=this.forwardStack.pop();
if(!last){
return;
}
if(last.kwArgs["forward"]){
last.kwArgs.forward();
}else{
if(last.kwArgs["forwardButton"]){
last.kwArgs.forwardButton();
}else{
if(last.kwArgs["handle"]){
last.kwArgs.handle("forward");
}
}
}
this.historyStack.push(last);
},_createState:function(url,args,hash){
return {"url":url,"kwArgs":args,"urlHash":hash};
},_getUrlQuery:function(url){
var _749=url.split("?");
if(_749.length<2){
return null;
}else{
return _749[1];
}
},_loadIframeHistory:function(){
var url=dojo.hostenv.getBaseScriptUri()+"iframe_history.html?"+(new Date()).getTime();
this.moveForward=true;
dojo.io.setIFrameSrc(this.historyIframe,url,false);
return url;
}};
dojo.provide("dojo.io.BrowserIO");
dojo.io.checkChildrenForFile=function(node){
var _74c=false;
var _74d=node.getElementsByTagName("input");
dojo.lang.forEach(_74d,function(_74e){
if(_74c){
return;
}
if(_74e.getAttribute("type")=="file"){
_74c=true;
}
});
return _74c;
};
dojo.io.formHasFile=function(_74f){
return dojo.io.checkChildrenForFile(_74f);
};
dojo.io.updateNode=function(node,_751){
node=dojo.byId(node);
var args=_751;
if(dojo.lang.isString(_751)){
args={url:_751};
}
args.mimetype="text/html";
args.load=function(t,d,e){
while(node.firstChild){
if(dojo["event"]){
try{
dojo.event.browser.clean(node.firstChild);
}
catch(e){
}
}
node.removeChild(node.firstChild);
}
node.innerHTML=d;
};
dojo.io.bind(args);
};
dojo.io.formFilter=function(node){
var type=(node.type||"").toLowerCase();
return !node.disabled&&node.name&&!dojo.lang.inArray(["file","submit","image","reset","button"],type);
};
dojo.io.encodeForm=function(_758,_759,_75a){
if((!_758)||(!_758.tagName)||(!_758.tagName.toLowerCase()=="form")){
dojo.raise("Attempted to encode a non-form element.");
}
if(!_75a){
_75a=dojo.io.formFilter;
}
var enc=/utf/i.test(_759||"")?encodeURIComponent:dojo.string.encodeAscii;
var _75c=[];
for(var i=0;i<_758.elements.length;i++){
var elm=_758.elements[i];
if(!elm||elm.tagName.toLowerCase()=="fieldset"||!_75a(elm)){
continue;
}
var name=enc(elm.name);
var type=elm.type.toLowerCase();
if(type=="select-multiple"){
for(var j=0;j<elm.options.length;j++){
if(elm.options[j].selected){
_75c.push(name+"="+enc(elm.options[j].value));
}
}
}else{
if(dojo.lang.inArray(["radio","checkbox"],type)){
if(elm.checked){
_75c.push(name+"="+enc(elm.value));
}
}else{
_75c.push(name+"="+enc(elm.value));
}
}
}
var _762=_758.getElementsByTagName("input");
for(var i=0;i<_762.length;i++){
var _763=_762[i];
if(_763.type.toLowerCase()=="image"&&_763.form==_758&&_75a(_763)){
var name=enc(_763.name);
_75c.push(name+"="+enc(_763.value));
_75c.push(name+".x=0");
_75c.push(name+".y=0");
}
}
return _75c.join("&")+"&";
};
dojo.io.FormBind=function(args){
this.bindArgs={};
if(args&&args.formNode){
this.init(args);
}else{
if(args){
this.init({formNode:args});
}
}
};
dojo.lang.extend(dojo.io.FormBind,{form:null,bindArgs:null,clickedButton:null,init:function(args){
var form=dojo.byId(args.formNode);
if(!form||!form.tagName||form.tagName.toLowerCase()!="form"){
throw new Error("FormBind: Couldn't apply, invalid form");
}else{
if(this.form==form){
return;
}else{
if(this.form){
throw new Error("FormBind: Already applied to a form");
}
}
}
dojo.lang.mixin(this.bindArgs,args);
this.form=form;
this.connect(form,"onsubmit","submit");
for(var i=0;i<form.elements.length;i++){
var node=form.elements[i];
if(node&&node.type&&dojo.lang.inArray(["submit","button"],node.type.toLowerCase())){
this.connect(node,"onclick","click");
}
}
var _769=form.getElementsByTagName("input");
for(var i=0;i<_769.length;i++){
var _76a=_769[i];
if(_76a.type.toLowerCase()=="image"&&_76a.form==form){
this.connect(_76a,"onclick","click");
}
}
},onSubmit:function(form){
return true;
},submit:function(e){
e.preventDefault();
if(this.onSubmit(this.form)){
dojo.io.bind(dojo.lang.mixin(this.bindArgs,{formFilter:dojo.lang.hitch(this,"formFilter")}));
}
},click:function(e){
var node=e.currentTarget;
if(node.disabled){
return;
}
this.clickedButton=node;
},formFilter:function(node){
var type=(node.type||"").toLowerCase();
var _771=false;
if(node.disabled||!node.name){
_771=false;
}else{
if(dojo.lang.inArray(["submit","button","image"],type)){
if(!this.clickedButton){
this.clickedButton=node;
}
_771=node==this.clickedButton;
}else{
_771=!dojo.lang.inArray(["file","submit","reset","button"],type);
}
}
return _771;
},connect:function(_772,_773,_774){
if(dojo.evalObjPath("dojo.event.connect")){
dojo.event.connect(_772,_773,this,_774);
}else{
var fcn=dojo.lang.hitch(this,_774);
_772[_773]=function(e){
if(!e){
e=window.event;
}
if(!e.currentTarget){
e.currentTarget=e.srcElement;
}
if(!e.preventDefault){
e.preventDefault=function(){
window.event.returnValue=false;
};
}
fcn(e);
};
}
}});
dojo.io.XMLHTTPTransport=new function(){
var _777=this;
var _778={};
this.useCache=false;
this.preventCache=false;
function getCacheKey(url,_77a,_77b){
return url+"|"+_77a+"|"+_77b.toLowerCase();
}
function addToCache(url,_77d,_77e,http){
_778[getCacheKey(url,_77d,_77e)]=http;
}
function getFromCache(url,_781,_782){
return _778[getCacheKey(url,_781,_782)];
}
this.clearCache=function(){
_778={};
};
function doLoad(_783,http,url,_786,_787){
if(((http.status>=200)&&(http.status<300))||(http.status==304)||(location.protocol=="file:"&&(http.status==0||http.status==undefined))||(location.protocol=="chrome:"&&(http.status==0||http.status==undefined))){
var ret;
if(_783.method.toLowerCase()=="head"){
var _789=http.getAllResponseHeaders();
ret={};
ret.toString=function(){
return _789;
};
var _78a=_789.split(/[\r\n]+/g);
for(var i=0;i<_78a.length;i++){
var pair=_78a[i].match(/^([^:]+)\s*:\s*(.+)$/i);
if(pair){
ret[pair[1]]=pair[2];
}
}
}else{
if(_783.mimetype=="text/javascript"){
try{
ret=dj_eval(http.responseText);
}
catch(e){
dojo.debug(e);
dojo.debug(http.responseText);
ret=null;
}
}else{
if(_783.mimetype=="text/json"){
try{
ret=dj_eval("("+http.responseText+")");
}
catch(e){
dojo.debug(e);
dojo.debug(http.responseText);
ret=false;
}
}else{
if((_783.mimetype=="application/xml")||(_783.mimetype=="text/xml")){
ret=http.responseXML;
if(!ret||typeof ret=="string"||!http.getResponseHeader("Content-Type")){
ret=dojo.dom.createDocumentFromText(http.responseText);
}
}else{
ret=http.responseText;
}
}
}
}
if(_787){
addToCache(url,_786,_783.method,http);
}
_783[(typeof _783.load=="function")?"load":"handle"]("load",ret,http,_783);
}else{
var _78d=new dojo.io.Error("XMLHttpTransport Error: "+http.status+" "+http.statusText);
_783[(typeof _783.error=="function")?"error":"handle"]("error",_78d,http,_783);
}
}
function setHeaders(http,_78f){
if(_78f["headers"]){
for(var _790 in _78f["headers"]){
if(_790.toLowerCase()=="content-type"&&!_78f["contentType"]){
_78f["contentType"]=_78f["headers"][_790];
}else{
http.setRequestHeader(_790,_78f["headers"][_790]);
}
}
}
}
this.inFlight=[];
this.inFlightTimer=null;
this.startWatchingInFlight=function(){
if(!this.inFlightTimer){
this.inFlightTimer=setTimeout("dojo.io.XMLHTTPTransport.watchInFlight();",10);
}
};
this.watchInFlight=function(){
var now=null;
if(!dojo.hostenv._blockAsync&&!_777._blockAsync){
for(var x=this.inFlight.length-1;x>=0;x--){
var tif=this.inFlight[x];
if(!tif||tif.http._aborted||!tif.http.readyState){
this.inFlight.splice(x,1);
continue;
}
if(4==tif.http.readyState){
this.inFlight.splice(x,1);
doLoad(tif.req,tif.http,tif.url,tif.query,tif.useCache);
}else{
if(tif.startTime){
if(!now){
now=(new Date()).getTime();
}
if(tif.startTime+(tif.req.timeoutSeconds*1000)<now){
if(typeof tif.http.abort=="function"){
tif.http.abort();
}
this.inFlight.splice(x,1);
tif.req[(typeof tif.req.timeout=="function")?"timeout":"handle"]("timeout",null,tif.http,tif.req);
}
}
}
}
}
clearTimeout(this.inFlightTimer);
if(this.inFlight.length==0){
this.inFlightTimer=null;
return;
}
this.inFlightTimer=setTimeout("dojo.io.XMLHTTPTransport.watchInFlight();",10);
};
var _794=dojo.hostenv.getXmlhttpObject()?true:false;
this.canHandle=function(_795){
return _794&&dojo.lang.inArray(["text/plain","text/html","application/xml","text/xml","text/javascript","text/json"],(_795["mimetype"].toLowerCase()||""))&&!(_795["formNode"]&&dojo.io.formHasFile(_795["formNode"]));
};
this.multipartBoundary="45309FFF-BD65-4d50-99C9-36986896A96F";
this.bind=function(_796){
if(!_796["url"]){
if(!_796["formNode"]&&(_796["backButton"]||_796["back"]||_796["changeUrl"]||_796["watchForURL"])&&(!djConfig.preventBackButtonFix)){
dojo.deprecated("Using dojo.io.XMLHTTPTransport.bind() to add to browser history without doing an IO request","Use dojo.undo.browser.addToHistory() instead.","0.4");
dojo.undo.browser.addToHistory(_796);
return true;
}
}
var url=_796.url;
var _798="";
if(_796["formNode"]){
var ta=_796.formNode.getAttribute("action");
if((ta)&&(!_796["url"])){
url=ta;
}
var tp=_796.formNode.getAttribute("method");
if((tp)&&(!_796["method"])){
_796.method=tp;
}
_798+=dojo.io.encodeForm(_796.formNode,_796.encoding,_796["formFilter"]);
}
if(url.indexOf("#")>-1){
dojo.debug("Warning: dojo.io.bind: stripping hash values from url:",url);
url=url.split("#")[0];
}
if(_796["file"]){
_796.method="post";
}
if(!_796["method"]){
_796.method="get";
}
if(_796.method.toLowerCase()=="get"){
_796.multipart=false;
}else{
if(_796["file"]){
_796.multipart=true;
}else{
if(!_796["multipart"]){
_796.multipart=false;
}
}
}
if(_796["backButton"]||_796["back"]||_796["changeUrl"]){
dojo.undo.browser.addToHistory(_796);
}
var _79b=_796["content"]||{};
if(_796.sendTransport){
_79b["dojo.transport"]="xmlhttp";
}
do{
if(_796.postContent){
_798=_796.postContent;
break;
}
if(_79b){
_798+=dojo.io.argsFromMap(_79b,_796.encoding);
}
if(_796.method.toLowerCase()=="get"||!_796.multipart){
break;
}
var t=[];
if(_798.length){
var q=_798.split("&");
for(var i=0;i<q.length;++i){
if(q[i].length){
var p=q[i].split("=");
t.push("--"+this.multipartBoundary,"Content-Disposition: form-data; name=\""+p[0]+"\"","",p[1]);
}
}
}
if(_796.file){
if(dojo.lang.isArray(_796.file)){
for(var i=0;i<_796.file.length;++i){
var o=_796.file[i];
t.push("--"+this.multipartBoundary,"Content-Disposition: form-data; name=\""+o.name+"\"; filename=\""+("fileName" in o?o.fileName:o.name)+"\"","Content-Type: "+("contentType" in o?o.contentType:"application/octet-stream"),"",o.content);
}
}else{
var o=_796.file;
t.push("--"+this.multipartBoundary,"Content-Disposition: form-data; name=\""+o.name+"\"; filename=\""+("fileName" in o?o.fileName:o.name)+"\"","Content-Type: "+("contentType" in o?o.contentType:"application/octet-stream"),"",o.content);
}
}
if(t.length){
t.push("--"+this.multipartBoundary+"--","");
_798=t.join("\r\n");
}
}while(false);
var _7a1=_796["sync"]?false:true;
var _7a2=_796["preventCache"]||(this.preventCache==true&&_796["preventCache"]!=false);
var _7a3=_796["useCache"]==true||(this.useCache==true&&_796["useCache"]!=false);
if(!_7a2&&_7a3){
var _7a4=getFromCache(url,_798,_796.method);
if(_7a4){
doLoad(_796,_7a4,url,_798,false);
return;
}
}
var http=dojo.hostenv.getXmlhttpObject(_796);
var _7a6=false;
if(_7a1){
var _7a7=this.inFlight.push({"req":_796,"http":http,"url":url,"query":_798,"useCache":_7a3,"startTime":_796.timeoutSeconds?(new Date()).getTime():0});
this.startWatchingInFlight();
}else{
_777._blockAsync=true;
}
if(_796.method.toLowerCase()=="post"){
http.open("POST",url,_7a1);
setHeaders(http,_796);
http.setRequestHeader("Content-Type",_796.multipart?("multipart/form-data; boundary="+this.multipartBoundary):(_796.contentType||"application/x-www-form-urlencoded"));
try{
http.send(_798);
}
catch(e){
if(typeof http.abort=="function"){
http.abort();
}
doLoad(_796,{status:404},url,_798,_7a3);
}
}else{
var _7a8=url;
if(_798!=""){
_7a8+=(_7a8.indexOf("?")>-1?"&":"?")+_798;
}
if(_7a2){
_7a8+=(dojo.string.endsWithAny(_7a8,"?","&")?"":(_7a8.indexOf("?")>-1?"&":"?"))+"dojo.preventCache="+new Date().valueOf();
}
http.open(_796.method.toUpperCase(),_7a8,_7a1);
setHeaders(http,_796);
try{
http.send(null);
}
catch(e){
if(typeof http.abort=="function"){
http.abort();
}
doLoad(_796,{status:404},url,_798,_7a3);
}
}
if(!_7a1){
doLoad(_796,http,url,_798,_7a3);
_777._blockAsync=false;
}
_796.abort=function(){
try{
http._aborted=true;
}
catch(e){
}
return http.abort();
};
return;
};
dojo.io.transports.addTransport("XMLHTTPTransport");
};
dojo.provide("dojo.io.cookie");
dojo.io.cookie.setCookie=function(name,_7aa,days,path,_7ad,_7ae){
var _7af=-1;
if(typeof days=="number"&&days>=0){
var d=new Date();
d.setTime(d.getTime()+(days*24*60*60*1000));
_7af=d.toGMTString();
}
_7aa=escape(_7aa);
document.cookie=name+"="+_7aa+";"+(_7af!=-1?" expires="+_7af+";":"")+(path?"path="+path:"")+(_7ad?"; domain="+_7ad:"")+(_7ae?"; secure":"");
};
dojo.io.cookie.set=dojo.io.cookie.setCookie;
dojo.io.cookie.getCookie=function(name){
var idx=document.cookie.lastIndexOf(name+"=");
if(idx==-1){
return null;
}
var _7b3=document.cookie.substring(idx+name.length+1);
var end=_7b3.indexOf(";");
if(end==-1){
end=_7b3.length;
}
_7b3=_7b3.substring(0,end);
_7b3=unescape(_7b3);
return _7b3;
};
dojo.io.cookie.get=dojo.io.cookie.getCookie;
dojo.io.cookie.deleteCookie=function(name){
dojo.io.cookie.setCookie(name,"-",0);
};
dojo.io.cookie.setObjectCookie=function(name,obj,days,path,_7ba,_7bb,_7bc){
if(arguments.length==5){
_7bc=_7ba;
_7ba=null;
_7bb=null;
}
var _7bd=[],cookie,value="";
if(!_7bc){
cookie=dojo.io.cookie.getObjectCookie(name);
}
if(days>=0){
if(!cookie){
cookie={};
}
for(var prop in obj){
if(prop==null){
delete cookie[prop];
}else{
if(typeof obj[prop]=="string"||typeof obj[prop]=="number"){
cookie[prop]=obj[prop];
}
}
}
prop=null;
for(var prop in cookie){
_7bd.push(escape(prop)+"="+escape(cookie[prop]));
}
value=_7bd.join("&");
}
dojo.io.cookie.setCookie(name,value,days,path,_7ba,_7bb);
};
dojo.io.cookie.getObjectCookie=function(name){
var _7c0=null,cookie=dojo.io.cookie.getCookie(name);
if(cookie){
_7c0={};
var _7c1=cookie.split("&");
for(var i=0;i<_7c1.length;i++){
var pair=_7c1[i].split("=");
var _7c4=pair[1];
if(isNaN(_7c4)){
_7c4=unescape(pair[1]);
}
_7c0[unescape(pair[0])]=_7c4;
}
}
return _7c0;
};
dojo.io.cookie.isSupported=function(){
if(typeof navigator.cookieEnabled!="boolean"){
dojo.io.cookie.setCookie("__TestingYourBrowserForCookieSupport__","CookiesAllowed",90,null);
var _7c5=dojo.io.cookie.getCookie("__TestingYourBrowserForCookieSupport__");
navigator.cookieEnabled=(_7c5=="CookiesAllowed");
if(navigator.cookieEnabled){
this.deleteCookie("__TestingYourBrowserForCookieSupport__");
}
}
return navigator.cookieEnabled;
};
if(!dojo.io.cookies){
dojo.io.cookies=dojo.io.cookie;
}
dojo.provide("dojo.io.*");
dojo.provide("dojo.html.*");
dojo.provide("dojo.html.iframe");
dojo.html.iframeContentWindow=function(_7c6){
var win=dojo.html.getDocumentWindow(dojo.html.iframeContentDocument(_7c6))||dojo.html.iframeContentDocument(_7c6).__parent__||(_7c6.name&&document.frames[_7c6.name])||null;
return win;
};
dojo.html.iframeContentDocument=function(_7c8){
var doc=_7c8.contentDocument||((_7c8.contentWindow)&&(_7c8.contentWindow.document))||((_7c8.name)&&(document.frames[_7c8.name])&&(document.frames[_7c8.name].document))||null;
return doc;
};
dojo.html.BackgroundIframe=function(node){
if(dojo.render.html.ie55||dojo.render.html.ie60){
var html="<iframe "+"style='position: absolute; left: 0px; top: 0px; width: 100%; height: 100%;"+"z-index: -1; filter:Alpha(Opacity=\"0\");' "+">";
this.iframe=dojo.doc().createElement(html);
this.iframe.tabIndex=-1;
if(node){
node.appendChild(this.iframe);
this.domNode=node;
}else{
dojo.body().appendChild(this.iframe);
this.iframe.style.display="none";
}
}
};
dojo.lang.extend(dojo.html.BackgroundIframe,{iframe:null,onResized:function(){
if(this.iframe&&this.domNode&&this.domNode.parentNode){
var _7cc=dojo.html.getMarginBox(this.domNode);
if(_7cc.width==0||_7cc.height==0){
dojo.lang.setTimeout(this,this.onResized,100);
return;
}
with(this.iframe.style){
width=_7cc.width+"px";
height=_7cc.height+"px";
}
}
},size:function(node){
if(!this.iframe){
return;
}
var _7ce=dojo.html.toCoordinateObject(node,true,dojo.html.boxSizing.BORDER_BOX);
with(this.iframe.style){
width=_7ce.width+"px";
height=_7ce.height+"px";
left=_7ce.left+"px";
top=_7ce.top+"px";
}
},setZIndex:function(node){
if(!this.iframe){
return;
}
if(dojo.dom.isNode(node)){
this.iframe.style.zIndex=dojo.html.getStyle(node,"z-index")-1;
}else{
if(!isNaN(node)){
this.iframe.style.zIndex=node;
}
}
},show:function(){
if(!this.iframe){
return;
}
this.iframe.style.display="block";
},hide:function(){
if(!this.iframe){
return;
}
this.iframe.style.display="none";
},remove:function(){
dojo.dom.removeNode(this.iframe);
}});
dojo.provide("dojo.widget.html.stabile");
dojo.widget.html.stabile={_sqQuotables:new RegExp("([\\\\'])","g"),_depth:0,_recur:false,depthLimit:2};
dojo.widget.html.stabile.getState=function(id){
dojo.widget.html.stabile.setup();
return dojo.widget.html.stabile.widgetState[id];
};
dojo.widget.html.stabile.setState=function(id,_7d2,_7d3){
dojo.widget.html.stabile.setup();
dojo.widget.html.stabile.widgetState[id]=_7d2;
if(_7d3){
dojo.widget.html.stabile.commit(dojo.widget.html.stabile.widgetState);
}
};
dojo.widget.html.stabile.setup=function(){
if(!dojo.widget.html.stabile.widgetState){
var text=dojo.widget.html.stabile.getStorage().value;
dojo.widget.html.stabile.widgetState=text?dj_eval("("+text+")"):{};
}
};
dojo.widget.html.stabile.commit=function(_7d5){
dojo.widget.html.stabile.getStorage().value=dojo.widget.html.stabile.description(_7d5);
};
dojo.widget.html.stabile.description=function(v,_7d7){
var _7d8=dojo.widget.html.stabile._depth;
var _7d9=function(){
return this.description(this,true);
};
try{
if(v===void (0)){
return "undefined";
}
if(v===null){
return "null";
}
if(typeof (v)=="boolean"||typeof (v)=="number"||v instanceof Boolean||v instanceof Number){
return v.toString();
}
if(typeof (v)=="string"||v instanceof String){
var v1=v.replace(dojo.widget.html.stabile._sqQuotables,"\\$1");
v1=v1.replace(/\n/g,"\\n");
v1=v1.replace(/\r/g,"\\r");
return "'"+v1+"'";
}
if(v instanceof Date){
return "new Date("+d.getFullYear+","+d.getMonth()+","+d.getDate()+")";
}
var d;
if(v instanceof Array||v.push){
if(_7d8>=dojo.widget.html.stabile.depthLimit){
return "[ ... ]";
}
d="[";
var _7dc=true;
dojo.widget.html.stabile._depth++;
for(var i=0;i<v.length;i++){
if(_7dc){
_7dc=false;
}else{
d+=",";
}
d+=arguments.callee(v[i],_7d7);
}
return d+"]";
}
if(v.constructor==Object||v.toString==_7d9){
if(_7d8>=dojo.widget.html.stabile.depthLimit){
return "{ ... }";
}
if(typeof (v.hasOwnProperty)!="function"&&v.prototype){
throw new Error("description: "+v+" not supported by script engine");
}
var _7dc=true;
d="{";
dojo.widget.html.stabile._depth++;
for(var key in v){
if(v[key]==void (0)||typeof (v[key])=="function"){
continue;
}
if(_7dc){
_7dc=false;
}else{
d+=", ";
}
var kd=key;
if(!kd.match(/^[a-zA-Z_][a-zA-Z0-9_]*$/)){
kd=arguments.callee(key,_7d7);
}
d+=kd+": "+arguments.callee(v[key],_7d7);
}
return d+"}";
}
if(_7d7){
if(dojo.widget.html.stabile._recur){
var _7e0=Object.prototype.toString;
return _7e0.apply(v,[]);
}else{
dojo.widget.html.stabile._recur=true;
return v.toString();
}
}else{
throw new Error("Unknown type: "+v);
return "'unknown'";
}
}
finally{
dojo.widget.html.stabile._depth=_7d8;
}
};
dojo.widget.html.stabile.getStorage=function(){
if(dojo.widget.html.stabile.dataField){
return dojo.widget.html.stabile.dataField;
}
var form=document.forms._dojo_form;
return dojo.widget.html.stabile.dataField=form?form.stabile:{value:""};
};
dojo.provide("dojo.html.selection");
dojo.html.selectionType={NONE:0,TEXT:1,CONTROL:2};
dojo.html.clearSelection=function(){
var _7e2=dojo.global();
var _7e3=dojo.doc();
try{
if(_7e2["getSelection"]){
if(dojo.render.html.safari){
_7e2.getSelection().collapse();
}else{
_7e2.getSelection().removeAllRanges();
}
}else{
if(_7e3.selection){
if(_7e3.selection.empty){
_7e3.selection.empty();
}else{
if(_7e3.selection.clear){
_7e3.selection.clear();
}
}
}
}
return true;
}
catch(e){
dojo.debug(e);
return false;
}
};
dojo.html.disableSelection=function(_7e4){
_7e4=dojo.byId(_7e4)||dojo.body();
var h=dojo.render.html;
if(h.mozilla){
_7e4.style.MozUserSelect="none";
}else{
if(h.safari){
_7e4.style.KhtmlUserSelect="none";
}else{
if(h.ie){
_7e4.unselectable="on";
}else{
return false;
}
}
}
return true;
};
dojo.html.enableSelection=function(_7e6){
_7e6=dojo.byId(_7e6)||dojo.body();
var h=dojo.render.html;
if(h.mozilla){
_7e6.style.MozUserSelect="";
}else{
if(h.safari){
_7e6.style.KhtmlUserSelect="";
}else{
if(h.ie){
_7e6.unselectable="off";
}else{
return false;
}
}
}
return true;
};
dojo.html.selectElement=function(_7e8){
var _7e9=dojo.global();
var _7ea=dojo.doc();
_7e8=dojo.byId(_7e8);
if(_7ea.selection&&dojo.body().createTextRange){
var _7eb=dojo.body().createTextRange();
_7eb.moveToElementText(_7e8);
_7eb.select();
}else{
if(_7e9["getSelection"]){
var _7ec=_7e9.getSelection();
if(_7ec["selectAllChildren"]){
_7ec.selectAllChildren(_7e8);
}
}
}
};
dojo.html.selectInputText=function(_7ed){
var _7ee=dojo.global();
var _7ef=dojo.doc();
_7ed=dojo.byId(_7ed);
if(_7ef["selection"]&&dojo.body()["createTextRange"]){
var _7f0=_7ed.createTextRange();
_7f0.moveStart("character",0);
_7f0.moveEnd("character",_7ed.value.length);
_7f0.select();
}else{
if(_7ee["getSelection"]){
var _7f1=_7ee.getSelection();
_7ed.setSelectionRange(0,_7ed.value.length);
}
}
_7ed.focus();
};
dojo.html.isSelectionCollapsed=function(){
dojo.deprecated("dojo.html.isSelectionCollapsed","replaced by dojo.html.selection.isCollapsed",0.5);
return dojo.html.selection.isCollapsed();
};
dojo.lang.mixin(dojo.html.selection,{getType:function(){
if(dojo.doc()["selection"]){
return dojo.html.selectionType[dojo.doc().selection.type.toUpperCase()];
}else{
var _7f2=dojo.html.selectionType.TEXT;
var oSel;
try{
oSel=dojo.global().getSelection();
}
catch(e){
}
if(oSel&&oSel.rangeCount==1){
var _7f4=oSel.getRangeAt(0);
if(_7f4.startContainer==_7f4.endContainer&&(_7f4.endOffset-_7f4.startOffset)==1&&_7f4.startContainer.nodeType!=dojo.dom.TEXT_NODE){
_7f2=dojo.html.selectionType.CONTROL;
}
}
return _7f2;
}
},isCollapsed:function(){
var _7f5=dojo.global();
var _7f6=dojo.doc();
if(_7f6["selection"]){
return _7f6.selection.createRange().text=="";
}else{
if(_7f5["getSelection"]){
var _7f7=_7f5.getSelection();
if(dojo.lang.isString(_7f7)){
return _7f7=="";
}else{
return _7f7.isCollapsed||_7f7.toString()=="";
}
}
}
},getSelectedElement:function(){
if(dojo.html.selection.getType()==dojo.html.selectionType.CONTROL){
if(dojo.doc()["selection"]){
var _7f8=dojo.doc().selection.createRange();
if(_7f8&&_7f8.item){
return dojo.doc().selection.createRange().item(0);
}
}else{
var _7f9=dojo.global().getSelection();
return _7f9.anchorNode.childNodes[_7f9.anchorOffset];
}
}
},getParentElement:function(){
if(dojo.html.selection.getType()==dojo.html.selectionType.CONTROL){
var p=dojo.html.selection.getSelectedElement();
if(p){
return p.parentNode;
}
}else{
if(dojo.doc()["selection"]){
return dojo.doc().selection.createRange().parentElement();
}else{
var _7fb=dojo.global().getSelection();
if(_7fb){
var node=_7fb.anchorNode;
while(node&&node.nodeType!=dojo.dom.ELEMENT_NODE){
node=node.parentNode;
}
return node;
}
}
}
},getSelectedText:function(){
if(dojo.doc()["selection"]){
if(dojo.html.selection.getType()==dojo.html.selectionType.CONTROL){
return null;
}
return dojo.doc().selection.createRange().text;
}else{
var _7fd=dojo.global().getSelection();
if(_7fd){
return _7fd.toString();
}
}
},getSelectedHtml:function(){
if(dojo.doc()["selection"]){
if(dojo.html.selection.getType()==dojo.html.selectionType.CONTROL){
return null;
}
return dojo.doc().selection.createRange().htmlText;
}else{
var _7fe=dojo.global().getSelection();
if(_7fe&&_7fe.rangeCount){
var frag=_7fe.getRangeAt(0).cloneContents();
var div=document.createElement("div");
div.appendChild(frag);
return div.innerHTML;
}
return null;
}
},hasAncestorElement:function(_801){
return (dojo.html.selection.getAncestorElement.apply(this,arguments)!=null);
},getAncestorElement:function(_802){
var node=dojo.html.selection.getSelectedElement()||dojo.html.selection.getParentElement();
while(node){
if(dojo.html.selection.isTag(node,arguments).length>0){
return node;
}
node=node.parentNode;
}
return null;
},isTag:function(node,tags){
if(node&&node.tagName){
for(var i=0;i<tags.length;i++){
if(node.tagName.toLowerCase()==String(tags[i]).toLowerCase()){
return String(tags[i]).toLowerCase();
}
}
}
return "";
},selectElement:function(_807){
var _808=dojo.global();
var _809=dojo.doc();
_807=dojo.byId(_807);
if(_809.selection&&dojo.body().createTextRange){
try{
var _80a=dojo.body().createControlRange();
_80a.addElement(_807);
_80a.select();
}
catch(e){
dojo.html.selection.selectElementChildren(_807);
}
}else{
if(_808["getSelection"]){
var _80b=_808.getSelection();
if(_80b["removeAllRanges"]){
var _80a=_809.createRange();
_80a.selectNode(_807);
_80b.removeAllRanges();
_80b.addRange(_80a);
}
}
}
},selectElementChildren:function(_80c){
var _80d=dojo.global();
var _80e=dojo.doc();
_80c=dojo.byId(_80c);
if(_80e.selection&&dojo.body().createTextRange){
var _80f=dojo.body().createTextRange();
_80f.moveToElementText(_80c);
_80f.select();
}else{
if(_80d["getSelection"]){
var _810=_80d.getSelection();
if(_810["selectAllChildren"]){
_810.selectAllChildren(_80c);
}
}
}
},getBookmark:function(){
var _811;
var _812=dojo.doc();
if(_812["selection"]){
var _813=_812.selection.createRange();
_811=_813.getBookmark();
}else{
var _814;
try{
_814=dojo.global().getSelection();
}
catch(e){
}
if(_814){
var _813=_814.getRangeAt(0);
_811=_813.cloneRange();
}else{
dojo.debug("No idea how to store the current selection for this browser!");
}
}
return _811;
},moveToBookmark:function(_815){
var _816=dojo.doc();
if(_816["selection"]){
var _817=_816.selection.createRange();
_817.moveToBookmark(_815);
_817.select();
}else{
var _818;
try{
_818=dojo.global().getSelection();
}
catch(e){
}
if(_818&&_818["removeAllRanges"]){
_818.removeAllRanges();
_818.addRange(_815);
}else{
dojo.debug("No idea how to restore selection for this browser!");
}
}
},collapse:function(_819){
if(dojo.global()["getSelection"]){
var _81a=dojo.global().getSelection();
if(_81a.removeAllRanges){
if(_819){
_81a.collapseToStart();
}else{
_81a.collapseToEnd();
}
}else{
dojo.global().getSelection().collapse(_819);
}
}else{
if(dojo.doc().selection){
var _81b=dojo.doc().selection.createRange();
_81b.collapse(_819);
_81b.select();
}
}
},remove:function(){
if(dojo.doc().selection){
var _81c=dojo.doc().selection;
if(_81c.type.toUpperCase()!="NONE"){
_81c.clear();
}
return _81c;
}else{
var _81c=dojo.global().getSelection();
for(var i=0;i<_81c.rangeCount;i++){
_81c.getRangeAt(i).deleteContents();
}
return _81c;
}
}});
dojo.provide("dojo.widget.Menu2");
dojo.declare("dojo.widget.PopupContainerBase",null,function(){
this.queueOnAnimationFinish=[];
},{isContainer:true,templateString:"<div dojoAttachPoint=\"containerNode\" style=\"display:none;position:absolute;\" class=\"dojoPopupContainer\" ></div>",isShowingNow:false,currentSubpopup:null,beginZIndex:1000,parentPopup:null,parent:null,popupIndex:0,aroundBox:dojo.html.boxSizing.BORDER_BOX,openedForWindow:null,processKey:function(evt){
return false;
},applyPopupBasicStyle:function(){
with(this.domNode.style){
display="none";
position="absolute";
}
},aboutToShow:function(){
},open:function(x,y,_821,_822,_823,_824){
if(this.isShowingNow){
return;
}
this.aboutToShow();
if(this.animationInProgress){
this.queueOnAnimationFinish.push(this.open,arguments);
return;
}
this.parent=_821;
var _825=false,node,aroundOrient;
if(typeof x=="object"){
node=x;
aroundOrient=_822;
_822=_821;
_821=y;
_825=true;
}
dojo.body().appendChild(this.domNode);
_822=_822||_821["domNode"]||[];
var _826=null;
this.isTopLevel=true;
while(_821){
if(_821!==this&&(_821.setOpenedSubpopup!=undefined&&_821.applyPopupBasicStyle!=undefined)){
_826=_821;
this.isTopLevel=false;
_826.setOpenedSubpopup(this);
break;
}
_821=_821.parent;
}
this.parentPopup=_826;
this.popupIndex=_826?_826.popupIndex+1:1;
if(this.isTopLevel){
var _827=_822 instanceof Array?null:_822;
dojo.widget.PopupManager.opened(this,_827);
}
if(this.isTopLevel&&!dojo.withGlobal(this.openedForWindow||dojo.global(),dojo.html.selection.isCollapsed)){
this._bookmark=dojo.withGlobal(this.openedForWindow||dojo.global(),dojo.html.selection.getBookmark);
}else{
this._bookmark=null;
}
if(_822 instanceof Array){
_822={left:_822[0],top:_822[1],width:0,height:0};
}
with(this.domNode.style){
display="";
zIndex=this.beginZIndex+this.popupIndex;
}
if(_825){
this.move(node,_824,aroundOrient);
}else{
this.move(x,y,_824,_823);
}
this.domNode.style.display="none";
this.explodeSrc=_822;
this.show();
this.isShowingNow=true;
},move:function(x,y,_82a,_82b){
var _82c=(typeof x=="object");
if(_82c){
var _82d=_82a;
var node=x;
_82a=y;
if(!_82d){
_82d={"BL":"TL","TL":"BL"};
}
dojo.html.placeOnScreenAroundElement(this.domNode,node,_82a,this.aroundBox,_82d);
}else{
if(!_82b){
_82b="TL,TR,BL,BR";
}
dojo.html.placeOnScreen(this.domNode,x,y,_82a,true,_82b);
}
},close:function(_82f){
if(_82f){
this.domNode.style.display="none";
}
if(this.animationInProgress){
this.queueOnAnimationFinish.push(this.close,[]);
return;
}
this.closeSubpopup(_82f);
this.hide();
if(this.bgIframe){
this.bgIframe.hide();
this.bgIframe.size({left:0,top:0,width:0,height:0});
}
if(this.isTopLevel){
dojo.widget.PopupManager.closed(this);
}
this.isShowingNow=false;
try{
this.parent.domNode.focus();
}
catch(e){
}
if(this._bookmark&&dojo.withGlobal(this.openedForWindow||dojo.global(),dojo.html.selection.isCollapsed)){
if(this.openedForWindow){
this.openedForWindow.focus();
}
dojo.withGlobal(this.openedForWindow||dojo.global(),"moveToBookmark",dojo.html.selection,[this._bookmark]);
}
this._bookmark=null;
},closeAll:function(_830){
if(this.parentPopup){
this.parentPopup.closeAll(_830);
}else{
this.close(_830);
}
},setOpenedSubpopup:function(_831){
this.currentSubpopup=_831;
},closeSubpopup:function(_832){
if(this.currentSubpopup==null){
return;
}
this.currentSubpopup.close(_832);
this.currentSubpopup=null;
},onShow:function(){
this.inherited("onShow");
this.openedSize={w:this.domNode.style.width,h:this.domNode.style.height};
if(dojo.render.html.ie){
if(!this.bgIframe){
this.bgIframe=new dojo.html.BackgroundIframe();
this.bgIframe.setZIndex(this.domNode);
}
this.bgIframe.size(this.domNode);
this.bgIframe.show();
}
this.processQueue();
},processQueue:function(){
if(!this.queueOnAnimationFinish.length){
return;
}
var func=this.queueOnAnimationFinish.shift();
var args=this.queueOnAnimationFinish.shift();
func.apply(this,args);
},onHide:function(){
dojo.widget.HtmlWidget.prototype.onHide.call(this);
if(this.openedSize){
with(this.domNode.style){
width=this.openedSize.w;
height=this.openedSize.h;
}
}
this.processQueue();
}});
dojo.widget.defineWidget("dojo.widget.PopupContainer",[dojo.widget.HtmlWidget,dojo.widget.PopupContainerBase],{});
dojo.widget.defineWidget("dojo.widget.PopupMenu2",dojo.widget.PopupContainer,function(){
this.targetNodeIds=[];
this.eventNames={open:""};
},{templateCssString:"",currentSubmenuTrigger:null,snarfChildDomOutput:true,eventNaming:"default",templateString:"<table class=\"dojoPopupMenu2\" border=0 cellspacing=0 cellpadding=0 style=\"display: none;\"><tbody dojoAttachPoint=\"containerNode\"></tbody></table>",templateCssString:"\n.dojoPopupMenu2 {\n	position: absolute;\n	border: 1px solid #7298d0;\n	background:#a9ccfe url(images/soriaMenuBg.gif) repeat-x bottom left !important;\n	padding: 1px;\n	margin-top: 1px;\n	margin-bottom: 1px;\n}\n\n.dojoMenuItem2{\n	white-space: nowrap;\n	font: menu;\n	margin: 0;\n}\n\n.dojoMenuItem2Hover {\n	background-color: #D2E4FD;\n	cursor:pointer;\n	cursor:hand;\n}\n\n.dojoMenuItem2Icon {\n	position: relative;\n	background-position: center center;\n	background-repeat: no-repeat;\n	width: 16px;\n	height: 16px;\n	padding-right: 3px;\n}\n\n.dojoMenuItem2Label {\n	position: relative;\n	vertical-align: middle;\n}\n\n/* main label text */\n.dojoMenuItem2Label {\n	position: relative;\n	vertical-align: middle;\n}\n\n.dojoMenuItem2Accel {\n	position: relative;\n	vertical-align: middle;\n	padding-left: 3px;\n}\n\n.dojoMenuItem2Disabled .dojoMenuItem2Label,\n.dojoMenuItem2Disabled .dojoMenuItem2Accel {\n	color: #607a9e;\n}\n\n.dojoMenuItem2Submenu {\n	position: relative;\n	background-position: center center;\n	background-repeat: no-repeat;\n	background-image: url(images/submenu_off.gif);\n	width: 5px;\n	height: 9px;\n	padding-left: 3px;\n}\n.dojoMenuItem2Hover .dojoMenuItem2Submenu {\n	background-image: url(images/submenu_on.gif);\n}\n\n.dojoMenuSeparator2 {\n	font-size: 1px;\n	margin: 0;\n}\n\n.dojoMenuSeparator2Top {\n	height: 50%;\n	border-bottom: 1px solid #7996c1;\n	margin: 0px 2px;\n	font-size: 1px;\n}\n\n.dojoMenuSeparator2Bottom {\n	height: 50%;\n	border-top: 1px solid #e3eeff;\n	margin: 0px 2px;\n	font-size: 1px;\n}\n\n.dojoMenuBar2 {\n	/*position: relative;*/\n	background:#a9ccfe url(images/soriaBarBg.gif) repeat-x bottom left;\n	border-bottom:1px solid #405067;\n	border-top:1px solid #708bb3;\n}\n\n.dojoMenuBar2Client {\n	padding: 1px;\n}\n\n.dojoMenuBarItem2 {\n	white-space: nowrap;\n	font: menu;\n	margin: 0;\n	position: relative;\n	vertical-align: middle;\n	z-index: 1;\n	padding: 3px 8px;\n}\n\n.dojoMenuBarItem2 span {\n	margin: 0;\n	position: relative;\n	z-index: 2;\n	cursor:pointer;\n	cursor:hand;\n}\n\n.dojoMenuBarItem2 span span {\n	position: absolute;\n	display: none;\n	left: 1px;\n	top: 1px;\n	z-index: -2;\n}\n\n.dojoMenuBarItem2Hover {\n	background-color:#d2e4fd;\n}\n\n.dojoMenuBarItem2Disabled span {\n	color: #4f6582;\n}\n\n.dojoMenuBarItem2Disabled span span {\n	display: block;\n}\n\n.dojoMenuBarItem2Hover span span,\n.dojoMenuBarItem2Hover span span {\n	display: none;\n}\n",templateCssPath:dojo.uri.dojoUri("src/widget/templates/Menu2.css"),submenuDelay:500,submenuOverlap:5,contextMenuForWindow:false,openEvent:null,_highlighted_option:null,initialize:function(args,frag){
if(this.eventNaming=="default"){
for(var _837 in this.eventNames){
this.eventNames[_837]=this.widgetId+"/"+_837;
}
}
},postCreate:function(){
if(this.contextMenuForWindow){
var doc=dojo.body();
this.bindDomNode(doc);
}else{
if(this.targetNodeIds.length>0){
dojo.lang.forEach(this.targetNodeIds,this.bindDomNode,this);
}
}
this.subscribeSubitemsOnOpen();
},subscribeSubitemsOnOpen:function(){
var _839=this.getChildrenOfType(dojo.widget.MenuItem2);
for(var i=0;i<_839.length;i++){
dojo.event.topic.subscribe(this.eventNames.open,_839[i],"menuOpen");
}
},getTopOpenEvent:function(){
var menu=this;
while(menu.parentPopup){
menu=menu.parentPopup;
}
return menu.openEvent;
},bindDomNode:function(node){
node=dojo.byId(node);
var win=dojo.html.getElementWindow(node);
if(dojo.html.isTag(node,"iframe")=="iframe"){
win=dojo.html.iframeContentWindow(node);
node=dojo.withGlobal(win,dojo.body);
}
dojo.widget.Menu2.OperaAndKonqFixer.fixNode(node);
dojo.event.kwConnect({srcObj:node,srcFunc:"oncontextmenu",targetObj:this,targetFunc:"onOpen",once:true});
if(dojo.render.html.moz&&win.document.designMode.toLowerCase()=="on"){
dojo.event.browser.addListener(node,"contextmenu",dojo.lang.hitch(this,"onOpen"));
}
dojo.widget.PopupManager.registerWin(win);
},unBindDomNode:function(_83e){
var node=dojo.byId(_83e);
dojo.event.kwDisconnect({srcObj:node,srcFunc:"oncontextmenu",targetObj:this,targetFunc:"onOpen",once:true});
dojo.widget.Menu2.OperaAndKonqFixer.cleanNode(node);
},moveToNext:function(evt){
this.highlightOption(1);
return true;
},moveToPrevious:function(evt){
this.highlightOption(-1);
return true;
},moveToParentMenu:function(evt){
if(this._highlighted_option&&this.parentPopup){
if(evt._menu2UpKeyProcessed){
return true;
}else{
this._highlighted_option.onUnhover();
this.closeSubpopup();
evt._menu2UpKeyProcessed=true;
}
}
return false;
},moveToChildMenu:function(evt){
if(this._highlighted_option&&this._highlighted_option.submenuId){
this._highlighted_option._onClick(true);
return true;
}
return false;
},selectCurrentItem:function(evt){
if(this._highlighted_option){
this._highlighted_option._onClick();
return true;
}
return false;
},processKey:function(evt){
if(evt.ctrlKey||evt.altKey||!evt.key){
return false;
}
var rval=false;
switch(evt.key){
case evt.KEY_DOWN_ARROW:
rval=this.moveToNext(evt);
break;
case evt.KEY_UP_ARROW:
rval=this.moveToPrevious(evt);
break;
case evt.KEY_RIGHT_ARROW:
rval=this.moveToChildMenu(evt);
break;
case evt.KEY_LEFT_ARROW:
rval=this.moveToParentMenu(evt);
break;
case " ":
case evt.KEY_ENTER:
if(rval=this.selectCurrentItem(evt)){
break;
}
case evt.KEY_ESCAPE:
dojo.widget.PopupManager.currentMenu.close();
rval=true;
break;
}
return rval;
},findValidItem:function(dir,_848){
if(_848){
_848=dir>0?_848.getNextSibling():_848.getPreviousSibling();
}
for(var i=0;i<this.children.length;++i){
if(!_848){
_848=dir>0?this.children[0]:this.children[this.children.length-1];
}
if(_848.onHover&&_848.isShowing()){
return _848;
}
_848=dir>0?_848.getNextSibling():_848.getPreviousSibling();
}
},highlightOption:function(dir){
var item;
if((!this._highlighted_option)){
item=this.findValidItem(dir);
}else{
item=this.findValidItem(dir,this._highlighted_option);
}
if(item){
if(this._highlighted_option){
this._highlighted_option.onUnhover();
}
item.onHover();
dojo.html.scrollIntoView(item.domNode);
try{
var node=dojo.html.getElementsByClass("dojoMenuItem2Label",item.domNode)[0];
node.focus();
}
catch(e){
}
}
},onItemClick:function(item){
},close:function(_84e){
if(this.animationInProgress){
dojo.widget.PopupMenu2.superclass.close.apply(this,arguments);
return;
}
if(this._highlighted_option){
this._highlighted_option.onUnhover();
}
dojo.widget.PopupMenu2.superclass.close.apply(this,arguments);
},closeSubpopup:function(_84f){
if(this.currentSubpopup==null){
return;
}
this.currentSubpopup.close(_84f);
this.currentSubpopup=null;
this.currentSubmenuTrigger.is_open=false;
this.currentSubmenuTrigger.closedSubmenu(_84f);
this.currentSubmenuTrigger=null;
},openSubmenu:function(_850,_851){
var _852=dojo.html.getAbsolutePosition(_851.domNode,true);
var _853=dojo.html.getMarginBox(this.domNode).width;
var x=_852.x+_853-this.submenuOverlap;
var y=_852.y;
_850.open(x,y,this,_851.domNode);
this.currentSubmenuTrigger=_851;
this.currentSubmenuTrigger.is_open=true;
},onOpen:function(e){
this.openEvent=e;
if(e["target"]){
this.openedForWindow=dojo.html.getElementWindow(e.target);
}else{
this.openedForWindow=null;
}
var x=e.pageX,y=e.pageY;
var win=dojo.html.getElementWindow(e.target);
var _859=win._frameElement||win.frameElement;
if(_859){
var cood=dojo.html.abs(_859,true);
x+=cood.x-dojo.withGlobal(win,dojo.html.getScroll).left;
y+=cood.y-dojo.withGlobal(win,dojo.html.getScroll).top;
}
this.open(x,y,null,[x,y]);
e.preventDefault();
e.stopPropagation();
}});
dojo.widget.defineWidget("dojo.widget.MenuItem2",dojo.widget.HtmlWidget,function(){
this.eventNames={engage:""};
},{templateString:"<tr class=\"dojoMenuItem2\" dojoAttachEvent=\"onMouseOver: onHover; onMouseOut: onUnhover; onClick: _onClick; onKey:onKey;\">"+"<td><div class=\"${this.iconClass}\" style=\"${this.iconStyle}\"></div></td>"+"<td tabIndex=\"-1\" class=\"dojoMenuItem2Label\">${this.caption}</td>"+"<td class=\"dojoMenuItem2Accel\">${this.accelKey}</td>"+"<td><div class=\"dojoMenuItem2Submenu\" style=\"display:${this.arrowDisplay};\"></div></td>"+"</tr>",is_hovering:false,hover_timer:null,is_open:false,topPosition:0,caption:"Untitled",accelKey:"",iconSrc:"",iconClass:"dojoMenuItem2Icon",submenuId:"",disabled:false,eventNaming:"default",highlightClass:"dojoMenuItem2Hover",postMixInProperties:function(){
this.iconStyle="";
if(this.iconSrc){
if((this.iconSrc.toLowerCase().substring(this.iconSrc.length-4)==".png")&&(dojo.render.html.ie55||dojo.render.html.ie60)){
this.iconStyle="filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+this.iconSrc+"', sizingMethod='image')";
}else{
this.iconStyle="background-image: url("+this.iconSrc+")";
}
}
this.arrowDisplay=this.submenuId?"block":"none";
dojo.widget.MenuItem2.superclass.postMixInProperties.apply(this,arguments);
},fillInTemplate:function(){
dojo.html.disableSelection(this.domNode);
if(this.disabled){
this.setDisabled(true);
}
if(this.eventNaming=="default"){
for(var _85b in this.eventNames){
this.eventNames[_85b]=this.widgetId+"/"+_85b;
}
}
},onHover:function(){
this.onUnhover();
if(this.is_hovering){
return;
}
if(this.is_open){
return;
}
if(this.parent._highlighted_option){
this.parent._highlighted_option.onUnhover();
}
this.parent.closeSubpopup();
this.parent._highlighted_option=this;
dojo.widget.PopupManager.setFocusedMenu(this.parent);
this.highlightItem();
if(this.is_hovering){
this.stopSubmenuTimer();
}
this.is_hovering=true;
this.startSubmenuTimer();
},onUnhover:function(){
if(!this.is_open){
this.unhighlightItem();
}
this.is_hovering=false;
this.parent._highlighted_option=null;
if(this.parent.parentPopup){
dojo.widget.PopupManager.setFocusedMenu(this.parent.parentPopup);
}
this.stopSubmenuTimer();
},_onClick:function(_85c){
var _85d=false;
if(this.disabled){
return false;
}
if(this.submenuId){
if(!this.is_open){
this.stopSubmenuTimer();
this.openSubmenu();
}
_85d=true;
}else{
this.onUnhover();
this.parent.closeAll(true);
}
this.onClick();
dojo.event.topic.publish(this.eventNames.engage,this);
if(_85d&&_85c){
dojo.widget.getWidgetById(this.submenuId).highlightOption(1);
}
return;
},onClick:function(){
this.parent.onItemClick(this);
},highlightItem:function(){
dojo.html.addClass(this.domNode,this.highlightClass);
},unhighlightItem:function(){
dojo.html.removeClass(this.domNode,this.highlightClass);
},startSubmenuTimer:function(){
this.stopSubmenuTimer();
if(this.disabled){
return;
}
var self=this;
var _85f=function(){
return function(){
self.openSubmenu();
};
}();
this.hover_timer=dojo.lang.setTimeout(_85f,this.parent.submenuDelay);
},stopSubmenuTimer:function(){
if(this.hover_timer){
dojo.lang.clearTimeout(this.hover_timer);
this.hover_timer=null;
}
},openSubmenu:function(){
this.parent.closeSubpopup();
var _860=dojo.widget.getWidgetById(this.submenuId);
if(_860){
this.parent.openSubmenu(_860,this);
}
},closedSubmenu:function(){
this.onUnhover();
},setDisabled:function(_861){
this.disabled=_861;
if(this.disabled){
dojo.html.addClass(this.domNode,"dojoMenuItem2Disabled");
}else{
dojo.html.removeClass(this.domNode,"dojoMenuItem2Disabled");
}
},enable:function(){
this.setDisabled(false);
},disable:function(){
this.setDisabled(true);
},menuOpen:function(_862){
}});
dojo.widget.defineWidget("dojo.widget.MenuSeparator2",dojo.widget.HtmlWidget,{templateString:"<tr class=\"dojoMenuSeparator2\"><td colspan=4>"+"<div class=\"dojoMenuSeparator2Top\"></div>"+"<div class=\"dojoMenuSeparator2Bottom\"></div>"+"</td></tr>",postCreate:function(){
dojo.html.disableSelection(this.domNode);
}});
dojo.widget.PopupManager=new function(){
this.currentMenu=null;
this.currentButton=null;
this.currentFocusMenu=null;
this.focusNode=null;
this.registeredWindows=[];
this.registerWin=function(win){
if(!win.__PopupManagerRegistered){
dojo.event.connect(win.document,"onmousedown",this,"onClick");
dojo.event.connect(win,"onscroll",this,"onClick");
dojo.event.connect(win.document,"onkey",this,"onKey");
win.__PopupManagerRegistered=true;
this.registeredWindows.push(win);
}
};
this.registerAllWindows=function(_864){
if(!_864){
_864=dojo.html.getDocumentWindow(window.top.document);
}
this.registerWin(_864);
for(var i=0;i<_864.frames.length;i++){
try{
var win=dojo.html.getDocumentWindow(_864.frames[i].document);
if(win){
this.registerAllWindows(win);
}
}
catch(e){
}
}
};
this.unRegisterWin=function(win){
if(win.__PopupManagerRegistered){
dojo.event.disconnect(win.document,"onmousedown",this,"onClick");
dojo.event.disconnect(win,"onscroll",this,"onClick");
dojo.event.disconnect(win.document,"onkey",this,"onKey");
win.__PopupManagerRegistered=false;
}
};
this.unRegisterAllWindows=function(){
for(var i=0;i<this.registeredWindows.length;++i){
this.unRegisterWin(this.registeredWindows[i]);
}
this.registeredWindows=[];
};
dojo.addOnLoad(this,"registerAllWindows");
dojo.addOnUnload(this,"unRegisterAllWindows");
this.closed=function(menu){
if(this.currentMenu==menu){
this.currentMenu=null;
this.currentButton=null;
this.currentFocusMenu=null;
}
};
this.opened=function(menu,_86b){
if(menu==this.currentMenu){
return;
}
if(this.currentMenu){
this.currentMenu.close();
}
this.currentMenu=menu;
this.currentFocusMenu=menu;
this.currentButton=_86b;
};
this.setFocusedMenu=function(menu){
this.currentFocusMenu=menu;
};
this.onKey=function(e){
if(!e.key){
return;
}
if(!this.currentMenu||!this.currentMenu.isShowingNow){
return;
}
var m=this.currentFocusMenu;
while(m){
if(m.processKey(e)){
e.preventDefault();
e.stopPropagation();
break;
}
m=m.parentPopup;
}
},this.onClick=function(e){
if(!this.currentMenu){
return;
}
var _870=dojo.html.getScroll().offset;
var m=this.currentMenu;
while(m){
if(dojo.html.overElement(m.domNode,e)||dojo.html.isDescendantOf(e.target,m.domNode)){
return;
}
m=m.currentSubpopup;
}
if(this.currentButton&&dojo.html.overElement(this.currentButton,e)){
return;
}
this.currentMenu.close();
};
};
dojo.widget.Menu2.OperaAndKonqFixer=new function(){
var _872=true;
var _873=false;
if(!dojo.lang.isFunction(dojo.doc().oncontextmenu)){
dojo.doc().oncontextmenu=function(){
_872=false;
_873=true;
};
}
if(dojo.doc().createEvent){
try{
var e=dojo.doc().createEvent("MouseEvents");
e.initMouseEvent("contextmenu",1,1,dojo.global(),1,0,0,0,0,0,0,0,0,0,null);
dojo.doc().dispatchEvent(e);
}
catch(e){
}
}else{
_872=false;
}
if(_873){
delete dojo.doc().oncontextmenu;
}
this.fixNode=function(node){
if(_872){
if(!dojo.lang.isFunction(node.oncontextmenu)){
node.oncontextmenu=function(e){
};
}
if(dojo.render.html.opera){
node._menufixer_opera=function(e){
if(e.ctrlKey){
this.oncontextmenu(e);
}
};
dojo.event.connect(node,"onclick",node,"_menufixer_opera");
}else{
node._menufixer_konq=function(e){
if(e.button==2){
e.preventDefault();
this.oncontextmenu(e);
}
};
dojo.event.connect(node,"onmousedown",node,"_menufixer_konq");
}
}
};
this.cleanNode=function(node){
if(_872){
if(node._menufixer_opera){
dojo.event.disconnect(node,"onclick",node,"_menufixer_opera");
delete node._menufixer_opera;
}else{
if(node._menufixer_konq){
dojo.event.disconnect(node,"onmousedown",node,"_menufixer_konq");
delete node._menufixer_konq;
}
}
if(node.oncontextmenu){
delete node.oncontextmenu;
}
}
};
};
dojo.widget.defineWidget("dojo.widget.MenuBar2",dojo.widget.PopupMenu2,{menuOverlap:2,templateString:"<div class=\"dojoMenuBar2\" tabIndex=\"0\"><table class=\"dojoMenuBar2Client\"><tr dojoAttachPoint=\"containerNode\"></tr></table></div>",close:function(_87a){
if(this._highlighted_option){
this._highlighted_option.onUnhover();
}
this.closeSubpopup(_87a);
},processKey:function(evt){
if(evt.ctrlKey||evt.altKey){
return false;
}
if(!dojo.html.hasClass(evt.target,"dojoMenuBar2")){
return false;
}
var rval=false;
switch(evt.key){
case evt.KEY_DOWN_ARROW:
rval=this.moveToChildMenu(evt);
break;
case evt.KEY_UP_ARROW:
rval=this.moveToParentMenu(evt);
break;
case evt.KEY_RIGHT_ARROW:
rval=this.moveToNext(evt);
break;
case evt.KEY_LEFT_ARROW:
rval=this.moveToPrevious(evt);
break;
default:
rval=this.inherited("processKey",[evt]);
break;
}
return rval;
},postCreate:function(){
this.inherited("postCreate");
dojo.widget.PopupManager.opened(this);
this.isShowingNow=true;
},openSubmenu:function(_87d,_87e){
var _87f=dojo.html.getAbsolutePosition(_87e.domNode,true);
var _880=dojo.html.getAbsolutePosition(this.domNode,true);
var _881=dojo.html.getBorderBox(this.domNode).height;
var x=_87f.x;
var y=_880.y+_881-this.menuOverlap;
_87d.open(x,y,this,_87e.domNode);
this.currentSubmenuTrigger=_87e;
this.currentSubmenuTrigger.is_open=true;
}});
dojo.widget.defineWidget("dojo.widget.MenuBarItem2",dojo.widget.MenuItem2,{templateString:"<td class=\"dojoMenuBarItem2\" dojoAttachEvent=\"onMouseOver: onHover; onMouseOut: onUnhover; onClick: _onClick;\">"+"<span><span>${this.caption}</span>${this.caption}</span>"+"</td>",highlightClass:"dojoMenuBarItem2Hover",setDisabled:function(_884){
this.disabled=_884;
if(this.disabled){
dojo.html.addClass(this.domNode,"dojoMenuBarItem2Disabled");
}else{
dojo.html.removeClass(this.domNode,"dojoMenuBarItem2Disabled");
}
}});
dojo.provide("dojo.widget.ComboBox");
dojo.widget.incrementalComboBoxDataProvider=function(url,_886,_887){
this.searchUrl=url;
this.inFlight=false;
this.activeRequest=null;
this.allowCache=false;
this.cache={};
this.init=function(cbox){
this.searchUrl=cbox.dataUrl;
};
this.addToCache=function(_889,data){
if(this.allowCache){
this.cache[_889]=data;
}
};
this.startSearch=function(_88b,type,_88d){
if(this.inFlight){
}
var tss=encodeURIComponent(_88b);
var _88f=dojo.string.substituteParams(this.searchUrl,{"searchString":tss});
var _890=this;
var _891=dojo.io.bind({url:_88f,method:"get",mimetype:"text/json",load:function(type,data,evt){
_890.inFlight=false;
if(!dojo.lang.isArray(data)){
var _895=[];
for(var key in data){
_895.push([data[key],key]);
}
data=_895;
}
_890.addToCache(_88b,data);
_890.provideSearchResults(data);
}});
this.inFlight=true;
};
};
dojo.widget.ComboBoxDataProvider=function(_897,_898,_899){
this.data=[];
this.searchTimeout=_899|500;
this.searchLimit=_898|30;
this.searchType="STARTSTRING";
this.caseSensitive=false;
this._lastSearch="";
this._lastSearchResults=null;
this.init=function(cbox,node){
if(!dojo.string.isBlank(cbox.dataUrl)){
this.getData(cbox.dataUrl);
}else{
if((node)&&(node.nodeName.toLowerCase()=="select")){
var opts=node.getElementsByTagName("option");
var ol=opts.length;
var data=[];
for(var x=0;x<ol;x++){
var _8a0=[String(opts[x].innerHTML),String(opts[x].value)];
data.push(_8a0);
if(opts[x].selected){
cbox.setAllValues(_8a0[0],_8a0[1]);
}
}
this.setData(data);
}
}
};
this.getData=function(url){
dojo.io.bind({url:url,load:dojo.lang.hitch(this,function(type,data,evt){
if(!dojo.lang.isArray(data)){
var _8a5=[];
for(var key in data){
_8a5.push([data[key],key]);
}
data=_8a5;
}
this.setData(data);
}),mimetype:"text/json"});
};
this.startSearch=function(_8a7,type,_8a9){
this._preformSearch(_8a7,type,_8a9);
};
this._preformSearch=function(_8aa,type,_8ac){
var st=type||this.searchType;
var ret=[];
if(!this.caseSensitive){
_8aa=_8aa.toLowerCase();
}
for(var x=0;x<this.data.length;x++){
if((!_8ac)&&(ret.length>=this.searchLimit)){
break;
}
var _8b0=new String((!this.caseSensitive)?this.data[x][0].toLowerCase():this.data[x][0]);
if(_8b0.length<_8aa.length){
continue;
}
if(st=="STARTSTRING"){
if(_8aa==_8b0.substr(0,_8aa.length)){
ret.push(this.data[x]);
}
}else{
if(st=="SUBSTRING"){
if(_8b0.indexOf(_8aa)>=0){
ret.push(this.data[x]);
}
}else{
if(st=="STARTWORD"){
var idx=_8b0.indexOf(_8aa);
if(idx==0){
ret.push(this.data[x]);
}
if(idx<=0){
continue;
}
var _8b2=false;
while(idx!=-1){
if(" ,/(".indexOf(_8b0.charAt(idx-1))!=-1){
_8b2=true;
break;
}
idx=_8b0.indexOf(_8aa,idx+1);
}
if(!_8b2){
continue;
}else{
ret.push(this.data[x]);
}
}
}
}
}
this.provideSearchResults(ret);
};
this.provideSearchResults=function(_8b3){
};
this.addData=function(_8b4){
this.data=this.data.concat(_8b4);
};
this.setData=function(_8b5){
this.data=_8b5;
};
if(_897){
this.setData(_897);
}
};
dojo.widget.defineWidget("dojo.widget.ComboBox",dojo.widget.HtmlWidget,{isContainer:false,forceValidOption:false,searchType:"stringstart",dataProvider:null,startSearch:function(_8b6){
},selectNextResult:function(){
},selectPrevResult:function(){
},setSelectedResult:function(){
},autoComplete:true,formInputName:"",name:"",textInputNode:null,comboBoxValue:null,comboBoxSelectionValue:null,optionsListWrapper:null,optionsListNode:null,downArrowNode:null,cbTableNode:null,searchTimer:null,searchDelay:100,dataUrl:"",fadeTime:200,maxListLength:8,mode:"local",selectedResult:null,_highlighted_option:null,_prev_key_backspace:false,_prev_key_esc:false,_gotFocus:false,_mouseover_list:false,dataProviderClass:"dojo.widget.ComboBoxDataProvider",buttonSrc:dojo.uri.dojoUri("src/widget/templates/images/combo_box_arrow.png"),dropdownToggle:"fade",templateString:"<span>\n	<input style=\"display:none\"  tabindex=\"-1\" name=\"\" value=\"\" \n		dojoAttachPoint=\"comboBoxValue\">\n	<input style=\"display:none\"  tabindex=\"-1\" name=\"\" value=\"\" \n		dojoAttachPoint=\"comboBoxSelectionValue\">\n	<table class=\"dojoComboBox\"\n		cellpadding=\"0\"\n		cellspacing=\"0\"\n		border=\"0\"\n		dojoAttachPoint=\"cbTableNode\">\n		<tr>\n			<td><input type=\"text\" autocomplete=\"off\" class=\"dojoComboBoxInput\"\n					dojoAttachEvent=\"keyDown: onKeyDown; keyUp: onKeyUp; keyPress: onKeyPress; compositionEnd; onResize\"\n					dojoAttachPoint=\"textInputNode\"></td>\n			<td><img border=\"0\" \n					hspace=\"0\"\n					vspace=\"0\"\n					class=\"dojoComboArrow\"\n					dojoAttachPoint=\"downArrowNode\"\n					dojoAttachEvent=\"onMouseUp: handleArrowClick;\"\n					src=\"${this.buttonSrc}\"\n					style=\"width: ${this.initialButtonSize}; height: ${this.initialButtonSize};\"></td>\n		</tr>\n	</table>\n</span>\n",templateCssString:"/* the table holding the input and the button */\n.dojoComboBox {\n	border: 1px solid #afafaf;\n	padding: 0px;\n	line-height: 0px;\n	display: inline;	/* for IE and safari */\n}\n\n.dj_gecko .dojoComboBox {\n	display: -moz-inline-box;\n}\n\n.dj_opera .dojoComboBox {\n	display: inline-table;\n}\n\n/* the input box */\ninput.dojoComboBoxInput {\n	/* font-size: 0.8em; */\n	border: 0px;\n	margin: 0px;\n	padding: 0px;\n}\n\n/* the drop down */\n.dojoComboBoxOptions {\n	font-family: Verdana, Helvetica, Garamond, sans-serif;\n	/* font-size: 0.7em; */\n	background-color: white;\n	border: 1px solid #afafaf;\n	position: absolute;\n	z-index: 1000; \n	overflow: auto;\n	cursor: default;\n}\n\n.dojoComboBoxItem {\n	padding-left: 2px;\n	padding-top: 2px;\n	margin: 0px;\n}\n\n.dojoComboBoxItemEven {\n	background-color: #f4f4f4;\n}\n\n.dojoComboBoxItemOdd {\n	background-color: white;\n}\n\n.dojoComboBoxItemHighlight {\n	background-color: #63709A;\n	color: white;\n}\n",templateCssPath:dojo.uri.dojoUri("src/widget/templates/ComboBox.css"),setValue:function(_8b7){
this.comboBoxValue.value=_8b7;
if(this.textInputNode.value!=_8b7){
this.textInputNode.value=_8b7;
}
dojo.widget.html.stabile.setState(this.widgetId,this.getState(),true);
this.onValueChanged(_8b7);
},onValueChanged:function(){
},getValue:function(){
return this.comboBoxValue.value;
},getState:function(){
return {value:this.getValue()};
},setState:function(_8b8){
this.setValue(_8b8.value);
},getCaretPos:function(_8b9){
if(dojo.lang.isNumber(_8b9.selectionStart)){
return _8b9.selectionStart;
}else{
if(dojo.render.html.ie){
var tr=document.selection.createRange().duplicate();
var ntr=_8b9.createTextRange();
tr.move("character",0);
ntr.move("character",0);
try{
ntr.setEndPoint("EndToEnd",tr);
return String(ntr.text).replace(/\r/g,"").length;
}
catch(e){
return 0;
}
}
}
},setCaretPos:function(_8bc,_8bd){
_8bd=parseInt(_8bd);
this.setSelectedRange(_8bc,_8bd,_8bd);
},setSelectedRange:function(_8be,_8bf,end){
if(!end){
end=_8be.value.length;
}
if(_8be.setSelectionRange){
_8be.focus();
_8be.setSelectionRange(_8bf,end);
}else{
if(_8be.createTextRange){
var _8c1=_8be.createTextRange();
with(_8c1){
collapse(true);
moveEnd("character",end);
moveStart("character",_8bf);
select();
}
}else{
_8be.value=_8be.value;
_8be.blur();
_8be.focus();
var dist=parseInt(_8be.value.length)-end;
var _8c3=String.fromCharCode(37);
var tcc=_8c3.charCodeAt(0);
for(var x=0;x<dist;x++){
var te=document.createEvent("KeyEvents");
te.initKeyEvent("keypress",true,true,null,false,false,false,false,tcc,tcc);
_8be.dispatchEvent(te);
}
}
}
},_handleKeyEvents:function(evt){
if(evt.ctrlKey||evt.altKey){
return;
}
this._prev_key_backspace=false;
this._prev_key_esc=false;
var k=dojo.event.browser.keys;
var _8c9=true;
var _8ca=evt.keyCode;
if(_8ca==0&&evt.charCode==k.KEY_SPACE){
_8ca=k.KEY_SPACE;
}
if(dojo.render.html.safari){
switch(_8ca){
case 63232:
_8ca=k.KEY_UP_ARROW;
break;
case 63233:
_8ca=k.KEY_DOWN_ARROW;
break;
}
}
switch(_8ca){
case k.KEY_DOWN_ARROW:
if(!this.popupWidget.isShowingNow){
this.startSearchFromInput();
}
this.highlightNextOption();
dojo.event.browser.stopEvent(evt);
return;
case k.KEY_UP_ARROW:
this.highlightPrevOption();
dojo.event.browser.stopEvent(evt);
return;
case k.KEY_ENTER:
if(this.popupWidget.isShowingNow){
dojo.event.browser.stopEvent(evt);
}
case k.KEY_TAB:
if(!this.autoComplete&&this.popupWidget.isShowingNow&&this._highlighted_option){
dojo.event.browser.stopEvent(evt);
this.selectOption({"target":this._highlighted_option,"noHide":false});
this.setSelectedRange(this.textInputNode,this.textInputNode.value.length,null);
}else{
this.selectOption();
return;
}
break;
case k.KEY_SPACE:
if(this.popupWidget.isShowingNow&&this._highlighted_option){
dojo.event.browser.stopEvent(evt);
this.selectOption();
this.hideResultList();
return;
}
break;
case k.KEY_ESCAPE:
this.hideResultList();
this._prev_key_esc=true;
return;
case k.KEY_BACKSPACE:
this._prev_key_backspace=true;
if(!this.textInputNode.value.length){
this.setAllValues("","");
this.hideResultList();
_8c9=false;
}
break;
case k.KEY_RIGHT_ARROW:
case k.KEY_LEFT_ARROW:
case k.KEY_SHIFT:
_8c9=false;
break;
default:
if(evt.charCode==0){
_8c9=false;
}
}
if(this.searchTimer){
clearTimeout(this.searchTimer);
}
if(_8c9){
this.blurOptionNode();
this.searchTimer=setTimeout(dojo.lang.hitch(this,this.startSearchFromInput),this.searchDelay);
}
},onKeyDown:function(evt){
if(!document.createEvent){
this._handleKeyEvents(evt);
}
},onKeyPress:function(evt){
if(document.createEvent){
this._handleKeyEvents(evt);
}
},compositionEnd:function(evt){
this._handleKeyEvents(evt);
},onKeyUp:function(evt){
this.setValue(this.textInputNode.value);
},setSelectedValue:function(_8cf){
this.comboBoxSelectionValue.value=_8cf;
},setAllValues:function(_8d0,_8d1){
this.setValue(_8d0);
this.setSelectedValue(_8d1);
},focusOptionNode:function(node){
if(this._highlighted_option!=node){
this.blurOptionNode();
this._highlighted_option=node;
dojo.html.addClass(this._highlighted_option,"dojoComboBoxItemHighlight");
}
},blurOptionNode:function(){
if(this._highlighted_option){
dojo.html.removeClass(this._highlighted_option,"dojoComboBoxItemHighlight");
this._highlighted_option=null;
}
},highlightNextOption:function(){
if((!this._highlighted_option)||!this._highlighted_option.parentNode){
this.focusOptionNode(this.optionsListNode.firstChild);
}else{
if(this._highlighted_option.nextSibling){
this.focusOptionNode(this._highlighted_option.nextSibling);
}
}
dojo.html.scrollIntoView(this._highlighted_option);
},highlightPrevOption:function(){
if(this._highlighted_option&&this._highlighted_option.previousSibling){
this.focusOptionNode(this._highlighted_option.previousSibling);
}else{
this._highlighted_option=null;
this.hideResultList();
return;
}
dojo.html.scrollIntoView(this._highlighted_option);
},itemMouseOver:function(evt){
if(evt.target===this.optionsListNode){
return;
}
this.focusOptionNode(evt.target);
dojo.html.addClass(this._highlighted_option,"dojoComboBoxItemHighlight");
},itemMouseOut:function(evt){
if(evt.target===this.optionsListNode){
return;
}
this.blurOptionNode();
},onResize:function(){
var _8d5=dojo.html.getBorderBox(this.textInputNode);
var _8d6={width:_8d5.height,height:_8d5.height};
dojo.html.setMarginBox(this.downArrowNode,_8d6);
},postMixInProperties:function(args,frag){
this.inherited("postMixInProperties",[args,frag]);
var _8d9=this.getFragNodeRef(frag);
var _8da=dojo.html.getBorderBox(_8d9);
this.initialButtonSize=_8da.height+"px";
},fillInTemplate:function(args,frag){
dojo.html.applyBrowserClass(this.domNode);
this.comboBoxValue.name=this.name;
this.comboBoxSelectionValue.name=this.name+"_selected";
var _8dd=this.getFragNodeRef(frag);
dojo.html.copyStyle(this.textInputNode,_8dd);
var _8de;
if(this.mode=="remote"){
_8de=dojo.widget.incrementalComboBoxDataProvider;
}else{
if(typeof this.dataProviderClass=="string"){
_8de=dojo.evalObjPath(this.dataProviderClass);
}else{
_8de=this.dataProviderClass;
}
}
this.dataProvider=new _8de();
this.dataProvider.init(this,this.getFragNodeRef(frag));
this.popupWidget=new dojo.widget.createWidget("PopupContainer",{toggle:this.dropdownToggle,toggleDuration:this.toggleDuration});
dojo.event.connect(this,"destroy",this.popupWidget,"destroy");
this.optionsListNode=this.popupWidget.domNode;
this.domNode.appendChild(this.optionsListNode);
dojo.html.addClass(this.optionsListNode,"dojoComboBoxOptions");
dojo.event.connect(this.optionsListNode,"onclick",this,"selectOption");
dojo.event.connect(this.optionsListNode,"onmouseover",this,"_onMouseOver");
dojo.event.connect(this.optionsListNode,"onmouseout",this,"_onMouseOut");
dojo.event.connect(this.optionsListNode,"onmouseover",this,"itemMouseOver");
dojo.event.connect(this.optionsListNode,"onmouseout",this,"itemMouseOut");
},focus:function(){
this.tryFocus();
},openResultList:function(_8df){
this.clearResultList();
if(!_8df.length){
this.hideResultList();
}
if((this.autoComplete)&&(_8df.length)&&(!this._prev_key_backspace)&&(this.textInputNode.value.length>0)){
var cpos=this.getCaretPos(this.textInputNode);
if((cpos+1)>this.textInputNode.value.length){
this.textInputNode.value+=_8df[0][0].substr(cpos);
this.setSelectedRange(this.textInputNode,cpos,this.textInputNode.value.length);
}
}
var even=true;
while(_8df.length){
var tr=_8df.shift();
if(tr){
var td=document.createElement("div");
td.appendChild(document.createTextNode(tr[0]));
td.setAttribute("resultName",tr[0]);
td.setAttribute("resultValue",tr[1]);
td.className="dojoComboBoxItem "+((even)?"dojoComboBoxItemEven":"dojoComboBoxItemOdd");
even=(!even);
this.optionsListNode.appendChild(td);
}
}
this.showResultList();
},onFocusInput:function(){
this._hasFocus=true;
},onBlurInput:function(){
this._hasFocus=false;
this._handleBlurTimer(true,500);
},_handleBlurTimer:function(_8e4,_8e5){
if(this.blurTimer&&(_8e4||_8e5)){
clearTimeout(this.blurTimer);
}
if(_8e5){
this.blurTimer=dojo.lang.setTimeout(this,"checkBlurred",_8e5);
}
},_onMouseOver:function(evt){
if(!this._mouseover_list){
this._handleBlurTimer(true,0);
this._mouseover_list=true;
}
},_onMouseOut:function(evt){
var _8e8=evt.relatedTarget;
if(!_8e8||_8e8.parentNode!=this.optionsListNode){
this._mouseover_list=false;
this._handleBlurTimer(true,100);
this.tryFocus();
}
},_isInputEqualToResult:function(_8e9){
var _8ea=this.textInputNode.value;
if(!this.dataProvider.caseSensitive){
_8ea=_8ea.toLowerCase();
_8e9=_8e9.toLowerCase();
}
return (_8ea==_8e9);
},_isValidOption:function(){
var tgt=dojo.html.firstElement(this.optionsListNode);
var _8ec=false;
var tgt=dojo.html.firstElement(this.optionsListNode);
var _8ec=false;
while(!_8ec&&tgt){
if(this._isInputEqualToResult(tgt.getAttribute("resultName"))){
_8ec=true;
}else{
tgt=dojo.html.nextElement(tgt);
}
}
return _8ec;
},checkBlurred:function(){
if(!this._hasFocus&&!this._mouseover_list){
this.hideResultList();
if(!this.textInputNode.value.length){
this.setAllValues("","");
return;
}
var _8ed=this._isValidOption();
if(this.forceValidOption&&!_8ed){
this.setAllValues("","");
return;
}
if(!_8ed){
this.setSelectedValue("");
}
}
},sizeBackgroundIframe:function(){
var mb=dojo.html.getMarginBox(this.optionsListNode);
if(mb.width==0||mb.height==0){
dojo.lang.setTimeout(this,"sizeBackgroundIframe",100);
return;
}
},selectOption:function(evt){
var tgt=null;
if(!evt){
evt={target:this._highlighted_option};
}
if(!dojo.html.isDescendantOf(evt.target,this.optionsListNode)){
if(!this.textInputNode.value.length){
return;
}
tgt=dojo.html.firstElement(this.optionsListNode);
if(!tgt||!this._isInputEqualToResult(tgt.getAttribute("resultName"))){
return;
}
}else{
tgt=evt.target;
}
while((tgt.nodeType!=1)||(!tgt.getAttribute("resultName"))){
tgt=tgt.parentNode;
if(tgt===dojo.body()){
return false;
}
}
this.textInputNode.value=tgt.getAttribute("resultName");
this.selectedResult=[tgt.getAttribute("resultName"),tgt.getAttribute("resultValue")];
this.setAllValues(tgt.getAttribute("resultName"),tgt.getAttribute("resultValue"));
if(!evt.noHide){
this.hideResultList();
this.setSelectedRange(this.textInputNode,0,null);
}
this.tryFocus();
},clearResultList:function(){
if(this.optionsListNode.innerHTML){
this.optionsListNode.innerHTML="";
}
},hideResultList:function(){
this.popupWidget.close();
},showResultList:function(){
var _8f1=this.optionsListNode.childNodes;
if(_8f1.length){
var _8f2=this.maxListLength;
if(_8f1.length<_8f2){
_8f2=_8f1.length;
}
with(this.optionsListNode.style){
display="";
if(_8f2==_8f1.length){
height="";
}else{
height=_8f2*dojo.html.getMarginBox(_8f1[0]).height+"px";
}
width=(dojo.html.getMarginBox(this.domNode).width-2)+"px";
}
this.popupWidget.open(this.cbTableNode,this,this.downArrowNode);
}else{
this.hideResultList();
}
},handleArrowClick:function(){
this._handleBlurTimer(true,0);
this.tryFocus();
if(this.popupWidget.isShowingNow){
this.hideResultList();
}else{
this.startSearch("");
}
},tryFocus:function(){
try{
this.textInputNode.focus();
}
catch(e){
}
},startSearchFromInput:function(){
this.startSearch(this.textInputNode.value);
},postCreate:function(){
dojo.event.connect(this,"startSearch",this.dataProvider,"startSearch");
dojo.event.connect(this.dataProvider,"provideSearchResults",this,"openResultList");
dojo.event.connect(this.textInputNode,"onblur",this,"onBlurInput");
dojo.event.connect(this.textInputNode,"onfocus",this,"onFocusInput");
var s=dojo.widget.html.stabile.getState(this.widgetId);
if(s){
this.setState(s);
}
}});
dojo.provide("dojo.widget.ContentPane");
dojo.widget.defineWidget("dojo.widget.ContentPane",dojo.widget.HtmlWidget,function(){
this._styleNodes=[];
this._onLoadStack=[];
this._onUnLoadStack=[];
this._callOnUnLoad=false;
this.scriptScope;
this._ioBindObj;
this.bindArgs={};
},{isContainer:true,adjustPaths:true,href:"",extractContent:true,parseContent:true,cacheContent:true,preload:false,refreshOnShow:false,handler:"",executeScripts:false,loadingMessage:"Loading...",postCreate:function(args,frag,_8f6){
if(this.handler!==""){
this.setHandler(this.handler);
}
if(this.isShowing()||this.preload){
this.loadContents();
}
},show:function(){
if(this.refreshOnShow){
this.refresh();
}else{
this.loadContents();
}
dojo.widget.ContentPane.superclass.show.call(this);
},refresh:function(){
this.isLoaded=false;
this.loadContents();
},loadContents:function(){
if(this.isLoaded){
return;
}
if(dojo.lang.isFunction(this.handler)){
this._runHandler();
}else{
if(this.href!=""){
this._downloadExternalContent(this.href,this.cacheContent&&!this.refreshOnShow);
}
}
},setUrl:function(url){
this.href=url;
this.isLoaded=false;
if(this.preload||this.isShowing()){
this.loadContents();
}
},abort:function(){
var bind=this._ioBindObj;
if(!bind||!bind.abort){
return;
}
bind.abort();
delete this._ioBindObj;
},_downloadExternalContent:function(url,_8fa){
this.abort();
this._handleDefaults(this.loadingMessage,"onDownloadStart");
var self=this;
this._ioBindObj=dojo.io.bind(this._cacheSetting({url:url,mimetype:"text/html",handler:function(type,data,xhr){
delete self._ioBindObj;
if(type=="load"){
self.onDownloadEnd.call(self,url,data);
}else{
var e={responseText:xhr.responseText,status:xhr.status,statusText:xhr.statusText,responseHeaders:xhr.getAllResponseHeaders(),_text:"Error loading '"+url+"' ("+xhr.status+" "+xhr.statusText+")"};
self._handleDefaults.call(self,e,"onDownloadError");
self.onLoad();
}
}},_8fa));
},_cacheSetting:function(_900,_901){
for(var x in this.bindArgs){
if(dojo.lang.isUndefined(_900[x])){
_900[x]=this.bindArgs[x];
}
}
if(dojo.lang.isUndefined(_900.useCache)){
_900.useCache=_901;
}
if(dojo.lang.isUndefined(_900.preventCache)){
_900.preventCache=!_901;
}
if(dojo.lang.isUndefined(_900.mimetype)){
_900.mimetype="text/html";
}
return _900;
},onLoad:function(e){
this._runStack("_onLoadStack");
this.isLoaded=true;
},onUnLoad:function(e){
this._runStack("_onUnLoadStack");
delete this.scriptScope;
},_runStack:function(_905){
var st=this[_905];
var err="";
var _908=this.scriptScope||window;
for(var i=0;i<st.length;i++){
try{
st[i].call(_908);
}
catch(e){
err+="\n"+st[i]+" failed: "+e.description;
}
}
this[_905]=[];
if(err.length){
var name=(_905=="_onLoadStack")?"addOnLoad":"addOnUnLoad";
this._handleDefaults(name+" failure\n "+err,"onExecError",true);
}
},addOnLoad:function(obj,func){
this._pushOnStack(this._onLoadStack,obj,func);
},addOnUnLoad:function(obj,func){
this._pushOnStack(this._onUnLoadStack,obj,func);
},_pushOnStack:function(_90f,obj,func){
if(typeof func=="undefined"){
_90f.push(obj);
}else{
_90f.push(function(){
obj[func]();
});
}
},destroy:function(){
this.onUnLoad();
dojo.widget.ContentPane.superclass.destroy.call(this);
},onExecError:function(e){
},onContentError:function(e){
},onDownloadError:function(e){
},onDownloadStart:function(e){
},onDownloadEnd:function(url,data){
data=this.splitAndFixPaths(data,url);
this.setContent(data);
},_handleDefaults:function(e,_919,_91a){
if(!_919){
_919="onContentError";
}
if(dojo.lang.isString(e)){
e={_text:e};
}
if(!e._text){
e._text=e.toString();
}
e.toString=function(){
return this._text;
};
if(typeof e.returnValue!="boolean"){
e.returnValue=true;
}
if(typeof e.preventDefault!="function"){
e.preventDefault=function(){
this.returnValue=false;
};
}
this[_919](e);
if(e.returnValue){
if(_91a){
alert(e.toString());
}else{
if(this._callOnUnLoad){
this.onUnLoad();
}
this._callOnUnLoad=false;
this._setContent(e.toString());
}
}
},splitAndFixPaths:function(s,url){
var _91d=[],scripts=[],tmp=[];
var _91e=[],requires=[],attr=[],styles=[];
var str="",path="",fix="",tagFix="",tag="",origPath="";
if(!url){
url="./";
}
if(s){
var _920=/<title[^>]*>([\s\S]*?)<\/title>/i;
while(_91e=_920.exec(s)){
_91d.push(_91e[1]);
s=s.substring(0,_91e.index)+s.substr(_91e.index+_91e[0].length);
}
if(this.adjustPaths){
var _921=/<[a-z][a-z0-9]*[^>]*\s(?:(?:src|href|style)=[^>])+[^>]*>/i;
var _922=/\s(src|href|style)=(['"]?)([\w()\[\]\/.,\\'"-:;#=&?\s@]+?)\2/i;
var _923=/^(?:[#]|(?:(?:https?|ftps?|file|javascript|mailto|news):))/;
while(tag=_921.exec(s)){
str+=s.substring(0,tag.index);
s=s.substring((tag.index+tag[0].length),s.length);
tag=tag[0];
tagFix="";
while(attr=_922.exec(tag)){
path="";
origPath=attr[3];
switch(attr[1].toLowerCase()){
case "src":
case "href":
if(_923.exec(origPath)){
path=origPath;
}else{
path=(new dojo.uri.Uri(url,origPath).toString());
}
break;
case "style":
path=dojo.html.fixPathsInCssText(origPath,url);
break;
default:
path=origPath;
}
fix=" "+attr[1]+"="+attr[2]+path+attr[2];
tagFix+=tag.substring(0,attr.index)+fix;
tag=tag.substring((attr.index+attr[0].length),tag.length);
}
str+=tagFix+tag;
}
s=str+s;
}
_920=/(?:<(style)[^>]*>([\s\S]*?)<\/style>|<link ([^>]*rel=['"]?stylesheet['"]?[^>]*)>)/i;
while(_91e=_920.exec(s)){
if(_91e[1]&&_91e[1].toLowerCase()=="style"){
styles.push(dojo.html.fixPathsInCssText(_91e[2],url));
}else{
if(attr=_91e[3].match(/href=(['"]?)([^'">]*)\1/i)){
styles.push({path:attr[2]});
}
}
s=s.substring(0,_91e.index)+s.substr(_91e.index+_91e[0].length);
}
var _920=/<script([^>]*)>([\s\S]*?)<\/script>/i;
var _924=/src=(['"]?)([^"']*)\1/i;
var _925=/.*(\bdojo\b\.js(?:\.uncompressed\.js)?)$/;
var _926=/(?:var )?\bdjConfig\b(?:[\s]*=[\s]*\{[^}]+\}|\.[\w]*[\s]*=[\s]*[^;\n]*)?;?|dojo\.hostenv\.writeIncludes\(\s*\);?/g;
var _927=/dojo\.(?:(?:require(?:After)?(?:If)?)|(?:widget\.(?:manager\.)?registerWidgetPackage)|(?:(?:hostenv\.)?setModulePrefix|registerModulePath)|defineNamespace)\((['"]).*?\1\)\s*;?/;
while(_91e=_920.exec(s)){
if(this.executeScripts&&_91e[1]){
if(attr=_924.exec(_91e[1])){
if(_925.exec(attr[2])){
dojo.debug("Security note! inhibit:"+attr[2]+" from  beeing loaded again.");
}else{
scripts.push({path:attr[2]});
}
}
}
if(_91e[2]){
var sc=_91e[2].replace(_926,"");
if(!sc){
continue;
}
while(tmp=_927.exec(sc)){
requires.push(tmp[0]);
sc=sc.substring(0,tmp.index)+sc.substr(tmp.index+tmp[0].length);
}
if(this.executeScripts){
scripts.push(sc);
}
}
s=s.substr(0,_91e.index)+s.substr(_91e.index+_91e[0].length);
}
if(this.extractContent){
_91e=s.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_91e){
s=_91e[1];
}
}
if(this.executeScripts){
var _920=/(<[a-zA-Z][a-zA-Z0-9]*\s[^>]*\S=(['"])[^>]*[^\.\]])scriptScope([^>]*>)/;
str="";
while(tag=_920.exec(s)){
tmp=((tag[2]=="'")?"\"":"'");
str+=s.substring(0,tag.index);
s=s.substr(tag.index).replace(_920,"$1dojo.widget.byId("+tmp+this.widgetId+tmp+").scriptScope$3");
}
s=str+s;
}
}
return {"xml":s,"styles":styles,"titles":_91d,"requires":requires,"scripts":scripts,"url":url};
},_setContent:function(cont){
this.destroyChildren();
for(var i=0;i<this._styleNodes.length;i++){
if(this._styleNodes[i]&&this._styleNodes[i].parentNode){
this._styleNodes[i].parentNode.removeChild(this._styleNodes[i]);
}
}
this._styleNodes=[];
var node=this.containerNode||this.domNode;
while(node.firstChild){
try{
dojo.event.browser.clean(node.firstChild);
}
catch(e){
}
node.removeChild(node.firstChild);
}
try{
if(typeof cont!="string"){
node.innerHTML="";
node.appendChild(cont);
}else{
node.innerHTML=cont;
}
}
catch(e){
e._text="Could'nt load content:"+e.description;
this._handleDefaults(e,"onContentError");
}
},setContent:function(data){
this.abort();
if(this._callOnUnLoad){
this.onUnLoad();
}
this._callOnUnLoad=true;
if(!data||dojo.html.isNode(data)){
this._setContent(data);
this.onResized();
this.onLoad();
}else{
if(typeof data.xml!="string"){
this.href="";
data=this.splitAndFixPaths(data);
}
this._setContent(data.xml);
for(var i=0;i<data.styles.length;i++){
if(data.styles[i].path){
this._styleNodes.push(dojo.html.insertCssFile(data.styles[i].path));
}else{
this._styleNodes.push(dojo.html.insertCssText(data.styles[i]));
}
}
if(this.parseContent){
for(var i=0;i<data.requires.length;i++){
try{
eval(data.requires[i]);
}
catch(e){
e._text="ContentPane: error in package loading calls, "+(e.description||e);
this._handleDefaults(e,"onContentError",true);
}
}
}
var _92e=this;
function asyncParse(){
if(_92e.executeScripts){
_92e._executeScripts(data.scripts);
}
if(_92e.parseContent){
var node=_92e.containerNode||_92e.domNode;
var _930=new dojo.xml.Parse();
var frag=_930.parseElement(node,null,true);
dojo.widget.getParser().createSubComponents(frag,_92e);
}
_92e.onResized();
_92e.onLoad();
}
if(dojo.hostenv.isXDomain&&data.requires.length){
dojo.addOnLoad(asyncParse);
}else{
asyncParse();
}
}
},setHandler:function(_932){
var fcn=dojo.lang.isFunction(_932)?_932:window[_932];
if(!dojo.lang.isFunction(fcn)){
this._handleDefaults("Unable to set handler, '"+_932+"' not a function.","onExecError",true);
return;
}
this.handler=function(){
return fcn.apply(this,arguments);
};
},_runHandler:function(){
var ret=true;
if(dojo.lang.isFunction(this.handler)){
this.handler(this,this.domNode);
ret=false;
}
this.onLoad();
return ret;
},_executeScripts:function(_935){
var self=this;
var tmp="",code="";
for(var i=0;i<_935.length;i++){
if(_935[i].path){
dojo.io.bind(this._cacheSetting({"url":_935[i].path,"load":function(type,_93a){
dojo.lang.hitch(self,tmp=_93a);
},"error":function(type,_93c){
_93c._text=type+" downloading remote script";
self._handleDefaults.call(self,_93c,"onExecError",true);
},"mimetype":"text/plain","sync":true},this.cacheContent));
code+=tmp;
}else{
code+=_935[i];
}
}
try{
delete this.scriptScope;
this.scriptScope=new (new Function("_container_",code+"; return this;"))(self);
}
catch(e){
e._text="Error running scripts from content:\n"+e.description;
this._handleDefaults(e,"onExecError",true);
}
}});
dojo.provide("dojo.widget.SplitContainer");
dojo.provide("dojo.widget.SplitContainerPanel");
dojo.widget.defineWidget("dojo.widget.SplitContainer",dojo.widget.HtmlWidget,function(){
this.sizers=[];
},{isContainer:true,virtualSizer:null,isHorizontal:null,paneBefore:null,paneAfter:null,isSizing:false,dragOffset:0,startPoint:0,lastPoint:0,sizingSplitter:null,screenToClientOffset:0,isDraggingLeft:0,templateCssString:".dojoSplitContainer{\n	position: relative;\n	overflow: hidden;\n}\n\n.dojoSplitPane{\n	position: absolute;\n}\n\n.dojoSplitContainerSizerH,\n.dojoSplitContainerSizerV {\n	font-size: 1px;\n	cursor: move;\n	cursor: w-resize;\n	background-color: ThreeDFace;\n	border: 1px solid;\n	border-color: ThreeDHighlight ThreeDShadow ThreeDShadow ThreeDHighlight;\n	margin: 0;\n}\n\n.dojoSplitContainerSizerV {\n	cursor: n-resize;\n}\n\n.dojoSplitContainerVirtualSizerH,\n.dojoSplitContainerVirtualSizerV {\n	font-size: 1px;\n	cursor: move;\n	cursor: w-resize;\n	background-color: ThreeDShadow;\n	-moz-opacity: 0.5;\n	opacity: 0.5;\n	filter: Alpha(Opacity=50);\n	margin: 0;\n}\n\n.dojoSplitContainerVirtualSizerV {\n	cursor: n-resize;\n}\n",templateCssPath:dojo.uri.dojoUri("src/widget/templates/SplitContainer.css"),originPos:0,activeSizing:false,sizerWidth:15,orientation:"horizontal",persist:true,debugName:"",fillInTemplate:function(){
dojo.html.insertCssFile(this.templateCssPath,null,true);
dojo.html.addClass(this.domNode,"dojoSplitContainer");
var _93d=(dojo.render.html.moz&&!window.XML);
if(_93d){
this.domNode.style.overflow="-moz-scrollbars-none";
}
var _93e=dojo.html.getContentBox(this.domNode);
this.paneWidth=_93e.width;
this.paneHeight=_93e.height;
this.isHorizontal=(this.orientation=="horizontal");
},onResized:function(e){
var _940=dojo.html.getContentBox(this.domNode);
this.paneWidth=_940.width;
this.paneHeight=_940.height;
this.layoutPanels();
},postCreate:function(args,_942,_943){
for(var i=0;i<this.children.length;i++){
with(this.children[i].domNode.style){
position="absolute";
}
dojo.html.addClass(this.children[i].domNode,"dojoSplitPane");
if(i==this.children.length-1){
break;
}
this._addSizer();
}
if(typeof this.sizerWidth=="object"){
try{
this.sizerWidth=parseInt(this.sizerWidth.toString());
}
catch(e){
this.sizerWidth=15;
}
}
this.virtualSizer=document.createElement("div");
this.virtualSizer.style.position="absolute";
this.virtualSizer.style.display="none";
this.virtualSizer.style.zIndex=10;
this.virtualSizer.className=this.isHorizontal?"dojoSplitContainerVirtualSizerH":"dojoSplitContainerVirtualSizerV";
this.domNode.appendChild(this.virtualSizer);
dojo.html.disableSelection(this.virtualSizer);
if(this.persist){
this.restoreState();
}
this.resizeSoon();
},_injectChild:function(_945){
with(_945.domNode.style){
position="absolute";
}
dojo.html.addClass(_945.domNode,"dojoSplitPane");
},_addSizer:function(){
var i=this.sizers.length;
this.sizers[i]=document.createElement("div");
this.sizers[i].style.position="absolute";
this.sizers[i].className=this.isHorizontal?"dojoSplitContainerSizerH":"dojoSplitContainerSizerV";
var self=this;
var _948=(function(){
var _949=i;
return function(e){
self.beginSizing(e,_949);
};
})();
dojo.event.connect(this.sizers[i],"onmousedown",_948);
this.domNode.appendChild(this.sizers[i]);
dojo.html.disableSelection(this.sizers[i]);
},removeChild:function(_94b){
if(this.sizers.length>0){
for(var x=0;x<this.children.length;x++){
if(this.children[x]===_94b){
var i=this.sizers.length-1;
this.domNode.removeChild(this.sizers[i]);
this.sizers.length=i;
break;
}
}
}
dojo.widget.SplitContainer.superclass.removeChild.call(this,_94b,arguments);
this.onResized();
},addChild:function(_94e,_94f,pos,ref,_952){
dojo.widget.SplitContainer.superclass.addChild.call(this,_94e,_94f,pos,ref,_952);
this._injectChild(_94e);
if(this.children.length>1){
this._addSizer();
}
this.layoutPanels();
},layoutPanels:function(){
if(this.children.length==0){
return;
}
var _953=this.isHorizontal?this.paneWidth:this.paneHeight;
if(this.children.length>1){
_953-=this.sizerWidth*(this.children.length-1);
}
var _954=0;
for(var i=0;i<this.children.length;i++){
_954+=this.children[i].sizeShare;
}
var _956=_953/_954;
var _957=0;
for(var i=0;i<this.children.length-1;i++){
var size=Math.round(_956*this.children[i].sizeShare);
this.children[i].sizeActual=size;
_957+=size;
}
this.children[this.children.length-1].sizeActual=_953-_957;
this.checkSizes();
var pos=0;
var size=this.children[0].sizeActual;
this.movePanel(this.children[0].domNode,pos,size);
this.children[0].position=pos;
this.children[0].checkSize();
pos+=size;
for(var i=1;i<this.children.length;i++){
this.movePanel(this.sizers[i-1],pos,this.sizerWidth);
this.sizers[i-1].position=pos;
pos+=this.sizerWidth;
size=this.children[i].sizeActual;
this.movePanel(this.children[i].domNode,pos,size);
this.children[i].position=pos;
this.children[i].checkSize();
pos+=size;
}
},movePanel:function(_95a,pos,size){
if(this.isHorizontal){
_95a.style.left=pos+"px";
_95a.style.top=0;
dojo.html.setMarginBox(_95a,{width:size,height:this.paneHeight});
}else{
_95a.style.left=0;
_95a.style.top=pos+"px";
dojo.html.setMarginBox(_95a,{width:this.paneWidth,height:size});
}
},growPane:function(_95d,pane){
if(_95d>0){
if(pane.sizeActual>pane.sizeMin){
if((pane.sizeActual-pane.sizeMin)>_95d){
pane.sizeActual=pane.sizeActual-_95d;
_95d=0;
}else{
_95d-=pane.sizeActual-pane.sizeMin;
pane.sizeActual=pane.sizeMin;
}
}
}
return _95d;
},checkSizes:function(){
var _95f=0;
var _960=0;
for(var i=0;i<this.children.length;i++){
_960+=this.children[i].sizeActual;
_95f+=this.children[i].sizeMin;
}
if(_95f<=_960){
var _962=0;
for(var i=0;i<this.children.length;i++){
if(this.children[i].sizeActual<this.children[i].sizeMin){
_962+=this.children[i].sizeMin-this.children[i].sizeActual;
this.children[i].sizeActual=this.children[i].sizeMin;
}
}
if(_962>0){
if(this.isDraggingLeft){
for(var i=this.children.length-1;i>=0;i--){
_962=this.growPane(_962,this.children[i]);
}
}else{
for(var i=0;i<this.children.length;i++){
_962=this.growPane(_962,this.children[i]);
}
}
}
}else{
for(var i=0;i<this.children.length;i++){
this.children[i].sizeActual=Math.round(_960*(this.children[i].sizeMin/_95f));
}
}
},beginSizing:function(e,i){
this.paneBefore=this.children[i];
this.paneAfter=this.children[i+1];
this.isSizing=true;
this.sizingSplitter=this.sizers[i];
this.originPos=dojo.html.getAbsolutePosition(this.children[0].domNode,true,dojo.html.boxSizing.MARGIN_BOX);
if(this.isHorizontal){
var _965=(e.layerX?e.layerX:e.offsetX);
var _966=e.pageX;
this.originPos=this.originPos.x;
}else{
var _965=(e.layerY?e.layerY:e.offsetY);
var _966=e.pageY;
this.originPos=this.originPos.y;
}
this.startPoint=this.lastPoint=_966;
this.screenToClientOffset=_966-_965;
this.dragOffset=this.lastPoint-this.paneBefore.sizeActual-this.originPos-this.paneBefore.position;
if(!this.activeSizing){
this.showSizingLine();
}
dojo.event.connect(document.documentElement,"onmousemove",this,"changeSizing");
dojo.event.connect(document.documentElement,"onmouseup",this,"endSizing");
dojo.event.browser.stopEvent(e);
},changeSizing:function(e){
this.lastPoint=this.isHorizontal?e.pageX:e.pageY;
if(this.activeSizing){
this.movePoint();
this.updateSize();
}else{
this.movePoint();
this.moveSizingLine();
}
dojo.event.browser.stopEvent(e);
},endSizing:function(e){
if(!this.activeSizing){
this.hideSizingLine();
}
this.updateSize();
this.isSizing=false;
dojo.event.disconnect(document.documentElement,"onmousemove",this,"changeSizing");
dojo.event.disconnect(document.documentElement,"onmouseup",this,"endSizing");
if(this.persist){
this.saveState(this);
}
},movePoint:function(){
var p=this.lastPoint-this.screenToClientOffset;
var a=p-this.dragOffset;
a=this.legaliseSplitPoint(a);
p=a+this.dragOffset;
this.lastPoint=p+this.screenToClientOffset;
},legaliseSplitPoint:function(a){
a+=this.sizingSplitter.position;
this.isDraggingLeft=(a>0)?1:0;
if(!this.activeSizing){
if(a<this.paneBefore.position+this.paneBefore.sizeMin){
a=this.paneBefore.position+this.paneBefore.sizeMin;
}
if(a>this.paneAfter.position+(this.paneAfter.sizeActual-(this.sizerWidth+this.paneAfter.sizeMin))){
a=this.paneAfter.position+(this.paneAfter.sizeActual-(this.sizerWidth+this.paneAfter.sizeMin));
}
}
a-=this.sizingSplitter.position;
this.checkSizes();
return a;
},updateSize:function(){
var pos=this.lastPoint-this.dragOffset-this.originPos;
var _96d=this.paneBefore.position;
var _96e=this.paneAfter.position+this.paneAfter.sizeActual;
this.paneBefore.sizeActual=pos-_96d;
this.paneAfter.position=pos+this.sizerWidth;
this.paneAfter.sizeActual=_96e-this.paneAfter.position;
for(var i=0;i<this.children.length;i++){
this.children[i].sizeShare=this.children[i].sizeActual;
}
this.layoutPanels();
},showSizingLine:function(){
this.moveSizingLine();
if(this.isHorizontal){
dojo.html.setMarginBox(this.virtualSizer,{width:this.sizerWidth,height:this.paneHeight});
}else{
dojo.html.setMarginBox(this.virtualSizer,{width:this.paneWidth,height:this.sizerWidth});
}
this.virtualSizer.style.display="block";
},hideSizingLine:function(){
this.virtualSizer.style.display="none";
},moveSizingLine:function(){
var pos=this.lastPoint-this.startPoint+this.sizingSplitter.position;
if(this.isHorizontal){
this.virtualSizer.style.left=pos+"px";
}else{
var pos=(this.lastPoint-this.startPoint)+this.sizingSplitter.position;
this.virtualSizer.style.top=pos+"px";
}
},_getCookieName:function(i){
return this.widgetId+"_"+i;
},restoreState:function(){
for(var i=0;i<this.children.length;i++){
var _973=this._getCookieName(i);
var _974=dojo.io.cookie.getCookie(_973);
if(_974!=null){
var pos=parseInt(_974);
if(typeof pos=="number"){
this.children[i].sizeShare=pos;
}
}
}
},saveState:function(){
for(var i=0;i<this.children.length;i++){
var _977=this._getCookieName(i);
dojo.io.cookie.setCookie(_977,this.children[i].sizeShare,null,null,null,null);
}
}});
dojo.lang.extend(dojo.widget.Widget,{sizeMin:10,sizeShare:10});
dojo.widget.defineWidget("dojo.widget.SplitContainerPanel",dojo.widget.ContentPane,{});
dojo.provide("dojo.widget.html.layout");
dojo.widget.html.layout=function(_978,_979,_97a){
dojo.html.addClass(_978,"dojoLayoutContainer");
_979=dojo.lang.filter(_979,function(_97b,idx){
_97b.idx=idx;
return dojo.lang.inArray(["top","bottom","left","right","client","flood"],_97b.layoutAlign);
});
if(_97a&&_97a!="none"){
var rank=function(_97e){
switch(_97e.layoutAlign){
case "flood":
return 1;
case "left":
case "right":
return (_97a=="left-right")?2:3;
case "top":
case "bottom":
return (_97a=="left-right")?3:2;
default:
return 4;
}
};
_979.sort(function(a,b){
return (rank(a)-rank(b))||(a.idx-b.idx);
});
}
var f={top:dojo.html.getPixelValue(_978,"padding-top",true),left:dojo.html.getPixelValue(_978,"padding-left",true)};
dojo.lang.mixin(f,dojo.html.getContentBox(_978));
dojo.lang.forEach(_979,function(_982){
var elm=_982.domNode;
var pos=_982.layoutAlign;
with(elm.style){
left=f.left+"px";
top=f.top+"px";
bottom="auto";
right="auto";
}
dojo.html.addClass(elm,"dojoAlign"+dojo.string.capitalize(pos));
if((pos=="top")||(pos=="bottom")){
dojo.html.setMarginBox(elm,{width:f.width});
var h=dojo.html.getMarginBox(elm).height;
f.height-=h;
if(pos=="top"){
f.top+=h;
}else{
elm.style.top=f.top+f.height+"px";
}
}else{
if(pos=="left"||pos=="right"){
dojo.html.setMarginBox(elm,{height:f.height});
var w=dojo.html.getMarginBox(elm).width;
f.width-=w;
if(pos=="left"){
f.left+=w;
}else{
elm.style.left=f.left+f.width+"px";
}
}else{
if(pos=="flood"||pos=="client"){
dojo.html.setMarginBox(elm,{width:f.width,height:f.height});
}
}
}
if(_982.onResized){
_982.onResized();
}
});
};
dojo.html.insertCssText(".dojoLayoutContainer{ position: relative; display: block; }\n"+"body .dojoAlignTop, body .dojoAlignBottom, body .dojoAlignLeft, body .dojoAlignRight { position: absolute; overflow: hidden; }\n"+"body .dojoAlignClient { position: absolute }\n"+".dojoAlignClient { overflow: auto; }\n");
dojo.provide("dojo.widget.TabContainer");
dojo.widget.defineWidget("dojo.widget.TabContainer",dojo.widget.HtmlWidget,{isContainer:true,labelPosition:"top",closeButton:"none",useVisibility:false,doLayout:true,templateString:"<div id=\"${this.widgetId}\" class=\"dojoTabContainer\" >\n	<div dojoAttachPoint=\"dojoTabLabels\" waiRole=\"tablist\"></div>\n	<div class=\"dojoTabPaneWrapper\" dojoAttachPoint=\"containerNode\" dojoAttachEvent=\"keyDown\" waiRole=\"tabpanel\"></div>\n</div>\n",templateCssString:".dojoTabContainer {\n	position : relative;\n}\n\n.dojoTabPaneWrapper {\n	position : relative;\n	border : 1px solid #6290d2;\n	clear: both;\n	_zoom: 1; /* force IE6 layout mode so top border doesnt disappear */\n}\n\n.dojoTabLabels-top {\n	position : absolute;\n	top : 0px;\n	left : 0px;\n	overflow : visible;\n	margin-bottom : -1px;\n	width : 100%;\n	z-index: 2;	/* so the bottom of the tab label will cover up the border of dojoTabPaneWrapper */\n}\n\n.dojoTabNoLayout.dojoTabLabels-top {\n	position : relative;\n}\n\n.dojoTabNoLayout.dojoTabLabels-top .dojoTabPaneTab {\n	margin-bottom: -1px;\n	_margin-bottom: 0px; /* IE filter so top border lines up correctly */\n}\n\n.dojoTabPaneTab {\n	position : relative;\n	float : left;\n	padding-left : 9px;\n	border-bottom : 1px solid #6290d2;\n	background : url(images/tab_left.gif) no-repeat left top;\n	cursor: pointer;\n	white-space: nowrap;\n	z-index: 3;\n}\n\n.dojoTabPaneTab div {\n	display : block;\n	padding : 4px 15px 4px 6px;\n	background : url(images/tab_top_right.gif) no-repeat right top;\n	color : #333;\n	font-size : 90%;\n}\n\n.dojoTabPanePaneClose {\n	position : absolute;\n	bottom : 0px;\n	right : 6px;\n	height : 12px;\n	width : 12px;\n	font-size : small;\n}\n.dojoTabPanePaneCloseImage {\n	background : url(images/tab_close.gif) no-repeat right top;\n}\n\n.dojoTabPanePaneCloseHover {\n	background-image : url(images/tab_close_h.gif);\n}\n\n.dojoTabPaneTabClose {\n	display : inline-block;\n	height : 12px;\n	width : 12px;\n	padding : 0 12px 0 0;\n	margin : 0 -10px 0 10px;\n	cursor : default;\n	font-size: small;\n}\n\n.dojoTabPaneTabCloseImage {\n	background : url(images/tab_close.gif) no-repeat right top;\n}\n\n.dojoTabPaneTabCloseHover {\n	background-image : url(images/tab_close_h.gif);\n}\n\n.dojoTabPaneTab.current {\n	padding-bottom : 1px;\n	border-bottom : 0;\n	background-position : 0 -150px;\n}\n\n.dojoTabPaneTab.current div {\n	padding-bottom : 5px;\n	margin-bottom : -1px;\n	background-position : 100% -150px;\n}\n\n/* bottom tabs */\n\n.dojoTabLabels-bottom {\n	position : absolute;\n	bottom : 0px;\n	left : 0px;\n	overflow : visible;\n	margin-top : -1px;\n	width : 100%;\n	z-index: 2;\n}\n\n.dojoTabNoLayout.dojoTabLabels-bottom {\n	position : relative;\n}\n\n.dojoTabLabels-bottom .dojoTabPaneTab {\n	border-top :  1px solid #6290d2;\n	border-bottom : 0;\n	background : url(images/tab_bot_left.gif) no-repeat left bottom;\n}\n\n.dojoTabLabels-bottom .dojoTabPaneTab div {\n	background : url(images/tab_bot_right.gif) no-repeat right bottom;\n}\n\n.dojoTabLabels-bottom .dojoTabPaneTab.current {\n	border-top : 0;\n	background : url(images/tab_bot_left_curr.gif) no-repeat left bottom;\n}\n\n.dojoTabLabels-bottom .dojoTabPaneTab.current div {\n	padding-top : 4px;\n	background : url(images/tab_bot_right_curr.gif) no-repeat right bottom;\n}\n\n/* right-h tabs */\n\n.dojoTabLabels-right-h {\n	position : absolute;\n	top : 0px;\n	right : 0px;\n	overflow : visible;\n	margin-left : -1px;\n	z-index: 2;\n}\n\n.dojoTabLabels-right-h .dojoTabPaneTab {\n	padding-left : 0;\n	border-left :  1px solid #6290d2;\n	border-bottom : 0;\n	background : url(images/tab_bot_right.gif) no-repeat right bottom;\n	float : none;\n}\n\n.dojoTabLabels-right-h .dojoTabPaneTab div {\n	padding : 4px 15px 4px 15px;\n}\n\n.dojoTabLabels-right-h .dojoTabPaneTab.current {\n	border-left :  0;\n	border-bottom :  1px solid #6290d2;\n}\n\n/* left-h tabs */\n\n.dojoTabLabels-left-h {\n	position : absolute;\n	top : 0px;\n	left : 0px;\n	overflow : visible;\n	margin-right : -1px;\n	z-index: 2;\n}\n\n.dojoTabLabels-left-h .dojoTabPaneTab {\n	border-right :  1px solid #6290d2;\n	border-bottom : 0;\n	float : none;\n	background : url(images/tab_top_left.gif) no-repeat left top;\n}\n\n.dojoTabLabels-left-h .dojoTabPaneTab.current {\n	border-right : 0;\n	border-bottom :  1px solid #6290d2;\n	padding-bottom : 0;\n	background : url(images/tab_top_left.gif) no-repeat 0 -150px;\n}\n\n.dojoTabLabels-left-h .dojoTabPaneTab div {\n	background : 0;\n	border-bottom :  1px solid #6290d2;\n}\n",templateCssPath:dojo.uri.dojoUri("src/widget/templates/TabContainer.css"),selectedTab:"",fillInTemplate:function(args,frag){
var _989=this.getFragNodeRef(frag);
dojo.html.copyStyle(this.domNode,_989);
dojo.widget.TabContainer.superclass.fillInTemplate.call(this,args,frag);
},postCreate:function(args,frag){
for(var i=0;i<this.children.length;i++){
this._setupTab(this.children[i]);
}
if(this.closeButton=="pane"){
var img=this._setupCloseButton("pane");
this.dojoTabLabels.appendChild(img);
dojo.event.connect(img,"onclick",dojo.lang.hitch(this,function(){
this._runOnCloseTab(this.selectedTabWidget);
}));
}
if(!this.doLayout){
dojo.html.addClass(this.dojoTabLabels,"dojoTabNoLayout");
if(this.labelPosition=="bottom"){
var p=this.dojoTabLabels.parentNode;
p.removeChild(this.dojoTabLabels);
p.appendChild(this.dojoTabLabels);
}
}
dojo.html.addClass(this.dojoTabLabels,"dojoTabLabels-"+this.labelPosition);
this._doSizing();
if(this.selectedTabWidget){
this.selectTab(this.selectedTabWidget,true);
}
},addChild:function(_98f,_990,pos,ref,_993){
this._setupTab(_98f);
dojo.widget.TabContainer.superclass.addChild.call(this,_98f,_990,pos,ref,_993);
this._doSizing();
},_setupTab:function(tab){
tab.domNode.style.display="none";
tab.div=document.createElement("div");
dojo.html.addClass(tab.div,"dojoTabPaneTab");
var _995=document.createElement("div");
var _996=document.createElement("span");
_996.innerHTML=tab.label;
_996.tabIndex="-1";
dojo.widget.wai.setAttr(_996,"waiRole","role","tab");
_995.appendChild(_996);
dojo.html.disableSelection(_996);
if(this.closeButton=="tab"||tab.tabCloseButton){
var _997=this._setupCloseButton("tab");
_995.appendChild(_997);
dojo.event.connect(_997,"onclick",dojo.lang.hitch(this,function(evt){
this._runOnCloseTab(tab);
dojo.event.browser.stopEvent(evt);
}));
}
tab.div.appendChild(_995);
tab.div.tabTitle=_996;
this.dojoTabLabels.appendChild(tab.div);
dojo.event.connect(tab.div,"onclick",dojo.lang.hitch(this,function(){
this.selectTab(tab);
}));
dojo.event.connect(tab.div,"onkeydown",dojo.lang.hitch(this,function(evt){
this.tabNavigation(evt,tab);
}));
if(!this.selectedTabWidget||this.selectedTab==tab.widgetId||tab.selected||(this.children.length==0)){
if(this.selectedTabWidget){
this._hideTab(this.selectedTabWidget);
}
this.selectedTabWidget=tab;
this._showTab(tab);
}else{
this._hideTab(tab);
}
dojo.html.addClass(tab.domNode,"dojoTabPane");
if(this.doLayout){
with(tab.domNode.style){
top=dojo.html.getPixelValue(this.containerNode,"padding-top",true);
left=dojo.html.getPixelValue(this.containerNode,"padding-left",true);
}
}
},_doSizing:function(){
if(!this.doLayout){
return;
}
var _99a=this.labelPosition.replace(/-h/,"");
var _99b=[{domNode:this.dojoTabLabels,layoutAlign:_99a},{domNode:this.containerNode,layoutAlign:"client"}];
dojo.widget.html.layout(this.domNode,_99b);
var _99c=dojo.html.getContentBox(this.containerNode);
dojo.lang.forEach(this.children,function(_99d){
if(_99d.selected){
_99d.resizeTo(_99c.width,_99c.height);
}
});
},removeChild:function(tab){
dojo.event.disconnect(tab.div,"onclick",function(){
});
if(this.closeButton=="tab"){
var img=tab.div.lastChild.lastChild;
if(img){
dojo.html.removeClass(img,"dojoTabPaneTabClose");
}
}
dojo.widget.TabContainer.superclass.removeChild.call(this,tab);
dojo.html.removeClass(tab.domNode,"dojoTabPane");
this.dojoTabLabels.removeChild(tab.div);
delete (tab.div);
if(this.selectedTabWidget===tab){
this.selectedTabWidget=undefined;
if(this.children.length>0){
this.selectTab(this.children[0],true);
}
}
this._doSizing();
},selectTab:function(tab,_9a1){
if(this.selectedTabWidget){
this._hideTab(this.selectedTabWidget);
}
this.selectedTabWidget=tab;
this._showTab(tab,_9a1);
},_setupCloseButton:function(type){
var _9a3="";
var _9a4="div";
if(type=="pane"){
_9a3="dojoTabPanePane";
}else{
if(type=="tab"){
_9a4="span";
_9a3="dojoTabPaneTab";
}
}
var div=document.createElement(_9a4);
dojo.html.addClass(div,_9a3+"Close "+_9a3+"CloseImage");
dojo.event.connect(div,"onmouseover",function(){
dojo.html.addClass(div,_9a3+"CloseHover");
});
dojo.event.connect(div,"onmouseout",function(){
dojo.html.removeClass(div,_9a3+"CloseHover");
});
return div;
},tabNavigation:function(evt,tab){
if((evt.keyCode==evt.KEY_RIGHT_ARROW)||(evt.keyCode==evt.KEY_LEFT_ARROW)){
var _9a8=null;
var next=null;
for(var i=0;i<this.children.length;i++){
if(this.children[i]==tab){
_9a8=i;
break;
}
}
if(evt.keyCode==evt.KEY_RIGHT_ARROW){
next=this.children[(_9a8+1)%this.children.length];
}else{
next=this.children[(_9a8+(this.children.length-1))%this.children.length];
}
this.selectTab(next);
dojo.event.browser.stopEvent(evt);
next.div.tabTitle.focus();
}
},keyDown:function(e){
if(e.keyCode==e.KEY_UP_ARROW&&e.ctrlKey){
this.selectTab(this.selectedTabWidget);
dojo.event.browser.stopEvent(e);
this.selectedTabWidget.div.tabTitle.focus();
}else{
if(e.keyCode==e.KEY_DELETE&&e.altKey){
if(this.closeButton=="tab"||this.closeButton=="pane"||this.selectedTabWidget.tabCloseButton){
this._runOnCloseTab(this.selectedTabWidget);
dojo.event.browser.stopEvent(e);
}
}
}
},_showTab:function(tab,_9ad){
dojo.html.addClass(tab.div,"current");
tab.selected=true;
tab.div.tabTitle.setAttribute("tabIndex","0");
if(this.useVisibility&&!dojo.render.html.ie){
tab.domNode.style.visibility="visible";
}else{
if(_9ad&&tab.refreshOnShow){
var tmp=tab.refreshOnShow;
tab.refreshOnShow=false;
tab.show();
tab.refreshOnShow=tmp;
}else{
tab.show();
}
if(this.doLayout){
var _9af=dojo.html.getContentBox(this.containerNode);
tab.resizeTo(_9af.width,_9af.height);
}
}
},_hideTab:function(tab){
dojo.html.removeClass(tab.div,"current");
tab.div.tabTitle.setAttribute("tabIndex","-1");
tab.selected=false;
if(this.useVisibility){
tab.domNode.style.visibility="hidden";
}else{
tab.hide();
}
},_runOnCloseTab:function(tab){
var onc=tab.extraArgs.onClose||tab.extraArgs.onclose;
var fcn=dojo.lang.isFunction(onc)?onc:window[onc];
var _9b4=dojo.lang.isFunction(fcn)?fcn(this,tab):true;
if(_9b4){
this.removeChild(tab);
tab.destroy();
}
},onResized:function(){
this._doSizing();
}});
dojo.lang.extend(dojo.widget.Widget,{label:"",selected:false,tabCloseButton:false});
dojo.widget.defineWidget("dojo.widget.a11y.TabContainer",dojo.widget.TabContainer,{templateCssString:".dojoTabContainer {\n	position : relative;\n}\n\n.dojoTabPaneWrapper {\n	position : relative;\n	border : 1px solid #6290d2;\n	clear: both;\n	_zoom: 1; /* force IE6 layout mode so top border doesnt disappear */\n}\n\n.dojoTabLabels-top {\n	position : absolute;\n	top : 0px;\n	left : 0px;\n	overflow : visible;\n	margin-bottom : -1px;\n	width : 100%;\n	z-index: 2;	/* so the bottom of the tab label will cover up the border of dojoTabPaneWrapper */\n}\n\n.dojoTabNoLayout.dojoTabLabels-top {\n	position : relative;\n}\n\n.dojoTabNoLayout.dojoTabLabels-top .dojoTabPaneTab {\n	margin-bottom: -1px;\n	_margin-bottom: 0px; /* IE filter so top border lines up correctly */\n}\n\n.dojoTabPaneTab {\n	position : relative;\n	float : left;\n	padding-left : 9px;\n	border-bottom : 1px solid #6290d2;\n	cursor: pointer;\n	white-space: nowrap;\n	z-index: 3;\n}\n\n.dojoTabPaneTab div {\n	display : block;\n	padding : 4px 15px 4px 6px;\n	color : #333;\n	font-size : 90%;\n}\n\n.dojoTabPanePaneClose {\n	position : absolute;\n	bottom : 0px;\n	right : 6px;\n	height : 12px;\n	width : 12px;\n	font-size : small;\n}\n.dojoTabPanePaneCloseImage {\n}\n\n.dojoTabPanePaneCloseHover {\n}\n\n.dojoTabPaneTabClose {\n	display : inline-block;\n	height : 12px;\n	width : 12px;\n	padding : 0 12px 0 0;\n	margin : 0 -10px 0 10px;\n	cursor : default;\n	font-size: small;\n}\n\n.dojoTabPaneTabCloseImage {\n}\n\n.dojoTabPaneTabCloseHover {\n}\n\n.dojoTabPaneTab.current {\n	padding-bottom : 1px;\n	border-bottom : 0;\n	background-position : 0 -150px;\n}\n\n.dojoTabPaneTab.current div {\n	padding-bottom : 5px;\n	margin-bottom : -1px;\n	background-position : 100% -150px;\n}\n\n/* bottom tabs */\n\n.dojoTabLabels-bottom {\n	position : absolute;\n	bottom : 0px;\n	left : 0px;\n	overflow : visible;\n	margin-top : -1px;\n	width : 100%;\n	z-index: 2;\n}\n\n.dojoTabNoLayout.dojoTabLabels-bottom {\n	position : relative;\n}\n\n.dojoTabLabels-bottom .dojoTabPaneTab {\n	border-top :  1px solid #6290d2;\n	border-bottom : 0;\n}\n\n.dojoTabLabels-bottom .dojoTabPaneTab div {\n}\n\n.dojoTabLabels-bottom .dojoTabPaneTab.current {\n	border-top : 0;\n}\n\n.dojoTabLabels-bottom .dojoTabPaneTab.current div {\n	padding-top : 4px;\n}\n\n/* right-h tabs */\n\n.dojoTabLabels-right-h {\n	position : absolute;\n	top : 0px;\n	right : 0px;\n	overflow : visible;\n	margin-left : -1px;\n	z-index: 2;\n}\n\n.dojoTabLabels-right-h .dojoTabPaneTab {\n	padding-left : 0;\n	border-left :  1px solid #6290d2;\n	border-bottom : 0;\n	float : none;\n}\n\n.dojoTabLabels-right-h .dojoTabPaneTab div {\n	padding : 4px 15px 4px 15px;\n}\n\n.dojoTabLabels-right-h .dojoTabPaneTab.current {\n	border-left :  0;\n	border-bottom :  1px solid #6290d2;\n}\n\n/* left-h tabs */\n\n.dojoTabLabels-left-h {\n	position : absolute;\n	top : 0px;\n	left : 0px;\n	overflow : visible;\n	margin-right : -1px;\n	z-index: 2;\n}\n\n.dojoTabLabels-left-h .dojoTabPaneTab {\n	border-right :  1px solid #6290d2;\n	border-bottom : 0;\n	float : none;\n}\n\n.dojoTabLabels-left-h .dojoTabPaneTab.current {\n	border-right : 0;\n	border-bottom :  1px solid #6290d2;\n	padding-bottom : 0;\n}\n\n.dojoTabLabels-left-h .dojoTabPaneTab div {\n	background : 0;\n	border-bottom :  1px solid #6290d2;\n}\n",templateCssPath:dojo.uri.dojoUri("src/widget/templates/TabContainerA11y.css"),imgPath:dojo.uri.dojoUri("src/widget/templates/images/tab_close.gif"),_setupCloseButton:function(type){
var _9b6="";
if(type=="pane"){
_9b6="dojoTabPanePaneClose";
}else{
if(type=="tab"){
_9b6="dojoTabPaneTabClose";
}
}
var img=document.createElement("img");
dojo.html.addClass(img,_9b6);
img.src=this.imgPath;
img.alt="[x]";
return img;
}});
dojo.provide("dojo.widget.LinkPane");
dojo.widget.defineWidget("dojo.widget.LinkPane",dojo.widget.ContentPane,{templateString:"<div class=\"dojoLinkPane\"></div>",fillInTemplate:function(args,frag){
var _9ba=this.getFragNodeRef(frag);
this.label+=_9ba.innerHTML;
var _9ba=this.getFragNodeRef(frag);
dojo.html.copyStyle(this.domNode,_9ba);
}});
dojo.provide("dojo.widget.LayoutContainer");
dojo.widget.defineWidget("dojo.widget.LayoutContainer",dojo.widget.HtmlWidget,{isContainer:true,layoutChildPriority:"top-bottom",postCreate:function(){
dojo.widget.html.layout(this.domNode,this.children,this.layoutChildPriority);
},addChild:function(_9bb,_9bc,pos,ref,_9bf){
dojo.widget.LayoutContainer.superclass.addChild.call(this,_9bb,_9bc,pos,ref,_9bf);
dojo.widget.html.layout(this.domNode,this.children,this.layoutChildPriority);
},removeChild:function(pane){
dojo.widget.LayoutContainer.superclass.removeChild.call(this,pane);
dojo.widget.html.layout(this.domNode,this.children,this.layoutChildPriority);
},onResized:function(){
dojo.widget.html.layout(this.domNode,this.children,this.layoutChildPriority);
},show:function(){
this.domNode.style.display="";
this.checkSize();
this.domNode.style.display="none";
this.domNode.style.visibility="";
dojo.widget.LayoutContainer.superclass.show.call(this);
}});
dojo.lang.extend(dojo.widget.Widget,{layoutAlign:"none"});
dojo.provide("dojo.widget.TreeNode");
dojo.widget.tags.addParseTreeHandler("dojo:TreeNode");
dojo.widget.TreeNode=function(){
dojo.widget.HtmlWidget.call(this);
this.actionsDisabled=[];
};
dojo.inherits(dojo.widget.TreeNode,dojo.widget.HtmlWidget);
dojo.lang.extend(dojo.widget.TreeNode,{widgetType:"TreeNode",loadStates:{UNCHECKED:"UNCHECKED",LOADING:"LOADING",LOADED:"LOADED"},actions:{MOVE:"MOVE",REMOVE:"REMOVE",EDIT:"EDIT",ADDCHILD:"ADDCHILD"},isContainer:true,lockLevel:0,templateString:("<div class=\"dojoTreeNode\"> "+"<span treeNode=\"${this.widgetId}\" class=\"dojoTreeNodeLabel\" dojoAttachPoint=\"labelNode\"> "+"\t\t<span dojoAttachPoint=\"titleNode\" dojoAttachEvent=\"onClick: onTitleClick\" class=\"dojoTreeNodeLabelTitle\">${this.title}</span> "+"</span> "+"<span class=\"dojoTreeNodeAfterLabel\" dojoAttachPoint=\"afterLabelNode\">${this.afterLabel}</span> "+"<div dojoAttachPoint=\"containerNode\" style=\"display:none\"></div> "+"</div>").replace(/(>|<)\s+/g,"$1"),childIconSrc:"",childIconFolderSrc:dojo.uri.dojoUri("src/widget/templates/images/Tree/closed.gif"),childIconDocumentSrc:dojo.uri.dojoUri("src/widget/templates/images/Tree/document.gif"),childIcon:null,isTreeNode:true,objectId:"",afterLabel:"",afterLabelNode:null,expandIcon:null,title:"",object:"",isFolder:false,labelNode:null,titleNode:null,imgs:null,expandLevel:"",tree:null,depth:0,isExpanded:false,state:null,domNodeInitialized:false,isFirstChild:function(){
return this.getParentIndex()==0?true:false;
},isLastChild:function(){
return this.getParentIndex()==this.parent.children.length-1?true:false;
},lock:function(){
return this.tree.lock.apply(this,arguments);
},unlock:function(){
return this.tree.unlock.apply(this,arguments);
},isLocked:function(){
return this.tree.isLocked.apply(this,arguments);
},cleanLock:function(){
return this.tree.cleanLock.apply(this,arguments);
},actionIsDisabled:function(_9c1){
var _9c2=this;
var _9c3=false;
if(this.tree.strictFolders&&_9c1==this.actions.ADDCHILD&&!this.isFolder){
_9c3=true;
}
if(dojo.lang.inArray(_9c2.actionsDisabled,_9c1)){
_9c3=true;
}
if(this.isLocked()){
_9c3=true;
}
return _9c3;
},getInfo:function(){
var info={widgetId:this.widgetId,objectId:this.objectId,index:this.getParentIndex(),isFolder:this.isFolder};
return info;
},initialize:function(args,frag){
this.state=this.loadStates.UNCHECKED;
for(var i=0;i<this.actionsDisabled.length;i++){
this.actionsDisabled[i]=this.actionsDisabled[i].toUpperCase();
}
this.expandLevel=parseInt(this.expandLevel);
},adjustDepth:function(_9c8){
for(var i=0;i<this.children.length;i++){
this.children[i].adjustDepth(_9c8);
}
this.depth+=_9c8;
if(_9c8>0){
for(var i=0;i<_9c8;i++){
var img=this.tree.makeBlankImg();
this.imgs.unshift(img);
dojo.html.insertBefore(this.imgs[0],this.domNode.firstChild);
}
}
if(_9c8<0){
for(var i=0;i<-_9c8;i++){
this.imgs.shift();
dojo.html.removeNode(this.domNode.firstChild);
}
}
},markLoading:function(){
this._markLoadingSavedIcon=this.expandIcon.src;
this.expandIcon.src=this.tree.expandIconSrcLoading;
},unMarkLoading:function(){
if(!this._markLoadingSavedIcon){
return;
}
var im=new Image();
im.src=this.tree.expandIconSrcLoading;
if(this.expandIcon.src==im.src){
this.expandIcon.src=this._markLoadingSavedIcon;
}
this._markLoadingSavedIcon=null;
},setFolder:function(){
dojo.event.connect(this.expandIcon,"onclick",this,"onTreeClick");
this.expandIcon.src=this.isExpanded?this.tree.expandIconSrcMinus:this.tree.expandIconSrcPlus;
this.isFolder=true;
},createDOMNode:function(tree,_9cd){
this.tree=tree;
this.depth=_9cd;
this.imgs=[];
for(var i=0;i<this.depth+1;i++){
var img=this.tree.makeBlankImg();
this.domNode.insertBefore(img,this.labelNode);
this.imgs.push(img);
}
this.expandIcon=this.imgs[this.imgs.length-1];
this.childIcon=this.tree.makeBlankImg();
this.imgs.push(this.childIcon);
dojo.html.insertBefore(this.childIcon,this.titleNode);
if(this.children.length||this.isFolder){
this.setFolder();
}else{
this.state=this.loadStates.LOADED;
}
dojo.event.connect(this.childIcon,"onclick",this,"onIconClick");
for(var i=0;i<this.children.length;i++){
this.children[i].parent=this;
var node=this.children[i].createDOMNode(this.tree,this.depth+1);
this.containerNode.appendChild(node);
}
if(this.children.length){
this.state=this.loadStates.LOADED;
}
this.updateIcons();
this.domNodeInitialized=true;
dojo.event.topic.publish(this.tree.eventNames.createDOMNode,{source:this});
return this.domNode;
},onTreeClick:function(e){
dojo.event.topic.publish(this.tree.eventNames.treeClick,{source:this,event:e});
},onIconClick:function(e){
dojo.event.topic.publish(this.tree.eventNames.iconClick,{source:this,event:e});
},onTitleClick:function(e){
dojo.event.topic.publish(this.tree.eventNames.titleClick,{source:this,event:e});
},markSelected:function(){
dojo.html.addClass(this.titleNode,"dojoTreeNodeLabelSelected");
},unMarkSelected:function(){
dojo.html.removeClass(this.titleNode,"dojoTreeNodeLabelSelected");
},updateExpandIcon:function(){
if(this.isFolder){
this.expandIcon.src=this.isExpanded?this.tree.expandIconSrcMinus:this.tree.expandIconSrcPlus;
}else{
this.expandIcon.src=this.tree.blankIconSrc;
}
},updateExpandGrid:function(){
if(this.tree.showGrid){
if(this.depth){
this.setGridImage(-2,this.isLastChild()?this.tree.gridIconSrcL:this.tree.gridIconSrcT);
}else{
if(this.isFirstChild()){
this.setGridImage(-2,this.isLastChild()?this.tree.gridIconSrcX:this.tree.gridIconSrcY);
}else{
this.setGridImage(-2,this.isLastChild()?this.tree.gridIconSrcL:this.tree.gridIconSrcT);
}
}
}else{
this.setGridImage(-2,this.tree.blankIconSrc);
}
},updateChildGrid:function(){
if((this.depth||this.tree.showRootGrid)&&this.tree.showGrid){
this.setGridImage(-1,(this.children.length&&this.isExpanded)?this.tree.gridIconSrcP:this.tree.gridIconSrcC);
}else{
if(this.tree.showGrid&&!this.tree.showRootGrid){
this.setGridImage(-1,(this.children.length&&this.isExpanded)?this.tree.gridIconSrcZ:this.tree.blankIconSrc);
}else{
this.setGridImage(-1,this.tree.blankIconSrc);
}
}
},updateParentGrid:function(){
var _9d4=this.parent;
for(var i=0;i<this.depth;i++){
var idx=this.imgs.length-(3+i);
var img=(this.tree.showGrid&&!_9d4.isLastChild())?this.tree.gridIconSrcV:this.tree.blankIconSrc;
this.setGridImage(idx,img);
_9d4=_9d4.parent;
}
},updateExpandGridColumn:function(){
if(!this.tree.showGrid){
return;
}
var _9d8=this;
var icon=this.isLastChild()?this.tree.blankIconSrc:this.tree.gridIconSrcV;
dojo.lang.forEach(_9d8.getDescendants(),function(node){
node.setGridImage(_9d8.depth,icon);
});
this.updateExpandGrid();
},updateIcons:function(){
this.imgs[0].style.display=this.tree.showRootGrid?"inline":"none";
this.buildChildIcon();
this.updateExpandGrid();
this.updateChildGrid();
this.updateParentGrid();
dojo.profile.stop("updateIcons");
},buildChildIcon:function(){
if(this.childIconSrc){
this.childIcon.src=this.childIconSrc;
}
this.childIcon.style.display=this.childIconSrc?"inline":"none";
},setGridImage:function(idx,src){
if(idx<0){
idx=this.imgs.length+idx;
}
this.imgs[idx].style.backgroundImage="url("+src+")";
},updateIconTree:function(){
this.tree.updateIconTree.call(this);
},expand:function(){
if(this.isExpanded){
return;
}
if(this.children.length){
this.showChildren();
}
this.isExpanded=true;
this.updateExpandIcon();
dojo.event.topic.publish(this.tree.eventNames.expand,{source:this});
},collapse:function(){
if(!this.isExpanded){
return;
}
this.hideChildren();
this.isExpanded=false;
this.updateExpandIcon();
dojo.event.topic.publish(this.tree.eventNames.collapse,{source:this});
},hideChildren:function(){
this.tree.toggleObj.hide(this.containerNode,this.toggleDuration,this.explodeSrc,dojo.lang.hitch(this,"onHide"));
if(dojo.exists(dojo,"dnd.dragManager.dragObjects")&&dojo.dnd.dragManager.dragObjects.length){
dojo.dnd.dragManager.cacheTargetLocations();
}
},showChildren:function(){
this.tree.toggleObj.show(this.containerNode,this.toggleDuration,this.explodeSrc,dojo.lang.hitch(this,"onShow"));
if(dojo.exists(dojo,"dnd.dragManager.dragObjects")&&dojo.dnd.dragManager.dragObjects.length){
dojo.dnd.dragManager.cacheTargetLocations();
}
},addChild:function(){
return this.tree.addChild.apply(this,arguments);
},doAddChild:function(){
return this.tree.doAddChild.apply(this,arguments);
},edit:function(_9dd){
dojo.lang.mixin(this,_9dd);
if(_9dd.title){
this.titleNode.innerHTML=this.title;
}
if(_9dd.afterLabel){
this.afterLabelNode.innerHTML=this.afterLabel;
}
if(_9dd.childIconSrc){
this.buildChildIcon();
}
},removeNode:function(){
return this.tree.removeNode.apply(this,arguments);
},doRemoveNode:function(){
return this.tree.doRemoveNode.apply(this,arguments);
},toString:function(){
return "["+this.widgetType+" Tree:"+this.tree+" ID:"+this.widgetId+" Title:"+this.title+"]";
}});
dojo.provide("dojo.AdapterRegistry");
dojo.AdapterRegistry=function(_9de){
this.pairs=[];
this.returnWrappers=_9de||false;
};
dojo.lang.extend(dojo.AdapterRegistry,{register:function(name,_9e0,wrap,_9e2,_9e3){
var type=(_9e3)?"unshift":"push";
this.pairs[type]([name,_9e0,wrap,_9e2]);
},match:function(){
for(var i=0;i<this.pairs.length;i++){
var pair=this.pairs[i];
if(pair[1].apply(this,arguments)){
if((pair[3])||(this.returnWrappers)){
return pair[2];
}else{
return pair[2].apply(this,arguments);
}
}
}
throw new Error("No match found");
},unregister:function(name){
for(var i=0;i<this.pairs.length;i++){
var pair=this.pairs[i];
if(pair[0]==name){
this.pairs.splice(i,1);
return true;
}
}
return false;
}});
dojo.provide("dojo.json");
dojo.json={jsonRegistry:new dojo.AdapterRegistry(),register:function(name,_9eb,wrap,_9ed){
dojo.json.jsonRegistry.register(name,_9eb,wrap,_9ed);
},evalJson:function(json){
try{
return eval("("+json+")");
}
catch(e){
dojo.debug(e);
return json;
}
},serialize:function(o){
var _9f0=typeof (o);
if(_9f0=="undefined"){
return "undefined";
}else{
if((_9f0=="number")||(_9f0=="boolean")){
return o+"";
}else{
if(o===null){
return "null";
}
}
}
if(_9f0=="string"){
return dojo.string.escapeString(o);
}
var me=arguments.callee;
var _9f2;
if(typeof (o.__json__)=="function"){
_9f2=o.__json__();
if(o!==_9f2){
return me(_9f2);
}
}
if(typeof (o.json)=="function"){
_9f2=o.json();
if(o!==_9f2){
return me(_9f2);
}
}
if(_9f0!="function"&&typeof (o.length)=="number"){
var res=[];
for(var i=0;i<o.length;i++){
var val=me(o[i]);
if(typeof (val)!="string"){
val="undefined";
}
res.push(val);
}
return "["+res.join(",")+"]";
}
try{
window.o=o;
_9f2=dojo.json.jsonRegistry.match(o);
return me(_9f2);
}
catch(e){
}
if(_9f0=="function"){
return null;
}
res=[];
for(var k in o){
var _9f7;
if(typeof (k)=="number"){
_9f7="\""+k+"\"";
}else{
if(typeof (k)=="string"){
_9f7=dojo.string.escapeString(k);
}else{
continue;
}
}
val=me(o[k]);
if(typeof (val)!="string"){
continue;
}
res.push(_9f7+":"+val);
}
return "{"+res.join(",")+"}";
}};
dojo.provide("dojo.dnd.DragSource");
dojo.provide("dojo.dnd.DropTarget");
dojo.provide("dojo.dnd.DragObject");
dojo.provide("dojo.dnd.DragAndDrop");
dojo.declare("dojo.dnd.DragSource",null,{type:"",onDragEnd:function(){
},onDragStart:function(){
},onSelected:function(){
},unregister:function(){
dojo.dnd.dragManager.unregisterDragSource(this);
},reregister:function(){
dojo.dnd.dragManager.registerDragSource(this);
}},function(){
var dm=dojo.dnd.dragManager;
if(dm["registerDragSource"]){
dm.registerDragSource(this);
}
});
dojo.declare("dojo.dnd.DragObject",null,{type:"",onDragStart:function(){
},onDragMove:function(){
},onDragOver:function(){
},onDragOut:function(){
},onDragEnd:function(){
},onDragLeave:this.onDragOut,onDragEnter:this.onDragOver,ondragout:this.onDragOut,ondragover:this.onDragOver},function(){
var dm=dojo.dnd.dragManager;
if(dm["registerDragObject"]){
dm.registerDragObject(this);
}
});
dojo.declare("dojo.dnd.DropTarget",null,{acceptsType:function(type){
if(!dojo.lang.inArray(this.acceptedTypes,"*")){
if(!dojo.lang.inArray(this.acceptedTypes,type)){
return false;
}
}
return true;
},accepts:function(_9fb){
if(!dojo.lang.inArray(this.acceptedTypes,"*")){
for(var i=0;i<_9fb.length;i++){
if(!dojo.lang.inArray(this.acceptedTypes,_9fb[i].type)){
return false;
}
}
}
return true;
},unregister:function(){
dojo.dnd.dragManager.unregisterDropTarget(this);
},onDragOver:function(){
},onDragOut:function(){
},onDragMove:function(){
},onDropStart:function(){
},onDrop:function(){
},onDropEnd:function(){
}},function(){
if(this.constructor==dojo.dnd.DropTarget){
return;
}
this.acceptedTypes=[];
dojo.dnd.dragManager.registerDropTarget(this);
});
dojo.dnd.DragEvent=function(){
this.dragSource=null;
this.dragObject=null;
this.target=null;
this.eventStatus="success";
};
dojo.declare("dojo.dnd.DragManager",null,{selectedSources:[],dragObjects:[],dragSources:[],registerDragSource:function(){
},dropTargets:[],registerDropTarget:function(){
},lastDragTarget:null,currentDragTarget:null,onKeyDown:function(){
},onMouseOut:function(){
},onMouseMove:function(){
},onMouseUp:function(){
}});
dojo.provide("dojo.dnd.HtmlDragManager");
dojo.declare("dojo.dnd.HtmlDragManager",dojo.dnd.DragManager,{disabled:false,nestedTargets:false,mouseDownTimer:null,dsCounter:0,dsPrefix:"dojoDragSource",dropTargetDimensions:[],currentDropTarget:null,previousDropTarget:null,_dragTriggered:false,selectedSources:[],dragObjects:[],currentX:null,currentY:null,lastX:null,lastY:null,mouseDownX:null,mouseDownY:null,threshold:7,dropAcceptable:false,cancelEvent:function(e){
e.stopPropagation();
e.preventDefault();
},registerDragSource:function(ds){
if(ds["domNode"]){
var dp=this.dsPrefix;
var _a00=dp+"Idx_"+(this.dsCounter++);
ds.dragSourceId=_a00;
this.dragSources[_a00]=ds;
ds.domNode.setAttribute(dp,_a00);
if(dojo.render.html.ie){
dojo.event.browser.addListener(ds.domNode,"ondragstart",this.cancelEvent);
}
}
},unregisterDragSource:function(ds){
if(ds["domNode"]){
var dp=this.dsPrefix;
var _a03=ds.dragSourceId;
delete ds.dragSourceId;
delete this.dragSources[_a03];
ds.domNode.setAttribute(dp,null);
if(dojo.render.html.ie){
dojo.event.browser.removeListener(ds.domNode,"ondragstart",this.cancelEvent);
}
}
},registerDropTarget:function(dt){
this.dropTargets.push(dt);
},unregisterDropTarget:function(dt){
var _a06=dojo.lang.find(this.dropTargets,dt,true);
if(_a06>=0){
this.dropTargets.splice(_a06,1);
}
},getDragSource:function(e){
var tn=e.target;
if(tn===dojo.body()){
return;
}
var ta=dojo.html.getAttribute(tn,this.dsPrefix);
while((!ta)&&(tn)){
tn=tn.parentNode;
if((!tn)||(tn===dojo.body())){
return;
}
ta=dojo.html.getAttribute(tn,this.dsPrefix);
}
return this.dragSources[ta];
},onKeyDown:function(e){
},onMouseDown:function(e){
if(this.disabled){
return;
}
if(dojo.render.html.ie){
if(e.button!=1){
return;
}
}else{
if(e.which!=1){
return;
}
}
var _a0c=e.target.nodeType==dojo.html.TEXT_NODE?e.target.parentNode:e.target;
if(dojo.html.isTag(_a0c,"button","textarea","input","select","option")){
return;
}
var ds=this.getDragSource(e);
if(!ds){
return;
}
if(!dojo.lang.inArray(this.selectedSources,ds)){
this.selectedSources.push(ds);
ds.onSelected();
}
this.mouseDownX=e.pageX;
this.mouseDownY=e.pageY;
e.preventDefault();
dojo.event.connect(document,"onmousemove",this,"onMouseMove");
},onMouseUp:function(e,_a0f){
if(this.selectedSources.length==0){
return;
}
this.mouseDownX=null;
this.mouseDownY=null;
this._dragTriggered=false;
e.dragSource=this.dragSource;
if((!e.shiftKey)&&(!e.ctrlKey)){
if(this.currentDropTarget){
this.currentDropTarget.onDropStart();
}
dojo.lang.forEach(this.dragObjects,function(_a10){
var ret=null;
if(!_a10){
return;
}
if(this.currentDropTarget){
e.dragObject=_a10;
var ce=this.currentDropTarget.domNode.childNodes;
if(ce.length>0){
e.dropTarget=ce[0];
while(e.dropTarget==_a10.domNode){
e.dropTarget=e.dropTarget.nextSibling;
}
}else{
e.dropTarget=this.currentDropTarget.domNode;
}
if(this.dropAcceptable){
ret=this.currentDropTarget.onDrop(e);
}else{
this.currentDropTarget.onDragOut(e);
}
}
e.dragStatus=this.dropAcceptable&&ret?"dropSuccess":"dropFailure";
dojo.lang.delayThese([function(){
try{
_a10.dragSource.onDragEnd(e);
}
catch(err){
var _a13={};
for(var i in e){
if(i=="type"){
_a13.type="mouseup";
continue;
}
_a13[i]=e[i];
}
_a10.dragSource.onDragEnd(_a13);
}
},function(){
_a10.onDragEnd(e);
}]);
},this);
this.selectedSources=[];
this.dragObjects=[];
this.dragSource=null;
if(this.currentDropTarget){
this.currentDropTarget.onDropEnd();
}
}else{
}
dojo.event.disconnect(document,"onmousemove",this,"onMouseMove");
this.currentDropTarget=null;
},onScroll:function(){
for(var i=0;i<this.dragObjects.length;i++){
if(this.dragObjects[i].updateDragOffset){
this.dragObjects[i].updateDragOffset();
}
}
if(this.dragObjects.length){
this.cacheTargetLocations();
}
},_dragStartDistance:function(x,y){
if((!this.mouseDownX)||(!this.mouseDownX)){
return;
}
var dx=Math.abs(x-this.mouseDownX);
var dx2=dx*dx;
var dy=Math.abs(y-this.mouseDownY);
var dy2=dy*dy;
return parseInt(Math.sqrt(dx2+dy2),10);
},cacheTargetLocations:function(){
dojo.profile.start("cacheTargetLocations");
this.dropTargetDimensions=[];
dojo.lang.forEach(this.dropTargets,function(_a1c){
var tn=_a1c.domNode;
if(!tn||dojo.lang.find(_a1c.acceptedTypes,this.dragSource.type)<0){
return;
}
var abs=dojo.html.getAbsolutePosition(tn,true);
var bb=dojo.html.getBorderBox(tn);
this.dropTargetDimensions.push([[abs.x,abs.y],[abs.x+bb.width,abs.y+bb.height],_a1c]);
},this);
dojo.profile.end("cacheTargetLocations");
},onMouseMove:function(e){
if((dojo.render.html.ie)&&(e.button!=1)){
this.currentDropTarget=null;
this.onMouseUp(e,true);
return;
}
if((this.selectedSources.length)&&(!this.dragObjects.length)){
var dx;
var dy;
if(!this._dragTriggered){
this._dragTriggered=(this._dragStartDistance(e.pageX,e.pageY)>this.threshold);
if(!this._dragTriggered){
return;
}
dx=e.pageX-this.mouseDownX;
dy=e.pageY-this.mouseDownY;
}
this.dragSource=this.selectedSources[0];
dojo.lang.forEach(this.selectedSources,function(_a23){
if(!_a23){
return;
}
var tdo=_a23.onDragStart(e);
if(tdo){
tdo.onDragStart(e);
tdo.dragOffset.y+=dy;
tdo.dragOffset.x+=dx;
tdo.dragSource=_a23;
this.dragObjects.push(tdo);
}
},this);
this.previousDropTarget=null;
this.cacheTargetLocations();
}
dojo.lang.forEach(this.dragObjects,function(_a25){
if(_a25){
_a25.onDragMove(e);
}
});
if(this.currentDropTarget){
var c=dojo.html.toCoordinateObject(this.currentDropTarget.domNode,true);
var dtp=[[c.x,c.y],[c.x+c.width,c.y+c.height]];
}
if((!this.nestedTargets)&&(dtp)&&(this.isInsideBox(e,dtp))){
if(this.dropAcceptable){
this.currentDropTarget.onDragMove(e,this.dragObjects);
}
}else{
var _a28=this.findBestTarget(e);
if(_a28.target===null){
if(this.currentDropTarget){
this.currentDropTarget.onDragOut(e);
this.previousDropTarget=this.currentDropTarget;
this.currentDropTarget=null;
}
this.dropAcceptable=false;
return;
}
if(this.currentDropTarget!==_a28.target){
if(this.currentDropTarget){
this.previousDropTarget=this.currentDropTarget;
this.currentDropTarget.onDragOut(e);
}
this.currentDropTarget=_a28.target;
e.dragObjects=this.dragObjects;
this.dropAcceptable=this.currentDropTarget.onDragOver(e);
}else{
if(this.dropAcceptable){
this.currentDropTarget.onDragMove(e,this.dragObjects);
}
}
}
},findBestTarget:function(e){
var _a2a=this;
var _a2b=new Object();
_a2b.target=null;
_a2b.points=null;
dojo.lang.every(this.dropTargetDimensions,function(_a2c){
if(!_a2a.isInsideBox(e,_a2c)){
return true;
}
_a2b.target=_a2c[2];
_a2b.points=_a2c;
return Boolean(_a2a.nestedTargets);
});
return _a2b;
},isInsideBox:function(e,_a2e){
if((e.pageX>_a2e[0][0])&&(e.pageX<_a2e[1][0])&&(e.pageY>_a2e[0][1])&&(e.pageY<_a2e[1][1])){
return true;
}
return false;
},onMouseOver:function(e){
},onMouseOut:function(e){
}});
dojo.dnd.dragManager=new dojo.dnd.HtmlDragManager();
(function(){
var d=document;
var dm=dojo.dnd.dragManager;
dojo.event.connect(d,"onkeydown",dm,"onKeyDown");
dojo.event.connect(d,"onmouseover",dm,"onMouseOver");
dojo.event.connect(d,"onmouseout",dm,"onMouseOut");
dojo.event.connect(d,"onmousedown",dm,"onMouseDown");
dojo.event.connect(d,"onmouseup",dm,"onMouseUp");
dojo.event.connect(window,"onscroll",dm,"onScroll");
})();
dojo.provide("dojo.dnd.HtmlDragAndDrop");
dojo.provide("dojo.dnd.HtmlDragSource");
dojo.provide("dojo.dnd.HtmlDropTarget");
dojo.provide("dojo.dnd.HtmlDragObject");
dojo.declare("dojo.dnd.HtmlDragSource",dojo.dnd.DragSource,{dragClass:"",onDragStart:function(){
var _a33=new dojo.dnd.HtmlDragObject(this.dragObject,this.type);
if(this.dragClass){
_a33.dragClass=this.dragClass;
}
if(this.constrainToContainer){
_a33.constrainTo(this.constrainingContainer||this.domNode.parentNode);
}
return _a33;
},setDragHandle:function(node){
node=dojo.byId(node);
dojo.dnd.dragManager.unregisterDragSource(this);
this.domNode=node;
dojo.dnd.dragManager.registerDragSource(this);
},setDragTarget:function(node){
this.dragObject=node;
},constrainTo:function(_a36){
this.constrainToContainer=true;
if(_a36){
this.constrainingContainer=_a36;
}
},onSelected:function(){
for(var i=0;i<this.dragObjects.length;i++){
dojo.dnd.dragManager.selectedSources.push(new dojo.dnd.HtmlDragSource(this.dragObjects[i]));
}
},addDragObjects:function(el){
for(var i=0;i<arguments.length;i++){
this.dragObjects.push(arguments[i]);
}
}},function(node,type){
node=dojo.byId(node);
this.dragObjects=[];
this.constrainToContainer=false;
if(node){
this.domNode=node;
this.dragObject=node;
dojo.dnd.DragSource.call(this);
this.type=(type)||(this.domNode.nodeName.toLowerCase());
}
});
dojo.declare("dojo.dnd.HtmlDragObject",dojo.dnd.DragObject,{dragClass:"",opacity:0.5,createIframe:true,disableX:false,disableY:false,createDragNode:function(){
var node=this.domNode.cloneNode(true);
if(this.dragClass){
dojo.html.addClass(node,this.dragClass);
}
if(this.opacity<1){
dojo.html.setOpacity(node,this.opacity);
}
if(node.tagName.toLowerCase()=="tr"){
var doc=this.domNode.ownerDocument;
var _a3e=doc.createElement("table");
var _a3f=doc.createElement("tbody");
_a3e.appendChild(_a3f);
_a3f.appendChild(node);
var _a40=this.domNode.childNodes;
var _a41=node.childNodes;
for(var i=0;i<_a40.length;i++){
if((_a41[i])&&(_a41[i].style)){
_a41[i].style.width=dojo.html.getContentBox(_a40[i]).width+"px";
}
}
node=_a3e;
}
if((dojo.render.html.ie55||dojo.render.html.ie60)&&this.createIframe){
with(node.style){
top="0px";
left="0px";
}
var _a43=document.createElement("div");
_a43.appendChild(node);
this.bgIframe=new dojo.html.BackgroundIframe(_a43);
_a43.appendChild(this.bgIframe.iframe);
node=_a43;
}
node.style.zIndex=999;
return node;
},onDragStart:function(e){
dojo.html.clearSelection();
this.scrollOffset=dojo.html.getScroll().offset;
this.dragStartPosition=dojo.html.getAbsolutePosition(this.domNode,true);
this.dragOffset={y:this.dragStartPosition.y-e.pageY,x:this.dragStartPosition.x-e.pageX};
this.dragClone=this.createDragNode();
this.containingBlockPosition=this.domNode.offsetParent?dojo.html.getAbsolutePosition(this.domNode.offsetParent,true):{x:0,y:0};
if(this.constrainToContainer){
this.constraints=this.getConstraints();
}
with(this.dragClone.style){
position="absolute";
top=this.dragOffset.y+e.pageY+"px";
left=this.dragOffset.x+e.pageX+"px";
}
dojo.body().appendChild(this.dragClone);
dojo.event.connect(this.domNode,"onclick",this,"squelchOnClick");
dojo.event.topic.publish("dragStart",{source:this});
},getConstraints:function(){
if(this.constrainingContainer.nodeName.toLowerCase()=="body"){
var _a45=dojo.html.getViewport();
var _a46=_a45.width;
var _a47=_a45.height;
var x=0;
var y=0;
}else{
var _a4a=dojo.html.getContentBox(this.constrainingContainer);
_a46=_a4a.width;
_a47=_a4a.height;
x=this.containingBlockPosition.x+dojo.html.getPixelValue(this.constrainingContainer,"padding-left",true)+dojo.html.getBorderExtent(this.constrainingContainer,"left");
y=this.containingBlockPosition.y+dojo.html.getPixelValue(this.constrainingContainer,"padding-top",true)+dojo.html.getBorderExtent(this.constrainingContainer,"top");
}
var mb=dojo.html.getMarginBox(this.domNode);
return {minX:x,minY:y,maxX:x+_a46-mb.width,maxY:y+_a47-mb.height};
},updateDragOffset:function(){
var _a4c=dojo.html.getScroll().offset;
if(_a4c.y!=this.scrollOffset.y){
var diff=_a4c.y-this.scrollOffset.y;
this.dragOffset.y+=diff;
this.scrollOffset.y=_a4c.y;
}
if(_a4c.x!=this.scrollOffset.x){
var diff=_a4c.x-this.scrollOffset.x;
this.dragOffset.x+=diff;
this.scrollOffset.x=_a4c.x;
}
},onDragMove:function(e){
this.updateDragOffset();
var x=this.dragOffset.x+e.pageX;
var y=this.dragOffset.y+e.pageY;
if(this.constrainToContainer){
if(x<this.constraints.minX){
x=this.constraints.minX;
}
if(y<this.constraints.minY){
y=this.constraints.minY;
}
if(x>this.constraints.maxX){
x=this.constraints.maxX;
}
if(y>this.constraints.maxY){
y=this.constraints.maxY;
}
}
this.setAbsolutePosition(x,y);
dojo.event.topic.publish("dragMove",{source:this});
},setAbsolutePosition:function(x,y){
if(!this.disableY){
this.dragClone.style.top=y+"px";
}
if(!this.disableX){
this.dragClone.style.left=x+"px";
}
},onDragEnd:function(e){
switch(e.dragStatus){
case "dropSuccess":
dojo.html.removeNode(this.dragClone);
this.dragClone=null;
break;
case "dropFailure":
var _a54=dojo.html.getAbsolutePosition(this.dragClone,true);
var _a55={left:this.dragStartPosition.x+1,top:this.dragStartPosition.y+1};
var anim=dojo.lfx.slideTo(this.dragClone,_a55,500,dojo.lfx.easeOut);
var _a57=this;
dojo.event.connect(anim,"onEnd",function(e){
dojo.lang.setTimeout(function(){
dojo.html.removeNode(_a57.dragClone);
_a57.dragClone=null;
},200);
});
anim.play();
break;
}
dojo.event.topic.publish("dragEnd",{source:this});
},squelchOnClick:function(e){
dojo.event.browser.stopEvent(e);
dojo.lang.setTimeout(function(){
dojo.event.disconnect(this.domNode,"onclick",this,"squelchOnClick");
},50);
},constrainTo:function(_a5a){
this.constrainToContainer=true;
if(_a5a){
this.constrainingContainer=_a5a;
}else{
this.constrainingContainer=this.domNode.parentNode;
}
}},function(node,type){
this.domNode=dojo.byId(node);
this.type=type;
this.constrainToContainer=false;
this.dragSource=null;
});
dojo.declare("dojo.dnd.HtmlDropTarget",dojo.dnd.DropTarget,{vertical:false,onDragOver:function(e){
if(!this.accepts(e.dragObjects)){
return false;
}
this.childBoxes=[];
for(var i=0,child;i<this.domNode.childNodes.length;i++){
child=this.domNode.childNodes[i];
if(child.nodeType!=dojo.html.ELEMENT_NODE){
continue;
}
var pos=dojo.html.getAbsolutePosition(child,true);
var _a60=dojo.html.getBorderBox(child);
this.childBoxes.push({top:pos.y,bottom:pos.y+_a60.height,left:pos.x,right:pos.x+_a60.width,height:_a60.height,width:_a60.width,node:child});
}
return true;
},_getNodeUnderMouse:function(e){
for(var i=0,child;i<this.childBoxes.length;i++){
with(this.childBoxes[i]){
if(e.pageX>=left&&e.pageX<=right&&e.pageY>=top&&e.pageY<=bottom){
return i;
}
}
}
return -1;
},createDropIndicator:function(){
this.dropIndicator=document.createElement("div");
with(this.dropIndicator.style){
position="absolute";
zIndex=999;
if(this.vertical){
borderLeftWidth="1px";
borderLeftColor="black";
borderLeftStyle="solid";
height=dojo.html.getBorderBox(this.domNode).height+"px";
top=dojo.html.getAbsolutePosition(this.domNode,true).y+"px";
}else{
borderTopWidth="1px";
borderTopColor="black";
borderTopStyle="solid";
width=dojo.html.getBorderBox(this.domNode).width+"px";
left=dojo.html.getAbsolutePosition(this.domNode,true).x+"px";
}
}
},onDragMove:function(e,_a64){
var i=this._getNodeUnderMouse(e);
if(!this.dropIndicator){
this.createDropIndicator();
}
var _a66=this.vertical?dojo.html.gravity.WEST:dojo.html.gravity.NORTH;
var hide=false;
if(i<0){
if(this.childBoxes.length){
var _a68=(dojo.html.gravity(this.childBoxes[0].node,e)&_a66);
if(_a68){
hide=true;
}
}else{
var _a68=true;
}
}else{
var _a69=this.childBoxes[i];
var _a68=(dojo.html.gravity(_a69.node,e)&_a66);
if(_a69.node===_a64[0].dragSource.domNode){
hide=true;
}else{
var _a6a=_a68?(i>0?this.childBoxes[i-1]:_a69):(i<this.childBoxes.length-1?this.childBoxes[i+1]:_a69);
if(_a6a.node===_a64[0].dragSource.domNode){
hide=true;
}
}
}
if(hide){
this.dropIndicator.style.display="none";
return;
}else{
this.dropIndicator.style.display="";
}
this.placeIndicator(e,_a64,i,_a68);
if(!dojo.html.hasParent(this.dropIndicator)){
dojo.body().appendChild(this.dropIndicator);
}
},placeIndicator:function(e,_a6c,_a6d,_a6e){
var _a6f=this.vertical?"left":"top";
var _a70;
if(_a6d<0){
if(this.childBoxes.length){
_a70=_a6e?this.childBoxes[0]:this.childBoxes[this.childBoxes.length-1];
}else{
this.dropIndicator.style[_a6f]=dojo.html.getAbsolutePosition(this.domNode,true)[this.vertical?"x":"y"]+"px";
}
}else{
_a70=this.childBoxes[_a6d];
}
if(_a70){
this.dropIndicator.style[_a6f]=(_a6e?_a70[_a6f]:_a70[this.vertical?"right":"bottom"])+"px";
if(this.vertical){
this.dropIndicator.style.height=_a70.height+"px";
this.dropIndicator.style.top=_a70.top+"px";
}else{
this.dropIndicator.style.width=_a70.width+"px";
this.dropIndicator.style.left=_a70.left+"px";
}
}
},onDragOut:function(e){
if(this.dropIndicator){
dojo.html.removeNode(this.dropIndicator);
delete this.dropIndicator;
}
},onDrop:function(e){
this.onDragOut(e);
var i=this._getNodeUnderMouse(e);
var _a74=this.vertical?dojo.html.gravity.WEST:dojo.html.gravity.NORTH;
if(i<0){
if(this.childBoxes.length){
if(dojo.html.gravity(this.childBoxes[0].node,e)&_a74){
return this.insert(e,this.childBoxes[0].node,"before");
}else{
return this.insert(e,this.childBoxes[this.childBoxes.length-1].node,"after");
}
}
return this.insert(e,this.domNode,"append");
}
var _a75=this.childBoxes[i];
if(dojo.html.gravity(_a75.node,e)&_a74){
return this.insert(e,_a75.node,"before");
}else{
return this.insert(e,_a75.node,"after");
}
},insert:function(e,_a77,_a78){
var node=e.dragObject.domNode;
if(_a78=="before"){
return dojo.html.insertBefore(node,_a77);
}else{
if(_a78=="after"){
return dojo.html.insertAfter(node,_a77);
}else{
if(_a78=="append"){
_a77.appendChild(node);
return true;
}
}
}
return false;
}},function(node,_a7b){
if(arguments.length==0){
return;
}
this.domNode=dojo.byId(node);
dojo.dnd.DropTarget.call(this);
if(_a7b&&dojo.lang.isString(_a7b)){
_a7b=[_a7b];
}
this.acceptedTypes=_a7b||[];
});
dojo.provide("dojo.dnd.TreeDragAndDrop");
dojo.provide("dojo.dnd.TreeDragSource");
dojo.provide("dojo.dnd.TreeDropTarget");
dojo.provide("dojo.dnd.TreeDNDController");
dojo.dnd.TreeDragSource=function(node,_a7d,type,_a7f){
this.controller=_a7d;
this.treeNode=_a7f;
dojo.dnd.HtmlDragSource.call(this,node,type);
};
dojo.inherits(dojo.dnd.TreeDragSource,dojo.dnd.HtmlDragSource);
dojo.lang.extend(dojo.dnd.TreeDragSource,{onDragStart:function(){
var _a80=dojo.dnd.HtmlDragSource.prototype.onDragStart.call(this);
_a80.treeNode=this.treeNode;
_a80.onDragStart=dojo.lang.hitch(_a80,function(e){
this.savedSelectedNode=this.treeNode.tree.selector.selectedNode;
if(this.savedSelectedNode){
this.savedSelectedNode.unMarkSelected();
}
var _a82=dojo.dnd.HtmlDragObject.prototype.onDragStart.apply(this,arguments);
var _a83=this.dragClone.getElementsByTagName("img");
for(var i=0;i<_a83.length;i++){
_a83.item(i).style.backgroundImage="url()";
}
return _a82;
});
_a80.onDragEnd=function(e){
if(this.savedSelectedNode){
this.savedSelectedNode.markSelected();
}
return dojo.dnd.HtmlDragObject.prototype.onDragEnd.apply(this,arguments);
};
return _a80;
},onDragEnd:function(e){
var res=dojo.dnd.HtmlDragSource.prototype.onDragEnd.call(this,e);
return res;
}});
dojo.dnd.TreeDropTarget=function(_a88,_a89,type,_a8b){
this.treeNode=_a8b;
this.controller=_a89;
dojo.dnd.HtmlDropTarget.apply(this,[_a88,type]);
};
dojo.inherits(dojo.dnd.TreeDropTarget,dojo.dnd.HtmlDropTarget);
dojo.lang.extend(dojo.dnd.TreeDropTarget,{autoExpandDelay:1500,autoExpandTimer:null,position:null,indicatorStyle:"2px black solid",showIndicator:function(_a8c){
if(this.position==_a8c){
return;
}
this.hideIndicator();
this.position=_a8c;
if(_a8c=="before"){
this.treeNode.labelNode.style.borderTop=this.indicatorStyle;
}else{
if(_a8c=="after"){
this.treeNode.labelNode.style.borderBottom=this.indicatorStyle;
}else{
if(_a8c=="onto"){
this.treeNode.markSelected();
}
}
}
},hideIndicator:function(){
this.treeNode.labelNode.style.borderBottom="";
this.treeNode.labelNode.style.borderTop="";
this.treeNode.unMarkSelected();
this.position=null;
},onDragOver:function(e){
var _a8e=dojo.dnd.HtmlDropTarget.prototype.onDragOver.apply(this,arguments);
if(_a8e&&this.treeNode.isFolder&&!this.treeNode.isExpanded){
this.setAutoExpandTimer();
}
return _a8e;
},accepts:function(_a8f){
var _a90=dojo.dnd.HtmlDropTarget.prototype.accepts.apply(this,arguments);
if(!_a90){
return false;
}
var _a91=_a8f[0].treeNode;
if(dojo.lang.isUndefined(_a91)||!_a91||!_a91.isTreeNode){
dojo.raise("Source is not TreeNode or not found");
}
if(_a91===this.treeNode){
return false;
}
return true;
},setAutoExpandTimer:function(){
var _a92=this;
var _a93=function(){
if(dojo.dnd.dragManager.currentDropTarget===_a92){
_a92.controller.expand(_a92.treeNode);
}
};
this.autoExpandTimer=dojo.lang.setTimeout(_a93,_a92.autoExpandDelay);
},getDNDMode:function(){
return this.treeNode.tree.DNDMode;
},getAcceptPosition:function(e,_a95){
var _a96=this.getDNDMode();
if(_a96&dojo.widget.Tree.prototype.DNDModes.ONTO&&!(!this.treeNode.actionIsDisabled(dojo.widget.TreeNode.prototype.actions.ADDCHILD)&&_a95.parent!==this.treeNode&&this.controller.canMove(_a95,this.treeNode))){
_a96&=~dojo.widget.Tree.prototype.DNDModes.ONTO;
}
var _a97=this.getPosition(e,_a96);
if(_a97=="onto"||(!this.isAdjacentNode(_a95,_a97)&&this.controller.canMove(_a95,this.treeNode.parent))){
return _a97;
}else{
return false;
}
},onDragOut:function(e){
this.clearAutoExpandTimer();
this.hideIndicator();
},clearAutoExpandTimer:function(){
if(this.autoExpandTimer){
clearTimeout(this.autoExpandTimer);
this.autoExpandTimer=null;
}
},onDragMove:function(e,_a9a){
var _a9b=_a9a[0].treeNode;
var _a9c=this.getAcceptPosition(e,_a9b);
if(_a9c){
this.showIndicator(_a9c);
}
},isAdjacentNode:function(_a9d,_a9e){
if(_a9d===this.treeNode){
return true;
}
if(_a9d.getNextSibling()===this.treeNode&&_a9e=="before"){
return true;
}
if(_a9d.getPreviousSibling()===this.treeNode&&_a9e=="after"){
return true;
}
return false;
},getPosition:function(e,_aa0){
var node=dojo.byId(this.treeNode.labelNode);
var _aa2=e.pageY||e.clientY+dojo.body().scrollTop;
var _aa3=dojo.html.getAbsolutePosition(node).y;
var _aa4=dojo.html.getBorderBox(node).height;
var relY=_aa2-_aa3;
var p=relY/_aa4;
var _aa7="";
if(_aa0&dojo.widget.Tree.prototype.DNDModes.ONTO&&_aa0&dojo.widget.Tree.prototype.DNDModes.BETWEEN){
if(p<=0.3){
_aa7="before";
}else{
if(p<=0.7){
_aa7="onto";
}else{
_aa7="after";
}
}
}else{
if(_aa0&dojo.widget.Tree.prototype.DNDModes.BETWEEN){
if(p<=0.5){
_aa7="before";
}else{
_aa7="after";
}
}else{
if(_aa0&dojo.widget.Tree.prototype.DNDModes.ONTO){
_aa7="onto";
}
}
}
return _aa7;
},getTargetParentIndex:function(_aa8,_aa9){
var _aaa=_aa9=="before"?this.treeNode.getParentIndex():this.treeNode.getParentIndex()+1;
if(this.treeNode.parent===_aa8.parent&&this.treeNode.getParentIndex()>_aa8.getParentIndex()){
_aaa--;
}
return _aaa;
},onDrop:function(e){
var _aac=this.position;
this.onDragOut(e);
var _aad=e.dragObject.treeNode;
if(!dojo.lang.isObject(_aad)){
dojo.raise("TreeNode not found in dragObject");
}
if(_aac=="onto"){
return this.controller.move(_aad,this.treeNode,0);
}else{
var _aae=this.getTargetParentIndex(_aad,_aac);
return this.controller.move(_aad,this.treeNode.parent,_aae);
}
}});
dojo.dnd.TreeDNDController=function(_aaf){
this.treeController=_aaf;
this.dragSources={};
this.dropTargets={};
};
dojo.lang.extend(dojo.dnd.TreeDNDController,{listenTree:function(tree){
dojo.event.topic.subscribe(tree.eventNames.createDOMNode,this,"onCreateDOMNode");
dojo.event.topic.subscribe(tree.eventNames.moveFrom,this,"onMoveFrom");
dojo.event.topic.subscribe(tree.eventNames.moveTo,this,"onMoveTo");
dojo.event.topic.subscribe(tree.eventNames.addChild,this,"onAddChild");
dojo.event.topic.subscribe(tree.eventNames.removeNode,this,"onRemoveNode");
dojo.event.topic.subscribe(tree.eventNames.treeDestroy,this,"onTreeDestroy");
},unlistenTree:function(tree){
dojo.event.topic.unsubscribe(tree.eventNames.createDOMNode,this,"onCreateDOMNode");
dojo.event.topic.unsubscribe(tree.eventNames.moveFrom,this,"onMoveFrom");
dojo.event.topic.unsubscribe(tree.eventNames.moveTo,this,"onMoveTo");
dojo.event.topic.unsubscribe(tree.eventNames.addChild,this,"onAddChild");
dojo.event.topic.unsubscribe(tree.eventNames.removeNode,this,"onRemoveNode");
dojo.event.topic.unsubscribe(tree.eventNames.treeDestroy,this,"onTreeDestroy");
},onTreeDestroy:function(_ab2){
this.unlistenTree(_ab2.source);
},onCreateDOMNode:function(_ab3){
this.registerDNDNode(_ab3.source);
},onAddChild:function(_ab4){
this.registerDNDNode(_ab4.child);
},onMoveFrom:function(_ab5){
var _ab6=this;
dojo.lang.forEach(_ab5.child.getDescendants(),function(node){
_ab6.unregisterDNDNode(node);
});
},onMoveTo:function(_ab8){
var _ab9=this;
dojo.lang.forEach(_ab8.child.getDescendants(),function(node){
_ab9.registerDNDNode(node);
});
},registerDNDNode:function(node){
if(!node.tree.DNDMode){
return;
}
var _abc=null;
var _abd=null;
if(!node.actionIsDisabled(node.actions.MOVE)){
var _abc=new dojo.dnd.TreeDragSource(node.labelNode,this,node.tree.widgetId,node);
this.dragSources[node.widgetId]=_abc;
}
var _abd=new dojo.dnd.TreeDropTarget(node.labelNode,this.treeController,node.tree.DNDAcceptTypes,node);
this.dropTargets[node.widgetId]=_abd;
},unregisterDNDNode:function(node){
if(this.dragSources[node.widgetId]){
dojo.dnd.dragManager.unregisterDragSource(this.dragSources[node.widgetId]);
delete this.dragSources[node.widgetId];
}
if(this.dropTargets[node.widgetId]){
dojo.dnd.dragManager.unregisterDropTarget(this.dropTargets[node.widgetId]);
delete this.dropTargets[node.widgetId];
}
}});
dojo.provide("dojo.widget.TreeBasicController");
dojo.deprecated("dojo.widget.TreeBasicController","use TreeV3 and TreeBasicControllerV3 instead","0.5");
dojo.widget.tags.addParseTreeHandler("dojo:TreeBasicController");
dojo.widget.TreeBasicController=function(){
dojo.widget.HtmlWidget.call(this);
};
dojo.inherits(dojo.widget.TreeBasicController,dojo.widget.HtmlWidget);
dojo.lang.extend(dojo.widget.TreeBasicController,{widgetType:"TreeBasicController",DNDController:"",dieWithTree:false,initialize:function(args,frag){
if(this.DNDController=="create"){
dojo.require("dojo.dnd.TreeDragAndDrop");
this.DNDController=new dojo.dnd.TreeDNDController(this);
}
},listenTree:function(tree){
dojo.event.topic.subscribe(tree.eventNames.createDOMNode,this,"onCreateDOMNode");
dojo.event.topic.subscribe(tree.eventNames.treeClick,this,"onTreeClick");
dojo.event.topic.subscribe(tree.eventNames.treeCreate,this,"onTreeCreate");
dojo.event.topic.subscribe(tree.eventNames.treeDestroy,this,"onTreeDestroy");
if(this.DNDController){
this.DNDController.listenTree(tree);
}
},unlistenTree:function(tree){
dojo.event.topic.unsubscribe(tree.eventNames.createDOMNode,this,"onCreateDOMNode");
dojo.event.topic.unsubscribe(tree.eventNames.treeClick,this,"onTreeClick");
dojo.event.topic.unsubscribe(tree.eventNames.treeCreate,this,"onTreeCreate");
dojo.event.topic.unsubscribe(tree.eventNames.treeDestroy,this,"onTreeDestroy");
},onTreeDestroy:function(_ac3){
var tree=_ac3.source;
this.unlistenTree(tree);
if(this.dieWithTree){
this.destroy();
}
},onCreateDOMNode:function(_ac5){
var node=_ac5.source;
if(node.expandLevel>0){
this.expandToLevel(node,node.expandLevel);
}
},onTreeCreate:function(_ac7){
var tree=_ac7.source;
var _ac9=this;
if(tree.expandLevel){
dojo.lang.forEach(tree.children,function(_aca){
_ac9.expandToLevel(_aca,tree.expandLevel-1);
});
}
},expandToLevel:function(node,_acc){
if(_acc==0){
return;
}
var _acd=node.children;
var _ace=this;
var _acf=function(node,_ad1){
this.node=node;
this.expandLevel=_ad1;
this.process=function(){
for(var i=0;i<this.node.children.length;i++){
var _ad3=node.children[i];
_ace.expandToLevel(_ad3,this.expandLevel);
}
};
};
var h=new _acf(node,_acc-1);
this.expand(node,false,h,h.process);
},onTreeClick:function(_ad5){
var node=_ad5.source;
if(node.isLocked()){
return false;
}
if(node.isExpanded){
this.collapse(node);
}else{
this.expand(node);
}
},expand:function(node,sync,_ad9,_ada){
node.expand();
if(_ada){
_ada.apply(_ad9,[node]);
}
},collapse:function(node){
node.collapse();
},canMove:function(_adc,_add){
if(_adc.actionIsDisabled(_adc.actions.MOVE)){
return false;
}
if(_adc.parent!==_add&&_add.actionIsDisabled(_add.actions.ADDCHILD)){
return false;
}
var node=_add;
while(node.isTreeNode){
if(node===_adc){
return false;
}
node=node.parent;
}
return true;
},move:function(_adf,_ae0,_ae1){
if(!this.canMove(_adf,_ae0)){
return false;
}
var _ae2=this.doMove(_adf,_ae0,_ae1);
if(!_ae2){
return _ae2;
}
if(_ae0.isTreeNode){
this.expand(_ae0);
}
return _ae2;
},doMove:function(_ae3,_ae4,_ae5){
_ae3.tree.move(_ae3,_ae4,_ae5);
return true;
},canRemoveNode:function(_ae6){
if(_ae6.actionIsDisabled(_ae6.actions.REMOVE)){
return false;
}
return true;
},removeNode:function(node,_ae8,_ae9){
if(!this.canRemoveNode(node)){
return false;
}
return this.doRemoveNode(node,_ae8,_ae9);
},doRemoveNode:function(node,_aeb,_aec){
node.tree.removeNode(node);
if(_aec){
_aec.apply(dojo.lang.isUndefined(_aeb)?this:_aeb,[node]);
}
},canCreateChild:function(_aed,_aee,data){
if(_aed.actionIsDisabled(_aed.actions.ADDCHILD)){
return false;
}
return true;
},createChild:function(_af0,_af1,data,_af3,_af4){
if(!this.canCreateChild(_af0,_af1,data)){
return false;
}
return this.doCreateChild.apply(this,arguments);
},doCreateChild:function(_af5,_af6,data,_af8,_af9){
var _afa=data.widgetType?data.widgetType:"TreeNode";
var _afb=dojo.widget.createWidget(_afa,data);
_af5.addChild(_afb,_af6);
this.expand(_af5);
if(_af9){
_af9.apply(_af8,[_afb]);
}
return _afb;
}});
dojo.provide("dojo.widget.TreeSelector");
dojo.deprecated("dojo.widget.TreeSelector","use TreeV3 and TreeSelectorV3 instead","0.5");
dojo.widget.tags.addParseTreeHandler("dojo:TreeSelector");
dojo.widget.TreeSelector=function(){
dojo.widget.HtmlWidget.call(this);
this.eventNames={};
this.listenedTrees=[];
};
dojo.inherits(dojo.widget.TreeSelector,dojo.widget.HtmlWidget);
dojo.lang.extend(dojo.widget.TreeSelector,{widgetType:"TreeSelector",selectedNode:null,dieWithTree:false,eventNamesDefault:{select:"select",destroy:"destroy",deselect:"deselect",dblselect:"dblselect"},initialize:function(){
for(name in this.eventNamesDefault){
if(dojo.lang.isUndefined(this.eventNames[name])){
this.eventNames[name]=this.widgetId+"/"+this.eventNamesDefault[name];
}
}
},destroy:function(){
dojo.event.topic.publish(this.eventNames.destroy,{source:this});
return dojo.widget.HtmlWidget.prototype.destroy.apply(this,arguments);
},listenTree:function(tree){
dojo.event.topic.subscribe(tree.eventNames.titleClick,this,"select");
dojo.event.topic.subscribe(tree.eventNames.iconClick,this,"select");
dojo.event.topic.subscribe(tree.eventNames.collapse,this,"onCollapse");
dojo.event.topic.subscribe(tree.eventNames.moveFrom,this,"onMoveFrom");
dojo.event.topic.subscribe(tree.eventNames.removeNode,this,"onRemoveNode");
dojo.event.topic.subscribe(tree.eventNames.treeDestroy,this,"onTreeDestroy");
this.listenedTrees.push(tree);
},unlistenTree:function(tree){
dojo.event.topic.unsubscribe(tree.eventNames.titleClick,this,"select");
dojo.event.topic.unsubscribe(tree.eventNames.iconClick,this,"select");
dojo.event.topic.unsubscribe(tree.eventNames.collapse,this,"onCollapse");
dojo.event.topic.unsubscribe(tree.eventNames.moveFrom,this,"onMoveFrom");
dojo.event.topic.unsubscribe(tree.eventNames.removeNode,this,"onRemoveNode");
dojo.event.topic.unsubscribe(tree.eventNames.treeDestroy,this,"onTreeDestroy");
for(var i=0;i<this.listenedTrees.length;i++){
if(this.listenedTrees[i]===tree){
this.listenedTrees.splice(i,1);
break;
}
}
},onTreeDestroy:function(_aff){
this.unlistenTree(_aff.source);
if(this.dieWithTree){
this.destroy();
}
},onCollapse:function(_b00){
if(!this.selectedNode){
return;
}
var node=_b00.source;
var _b02=this.selectedNode.parent;
while(_b02!==node&&_b02.isTreeNode){
_b02=_b02.parent;
}
if(_b02.isTreeNode){
this.deselect();
}
},select:function(_b03){
var node=_b03.source;
var e=_b03.event;
if(this.selectedNode===node){
if(e.ctrlKey||e.shiftKey||e.metaKey){
this.deselect();
return;
}
dojo.event.topic.publish(this.eventNames.dblselect,{node:node});
return;
}
if(this.selectedNode){
this.deselect();
}
this.doSelect(node);
dojo.event.topic.publish(this.eventNames.select,{node:node});
},onMoveFrom:function(_b06){
if(_b06.child!==this.selectedNode){
return;
}
if(!dojo.lang.inArray(this.listenedTrees,_b06.newTree)){
this.deselect();
}
},onRemoveNode:function(_b07){
if(_b07.child!==this.selectedNode){
return;
}
this.deselect();
},doSelect:function(node){
node.markSelected();
this.selectedNode=node;
},deselect:function(){
var node=this.selectedNode;
this.selectedNode=null;
node.unMarkSelected();
dojo.event.topic.publish(this.eventNames.deselect,{node:node});
}});
dojo.provide("dojo.widget.Tree");
dojo.deprecated("dojo.widget.Tree","use TreeV3 instead","0.5");
dojo.widget.tags.addParseTreeHandler("dojo:Tree");
dojo.widget.Tree=function(){
dojo.widget.HtmlWidget.call(this);
this.eventNames={};
this.tree=this;
this.DNDAcceptTypes=[];
this.actionsDisabled=[];
};
dojo.inherits(dojo.widget.Tree,dojo.widget.HtmlWidget);
dojo.lang.extend(dojo.widget.Tree,{widgetType:"Tree",eventNamesDefault:{createDOMNode:"createDOMNode",treeCreate:"treeCreate",treeDestroy:"treeDestroy",treeClick:"treeClick",iconClick:"iconClick",titleClick:"titleClick",moveFrom:"moveFrom",moveTo:"moveTo",addChild:"addChild",removeNode:"removeNode",expand:"expand",collapse:"collapse"},isContainer:true,DNDMode:"off",lockLevel:0,strictFolders:true,DNDModes:{BETWEEN:1,ONTO:2},DNDAcceptTypes:"",templateCssString:"\n.dojoTree {\n	font: caption;\n	font-size: 11px;\n	font-weight: normal;\n	overflow: auto;\n}\n\n\n.dojoTreeNodeLabelTitle {\n	padding-left: 2px;\n	color: WindowText;\n}\n\n.dojoTreeNodeLabel {\n	cursor:hand;\n	cursor:pointer;\n}\n\n.dojoTreeNodeLabelTitle:hover {\n	text-decoration: underline;\n}\n\n.dojoTreeNodeLabelSelected {\n	background-color: Highlight;\n	color: HighlightText;\n}\n\n.dojoTree div {\n	white-space: nowrap;\n}\n\n.dojoTree img, .dojoTreeNodeLabel img {\n	vertical-align: middle;\n}\n\n",templateCssPath:dojo.uri.dojoUri("src/widget/templates/images/Tree/Tree.css"),templateString:"<div class=\"dojoTree\"></div>",isExpanded:true,isTree:true,objectId:"",controller:"",selector:"",menu:"",expandLevel:"",blankIconSrc:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_blank.gif"),gridIconSrcT:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_grid_t.gif"),gridIconSrcL:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_grid_l.gif"),gridIconSrcV:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_grid_v.gif"),gridIconSrcP:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_grid_p.gif"),gridIconSrcC:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_grid_c.gif"),gridIconSrcX:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_grid_x.gif"),gridIconSrcY:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_grid_y.gif"),gridIconSrcZ:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_grid_z.gif"),expandIconSrcPlus:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_expand_plus.gif"),expandIconSrcMinus:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_expand_minus.gif"),expandIconSrcLoading:dojo.uri.dojoUri("src/widget/templates/images/Tree/treenode_loading.gif"),iconWidth:18,iconHeight:18,showGrid:true,showRootGrid:true,actionIsDisabled:function(_b0a){
var _b0b=this;
return dojo.lang.inArray(_b0b.actionsDisabled,_b0a);
},actions:{ADDCHILD:"ADDCHILD"},getInfo:function(){
var info={widgetId:this.widgetId,objectId:this.objectId};
return info;
},initializeController:function(){
if(this.controller!="off"){
if(this.controller){
this.controller=dojo.widget.byId(this.controller);
}else{
dojo.require("dojo.widget.TreeBasicController");
this.controller=dojo.widget.createWidget("TreeBasicController",{DNDController:(this.DNDMode?"create":""),dieWithTree:true});
}
this.controller.listenTree(this);
}else{
this.controller=null;
}
},initializeSelector:function(){
if(this.selector!="off"){
if(this.selector){
this.selector=dojo.widget.byId(this.selector);
}else{
dojo.require("dojo.widget.TreeSelector");
this.selector=dojo.widget.createWidget("TreeSelector",{dieWithTree:true});
}
this.selector.listenTree(this);
}else{
this.selector=null;
}
},initialize:function(args,frag){
var _b0f=this;
for(name in this.eventNamesDefault){
if(dojo.lang.isUndefined(this.eventNames[name])){
this.eventNames[name]=this.widgetId+"/"+this.eventNamesDefault[name];
}
}
for(var i=0;i<this.actionsDisabled.length;i++){
this.actionsDisabled[i]=this.actionsDisabled[i].toUpperCase();
}
if(this.DNDMode=="off"){
this.DNDMode=0;
}else{
if(this.DNDMode=="between"){
this.DNDMode=this.DNDModes.ONTO|this.DNDModes.BETWEEN;
}else{
if(this.DNDMode=="onto"){
this.DNDMode=this.DNDModes.ONTO;
}
}
}
this.expandLevel=parseInt(this.expandLevel);
this.initializeSelector();
this.initializeController();
if(this.menu){
this.menu=dojo.widget.byId(this.menu);
this.menu.listenTree(this);
}
this.containerNode=this.domNode;
},postCreate:function(){
this.createDOMNode();
},createDOMNode:function(){
dojo.html.disableSelection(this.domNode);
for(var i=0;i<this.children.length;i++){
this.children[i].parent=this;
var node=this.children[i].createDOMNode(this,0);
this.domNode.appendChild(node);
}
if(!this.showRootGrid){
for(var i=0;i<this.children.length;i++){
this.children[i].expand();
}
}
dojo.event.topic.publish(this.eventNames.treeCreate,{source:this});
},destroy:function(){
dojo.event.topic.publish(this.tree.eventNames.treeDestroy,{source:this});
return dojo.widget.HtmlWidget.prototype.destroy.apply(this,arguments);
},addChild:function(_b13,_b14){
var _b15={child:_b13,index:_b14,parent:this,domNodeInitialized:_b13.domNodeInitialized};
this.doAddChild.apply(this,arguments);
dojo.event.topic.publish(this.tree.eventNames.addChild,_b15);
},doAddChild:function(_b16,_b17){
if(dojo.lang.isUndefined(_b17)){
_b17=this.children.length;
}
if(!_b16.isTreeNode){
dojo.raise("You can only add TreeNode widgets to a "+this.widgetType+" widget!");
return;
}
if(this.isTreeNode){
if(!this.isFolder){
this.setFolder();
}
}
var _b18=this;
dojo.lang.forEach(_b16.getDescendants(),function(elem){
elem.tree=_b18.tree;
});
_b16.parent=this;
if(this.isTreeNode){
this.state=this.loadStates.LOADED;
}
if(_b17<this.children.length){
dojo.html.insertBefore(_b16.domNode,this.children[_b17].domNode);
}else{
this.containerNode.appendChild(_b16.domNode);
if(this.isExpanded&&this.isTreeNode){
this.showChildren();
}
}
this.children.splice(_b17,0,_b16);
if(_b16.domNodeInitialized){
var d=this.isTreeNode?this.depth:-1;
_b16.adjustDepth(d-_b16.depth+1);
_b16.updateIconTree();
}else{
_b16.depth=this.isTreeNode?this.depth+1:0;
_b16.createDOMNode(_b16.tree,_b16.depth);
}
var _b1b=_b16.getPreviousSibling();
if(_b16.isLastChild()&&_b1b){
_b1b.updateExpandGridColumn();
}
},makeBlankImg:function(){
var img=document.createElement("img");
img.style.width=this.iconWidth+"px";
img.style.height=this.iconHeight+"px";
img.src=this.blankIconSrc;
img.style.verticalAlign="middle";
return img;
},updateIconTree:function(){
if(!this.isTree){
this.updateIcons();
}
for(var i=0;i<this.children.length;i++){
this.children[i].updateIconTree();
}
},toString:function(){
return "["+this.widgetType+" ID:"+this.widgetId+"]";
},move:function(_b1e,_b1f,_b20){
var _b21=_b1e.parent;
var _b22=_b1e.tree;
this.doMove.apply(this,arguments);
var _b1f=_b1e.parent;
var _b23=_b1e.tree;
var _b24={oldParent:_b21,oldTree:_b22,newParent:_b1f,newTree:_b23,child:_b1e};
dojo.event.topic.publish(_b22.eventNames.moveFrom,_b24);
dojo.event.topic.publish(_b23.eventNames.moveTo,_b24);
},doMove:function(_b25,_b26,_b27){
_b25.parent.doRemoveNode(_b25);
_b26.doAddChild(_b25,_b27);
},removeNode:function(_b28){
if(!_b28.parent){
return;
}
var _b29=_b28.tree;
var _b2a=_b28.parent;
var _b2b=this.doRemoveNode.apply(this,arguments);
dojo.event.topic.publish(this.tree.eventNames.removeNode,{child:_b2b,tree:_b29,parent:_b2a});
return _b2b;
},doRemoveNode:function(_b2c){
if(!_b2c.parent){
return;
}
var _b2d=_b2c.parent;
var _b2e=_b2d.children;
var _b2f=_b2c.getParentIndex();
if(_b2f<0){
dojo.raise("Couldn't find node "+_b2c+" for removal");
}
_b2e.splice(_b2f,1);
dojo.html.removeNode(_b2c.domNode);
if(_b2d.children.length==0&&!_b2d.isTree){
_b2d.containerNode.style.display="none";
}
if(_b2f==_b2e.length&&_b2f>0){
_b2e[_b2f-1].updateExpandGridColumn();
}
if(_b2d instanceof dojo.widget.Tree&&_b2f==0&&_b2e.length>0){
_b2e[0].updateExpandGrid();
}
_b2c.parent=_b2c.tree=null;
return _b2c;
},markLoading:function(){
},unMarkLoading:function(){
},lock:function(){
!this.lockLevel&&this.markLoading();
this.lockLevel++;
},unlock:function(){
if(!this.lockLevel){
dojo.raise("unlock: not locked");
}
this.lockLevel--;
!this.lockLevel&&this.unMarkLoading();
},isLocked:function(){
var node=this;
while(true){
if(node.lockLevel){
return true;
}
if(node instanceof dojo.widget.Tree){
break;
}
node=node.parent;
}
return false;
},flushLock:function(){
this.lockLevel=0;
this.unMarkLoading();
}});
dojo.provide("dojo.widget.TreeLoadingController");
dojo.deprecated("dojo.widget.TreeLoadingController","use TreeV3 and TreeLoadingControllerV3 instead","0.5");
dojo.widget.tags.addParseTreeHandler("dojo:TreeLoadingController");
dojo.widget.TreeLoadingController=function(){
dojo.widget.TreeBasicController.call(this);
};
dojo.inherits(dojo.widget.TreeLoadingController,dojo.widget.TreeBasicController);
dojo.lang.extend(dojo.widget.TreeLoadingController,{widgetType:"TreeLoadingController",RPCUrl:"",RPCActionParam:"action",RPCErrorHandler:function(type,obj,evt){
alert("RPC Error: "+(obj.message||"no message"));
},preventCache:true,getRPCUrl:function(_b34){
if(this.RPCUrl=="local"){
var dir=document.location.href.substr(0,document.location.href.lastIndexOf("/"));
var _b36=dir+"/"+_b34;
return _b36;
}
if(!this.RPCUrl){
dojo.raise("Empty RPCUrl: can't load");
}
return this.RPCUrl+(this.RPCUrl.indexOf("?")>-1?"&":"?")+this.RPCActionParam+"="+_b34;
},loadProcessResponse:function(node,_b38,_b39,_b3a){
if(!dojo.lang.isUndefined(_b38.error)){
this.RPCErrorHandler("server",_b38.error);
return false;
}
var _b3b=_b38;
if(!dojo.lang.isArray(_b3b)){
dojo.raise("loadProcessResponse: Not array loaded: "+_b3b);
}
for(var i=0;i<_b3b.length;i++){
_b3b[i]=dojo.widget.createWidget(node.widgetType,_b3b[i]);
node.addChild(_b3b[i]);
}
node.state=node.loadStates.LOADED;
if(dojo.lang.isFunction(_b3a)){
_b3a.apply(dojo.lang.isUndefined(_b39)?this:_b39,[node,_b3b]);
}
},getInfo:function(obj){
return obj.getInfo();
},runRPC:function(kw){
var _b3f=this;
var _b40=function(type,data,evt){
if(kw.lock){
dojo.lang.forEach(kw.lock,function(t){
t.unlock();
});
}
if(type=="load"){
kw.load.call(this,data);
}else{
this.RPCErrorHandler(type,data,evt);
}
};
if(kw.lock){
dojo.lang.forEach(kw.lock,function(t){
t.lock();
});
}
dojo.io.bind({url:kw.url,handle:dojo.lang.hitch(this,_b40),mimetype:"text/json",preventCache:_b3f.preventCache,sync:kw.sync,content:{data:dojo.json.serialize(kw.params)}});
},loadRemote:function(node,sync,_b48,_b49){
var _b4a=this;
var _b4b={node:this.getInfo(node),tree:this.getInfo(node.tree)};
this.runRPC({url:this.getRPCUrl("getChildren"),load:function(_b4c){
_b4a.loadProcessResponse(node,_b4c,_b48,_b49);
},sync:sync,lock:[node],params:_b4b});
},expand:function(node,sync,_b4f,_b50){
if(node.state==node.loadStates.UNCHECKED&&node.isFolder){
this.loadRemote(node,sync,this,function(node,_b52){
this.expand(node,sync,_b4f,_b50);
});
return;
}
dojo.widget.TreeBasicController.prototype.expand.apply(this,arguments);
},doMove:function(_b53,_b54,_b55){
if(_b54.isTreeNode&&_b54.state==_b54.loadStates.UNCHECKED){
this.loadRemote(_b54,true);
}
return dojo.widget.TreeBasicController.prototype.doMove.apply(this,arguments);
},doCreateChild:function(_b56,_b57,data,_b59,_b5a){
if(_b56.state==_b56.loadStates.UNCHECKED){
this.loadRemote(_b56,true);
}
return dojo.widget.TreeBasicController.prototype.doCreateChild.apply(this,arguments);
}});
dojo.provide("dojo.widget.Button");
dojo.widget.defineWidget("dojo.widget.Button",dojo.widget.HtmlWidget,{isContainer:true,caption:"",disabled:false,templateString:"<div dojoAttachPoint=\"buttonNode\" class=\"dojoButton\" style=\"position:relative;\" dojoAttachEvent=\"onMouseOver; onMouseOut; onMouseDown; onMouseUp; onClick:buttonClick; onKey:onKey; onFocus;\">\n  <div class=\"dojoButtonContents\" align=center dojoAttachPoint=\"containerNode\" style=\"position:absolute;z-index:2;\"></div>\n  <img dojoAttachPoint=\"leftImage\" style=\"position:absolute;left:0px;\">\n  <img dojoAttachPoint=\"centerImage\" style=\"position:absolute;z-index:1;\">\n  <img dojoAttachPoint=\"rightImage\" style=\"position:absolute;top:0px;right:0px;\">\n</div>\n",templateCssString:"/* ---- button --- */\n.dojoButton {\n	padding: 0 0 0 0;\n	font-size: 8pt;\n	white-space: nowrap;\n	cursor: pointer;\n	font-family: Myriad, Tahoma, Verdana, sans-serif;\n}\n\n.dojoButton .dojoButtonContents {\n	padding: 2px 2px 2px 2px;\n	text-align: center;		/* if icon and label are split across two lines, center icon */\n	color: white;\n}\n\n.dojoButtonLeftPart .dojoButtonContents {\n	padding-right: 8px;\n}\n\n.dojoButtonDisabled {\n	cursor: url(\"images/no.gif\"), default;\n}\n\n\n.dojoButtonContents img {\n	vertical-align: middle;	/* if icon and label are on same line, center them */\n}\n\n/* -------- colors ------------ */\n\n.dojoButtonHover .dojoButtonContents {\n}\n\n.dojoButtonDepressed .dojoButtonContents {\n	color: #293a4b;\n}\n\n.dojoButtonDisabled .dojoButtonContents {\n	color: #eeeeee;\n}\n\n\n/* ---------- drop down button specific ---------- */\n\n/* border between label and arrow (for drop down buttons */\n.dojoButton .border {\n	width: 1px;\n	background: gray;\n}\n\n/* button arrow */\n.dojoButton .downArrow {\n	padding-left: 10px;\n	text-align: center;\n}\n\n.dojoButton.disabled .downArrow {\n	cursor : default;\n}",templateCssPath:dojo.uri.dojoUri("src/widget/templates/ButtonTemplate.css"),inactiveImg:"src/widget/templates/images/soriaButton-",activeImg:"src/widget/templates/images/soriaActive-",pressedImg:"src/widget/templates/images/soriaPressed-",disabledImg:"src/widget/templates/images/soriaDisabled-",width2height:1/3,buttonNode:null,containerNode:null,leftImage:null,centerImage:null,rightImage:null,fillInTemplate:function(args,frag){
if(this.caption!=""){
this.containerNode.appendChild(document.createTextNode(this.caption));
}
dojo.html.disableSelection(this.containerNode);
},postCreate:function(args,frag){
this.sizeMyself();
},sizeMyself:function(){
if(this.domNode.parentNode){
var _b5f=document.createElement("span");
dojo.html.insertBefore(_b5f,this.domNode);
}
dojo.body().appendChild(this.domNode);
this.sizeMyselfHelper();
if(_b5f){
dojo.html.insertBefore(this.domNode,_b5f);
dojo.html.removeNode(_b5f);
}
},sizeMyselfHelper:function(){
var mb=dojo.html.getMarginBox(this.containerNode);
this.height=mb.height;
this.containerWidth=mb.width;
var _b61=this.height*this.width2height;
this.containerNode.style.left=_b61+"px";
this.leftImage.height=this.rightImage.height=this.centerImage.height=this.height;
this.leftImage.width=this.rightImage.width=_b61+1;
this.centerImage.width=this.containerWidth;
this.centerImage.style.left=_b61+"px";
this._setImage(this.disabled?this.disabledImg:this.inactiveImg);
if(this.disabled){
dojo.html.prependClass(this.domNode,"dojoButtonDisabled");
this.domNode.removeAttribute("tabIndex");
dojo.widget.wai.setAttr(this.domNode,"waiState","disabled",true);
}else{
dojo.html.removeClass(this.domNode,"dojoButtonDisabled");
this.domNode.setAttribute("tabIndex","0");
dojo.widget.wai.setAttr(this.domNode,"waiState","disabled",false);
}
this.domNode.style.height=this.height+"px";
this.domNode.style.width=(this.containerWidth+2*_b61)+"px";
},onMouseOver:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.buttonNode,"dojoButtonHover");
this._setImage(this.activeImg);
},onMouseDown:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.buttonNode,"dojoButtonDepressed");
dojo.html.removeClass(this.buttonNode,"dojoButtonHover");
this._setImage(this.pressedImg);
},onMouseUp:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.buttonNode,"dojoButtonHover");
dojo.html.removeClass(this.buttonNode,"dojoButtonDepressed");
this._setImage(this.activeImg);
},onMouseOut:function(e){
if(this.disabled){
return;
}
if(e.toElement&&dojo.html.isDescendantOf(e.toElement,this.buttonNode)){
return;
}
dojo.html.removeClass(this.buttonNode,"dojoButtonHover");
this._setImage(this.inactiveImg);
},onKey:function(e){
if(!e.key){
return;
}
var menu=dojo.widget.getWidgetById(this.menuId);
if(e.key==e.KEY_ENTER||e.key==" "){
this.onMouseDown(e);
this.buttonClick(e);
dojo.lang.setTimeout(this,"onMouseUp",75,e);
e.preventDefault();
e.stopPropagation();
}
if(menu&&menu.isShowingNow&&e.key==e.KEY_DOWN_ARROW){
dojo.event.disconnect(this.domNode,"onblur",this,"onBlur");
}
},onFocus:function(e){
var menu=dojo.widget.getWidgetById(this.menuId);
if(menu){
dojo.event.connectOnce(this.domNode,"onblur",this,"onBlur");
}
},onBlur:function(e){
var menu=dojo.widget.getWidgetById(this.menuId);
if(!menu){
return;
}
if(menu.close&&menu.isShowingNow){
menu.close();
}
},buttonClick:function(e){
if(!this.disabled){
this.onClick(e);
}
},onClick:function(e){
},_setImage:function(_b6e){
this.leftImage.src=dojo.uri.dojoUri(_b6e+"l.gif");
this.centerImage.src=dojo.uri.dojoUri(_b6e+"c.gif");
this.rightImage.src=dojo.uri.dojoUri(_b6e+"r.gif");
},_toggleMenu:function(_b6f){
var menu=dojo.widget.getWidgetById(_b6f);
if(!menu){
return;
}
if(menu.open&&!menu.isShowingNow){
var pos=dojo.html.getAbsolutePosition(this.domNode,false);
menu.open(pos.x,pos.y+this.height,this);
}else{
if(menu.close&&menu.isShowingNow){
menu.close();
}else{
menu.toggle();
}
}
},setCaption:function(_b72){
this.caption=_b72;
this.containerNode.innerHTML=_b72;
this.sizeMyself();
},setDisabled:function(_b73){
this.disabled=_b73;
this.sizeMyself();
}});
dojo.widget.defineWidget("dojo.widget.DropDownButton",dojo.widget.Button,{menuId:"",arrow:null,downArrow:"src/widget/templates/images/whiteDownArrow.gif",disabledDownArrow:"src/widget/templates/images/whiteDownArrow.gif",fillInTemplate:function(args,frag){
dojo.widget.DropDownButton.superclass.fillInTemplate.call(this,args,frag);
this.arrow=document.createElement("img");
dojo.html.setClass(this.arrow,"downArrow");
dojo.widget.wai.setAttr(this.domNode,"waiState","haspopup",this.menuId);
},sizeMyselfHelper:function(){
this.arrow.src=dojo.uri.dojoUri(this.disabled?this.disabledDownArrow:this.downArrow);
this.containerNode.appendChild(this.arrow);
dojo.widget.DropDownButton.superclass.sizeMyselfHelper.call(this);
},onClick:function(e){
this._toggleMenu(this.menuId);
}});
dojo.widget.defineWidget("dojo.widget.ComboButton",dojo.widget.Button,{menuId:"",templateString:"<div class=\"dojoButton\" style=\"position:relative;top:0px;left:0px; text-align:none;\" dojoAttachEvent=\"onKey;onFocus\">\n\n	<div dojoAttachPoint=\"buttonNode\" class=\"dojoButtonLeftPart\" style=\"position:absolute;left:0px;top:0px;\"\n		dojoAttachEvent=\"onMouseOver; onMouseOut; onMouseDown; onMouseUp; onClick:buttonClick;\">\n		<div class=\"dojoButtonContents\" dojoAttachPoint=\"containerNode\" style=\"position:absolute;top:0px;right:0px;z-index:2;\"></div>\n		<img dojoAttachPoint=\"leftImage\" style=\"position:absolute;left:0px;top:0px;\">\n		<img dojoAttachPoint=\"centerImage\" style=\"position:absolute;right:0px;top:0px;z-index:1;\">\n	</div>\n\n	<div dojoAttachPoint=\"rightPart\" class=\"dojoButtonRightPart\" style=\"position:absolute;top:0px;right:0px;\"\n		dojoAttachEvent=\"onMouseOver:rightOver; onMouseOut:rightOut; onMouseDown:rightDown; onMouseUp:rightUp; onClick:rightClick;\">\n		<img dojoAttachPoint=\"arrowBackgroundImage\" style=\"position:absolute;top:0px;left:0px;z-index:1;\">\n		<img src=\"${dojoRoot}src/widget/templates/images/whiteDownArrow.gif\"\n		  		style=\"z-index:2;position:absolute;left:3px;top:50%;\">\n		<img dojoAttachPoint=\"rightImage\" style=\"position:absolute;top:0px;right:0px;\">\n	</div>\n\n</div>\n",rightPart:null,arrowBackgroundImage:null,splitWidth:2,arrowWidth:5,sizeMyselfHelper:function(e){
var mb=dojo.html.getMarginBox(this.containerNode);
this.height=mb.height;
this.containerWidth=mb.width;
var _b79=this.height/3;
if(this.disabled){
dojo.widget.wai.setAttr(this.domNode,"waiState","disabled",true);
this.domNode.removeAttribute("tabIndex");
}else{
dojo.widget.wai.setAttr(this.domNode,"waiState","disabled",false);
this.domNode.setAttribute("tabIndex","0");
}
this.leftImage.height=this.rightImage.height=this.centerImage.height=this.arrowBackgroundImage.height=this.height;
this.leftImage.width=_b79+1;
this.centerImage.width=this.containerWidth;
this.buttonNode.style.height=this.height+"px";
this.buttonNode.style.width=_b79+this.containerWidth+"px";
this._setImage(this.disabled?this.disabledImg:this.inactiveImg);
this.arrowBackgroundImage.width=this.arrowWidth;
this.rightImage.width=_b79+1;
this.rightPart.style.height=this.height+"px";
this.rightPart.style.width=this.arrowWidth+_b79+"px";
this._setImageR(this.disabled?this.disabledImg:this.inactiveImg);
this.domNode.style.height=this.height+"px";
var _b7a=this.containerWidth+this.splitWidth+this.arrowWidth+2*_b79;
this.domNode.style.width=_b7a+"px";
},_setImage:function(_b7b){
this.leftImage.src=dojo.uri.dojoUri(_b7b+"l.gif");
this.centerImage.src=dojo.uri.dojoUri(_b7b+"c.gif");
},rightOver:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.rightPart,"dojoButtonHover");
this._setImageR(this.activeImg);
},rightDown:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.rightPart,"dojoButtonDepressed");
dojo.html.removeClass(this.rightPart,"dojoButtonHover");
this._setImageR(this.pressedImg);
},rightUp:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.rightPart,"dojoButtonHover");
dojo.html.removeClass(this.rightPart,"dojoButtonDepressed");
this._setImageR(this.activeImg);
},rightOut:function(e){
if(this.disabled){
return;
}
dojo.html.removeClass(this.rightPart,"dojoButtonHover");
this._setImageR(this.inactiveImg);
},rightClick:function(e){
if(this.disabled){
return;
}
this._toggleMenu(this.menuId);
},_setImageR:function(_b81){
this.arrowBackgroundImage.src=dojo.uri.dojoUri(_b81+"c.gif");
this.rightImage.src=dojo.uri.dojoUri(_b81+"r.gif");
},onKey:function(e){
if(!e.key){
return;
}
var menu=dojo.widget.getWidgetById(this.menuId);
if(e.key==e.KEY_ENTER||e.key==" "){
this.onMouseDown(e);
this.buttonClick(e);
dojo.lang.setTimeout(this,"onMouseUp",75,e);
e.preventDefault();
e.stopPropagation();
}else{
if(e.key==e.KEY_DOWN_ARROW&&e.altKey){
this.rightDown(e);
this.rightClick(e);
dojo.lang.setTimeout(this,"rightUp",75,e);
e.preventDefault();
e.stopPropagation();
}else{
if(menu&&menu.isShowingNow&&e.key==e.KEY_DOWN_ARROW){
dojo.event.disconnect(this.domNode,"onblur",this,"onBlur");
}
}
}
}});
dojo.provide("dojo.widget.Dialog");
dojo.declare("dojo.widget.ModalDialogBase",null,{isContainer:true,_scrollConnected:false,focusElement:"",shared:{bg:null,bgIframe:null},bgColor:"black",bgOpacity:0.4,followScroll:true,_fromTrap:false,trapTabs:function(e){
if(e.target==this.tabStartOuter){
if(this._fromTrap){
this.tabStart.focus();
this._fromTrap=false;
}else{
this._fromTrap=true;
this.tabEnd.focus();
}
}else{
if(e.target==this.tabStart){
if(this._fromTrap){
this._fromTrap=false;
}else{
this._fromTrap=true;
this.tabEnd.focus();
}
}else{
if(e.target==this.tabEndOuter){
if(this._fromTrap){
this.tabEnd.focus();
this._fromTrap=false;
}else{
this._fromTrap=true;
this.tabStart.focus();
}
}else{
if(e.target==this.tabEnd){
if(this._fromTrap){
this._fromTrap=false;
}else{
this._fromTrap=true;
this.tabStart.focus();
}
}
}
}
}
},clearTrap:function(e){
var _b86=this;
setTimeout(function(){
_b86._fromTrap=false;
},100);
},postCreate:function(){
with(this.domNode.style){
position="absolute";
zIndex=999;
display="none";
overflow="visible";
}
var b=dojo.body();
b.appendChild(this.domNode);
if(!this.shared.bg){
this.shared.bg=document.createElement("div");
this.shared.bg.className="dialogUnderlay";
with(this.shared.bg.style){
position="absolute";
left=top="0px";
zIndex=998;
display="none";
}
this.setBackgroundColor(this.bgColor);
b.appendChild(this.shared.bg);
this.shared.bgIframe=new dojo.html.BackgroundIframe(this.shared.bg);
}
},setBackgroundColor:function(_b88){
if(arguments.length>=3){
_b88=new dojo.gfx.color.Color(arguments[0],arguments[1],arguments[2]);
}else{
_b88=new dojo.gfx.color.Color(_b88);
}
this.shared.bg.style.backgroundColor=_b88.toString();
return this.bgColor=_b88;
},setBackgroundOpacity:function(op){
if(arguments.length==0){
op=this.bgOpacity;
}
dojo.html.setOpacity(this.shared.bg,op);
try{
this.bgOpacity=dojo.html.getOpacity(this.shared.bg);
}
catch(e){
this.bgOpacity=op;
}
return this.bgOpacity;
},sizeBackground:function(){
if(this.bgOpacity>0){
var _b8a=dojo.html.getViewport();
var h=_b8a.height;
var w=_b8a.width;
this.shared.bg.style.width=w+"px";
this.shared.bg.style.height=h+"px";
var _b8a=dojo.html.getViewport();
if(_b8a.width!=w){
this.shared.bg.style.width=_b8a.width+"px";
}
if(_b8a.height!=h){
this.shared.bg.style.height=_b8a.height+"px";
}
}
},showBackground:function(){
if(this.bgOpacity>0){
this.shared.bg.style.display="block";
}
},placeModalDialog:function(){
var _b8d=dojo.html.getScroll().offset;
var _b8e=dojo.html.getViewport();
var mb=dojo.html.getMarginBox(this.containerNode);
var x=_b8d.x+(_b8e.width-mb.width)/2;
var y=_b8d.y+(_b8e.height-mb.height)/2;
with(this.domNode.style){
left=x+"px";
top=y+"px";
}
},showModalDialog:function(){
this.setBackgroundOpacity();
this.showBackground();
},hideModalDialog:function(){
if(this.focusElement){
dojo.byId(this.focusElement).focus();
dojo.byId(this.focusElement).blur();
}
this.shared.bg.style.display="none";
this.shared.bg.style.width=this.shared.bg.style.height="1px";
}});
dojo.widget.defineWidget("dojo.widget.Dialog",[dojo.widget.ContentPane,dojo.widget.ModalDialogBase],{templateString:"<div id=\"${this.widgetId}\" class=\"dojoDialog\" dojoattachpoint=\"wrapper\">\n	<span dojoattachpoint=\"tabStartOuter\" dojoonfocus=\"trapTabs\" dojoonblur=\"clearTrap\"	tabindex=\"0\"></span>\n	<span dojoattachpoint=\"tabStart\" dojoonfocus=\"trapTabs\" dojoonblur=\"clearTrap\" tabindex=\"0\"></span>\n	<div dojoattachpoint=\"containerNode\" style=\"position: relative; z-index: 2;\"></div>\n	<span dojoattachpoint=\"tabEnd\" dojoonfocus=\"trapTabs\" dojoonblur=\"clearTrap\" tabindex=\"0\"></span>\n	<span dojoattachpoint=\"tabEndOuter\" dojoonfocus=\"trapTabs\" dojoonblur=\"clearTrap\" tabindex=\"0\"></span>\n</div>\n",anim:null,blockDuration:0,lifetime:0,show:function(){
if(this.followScroll&&!this._scrollConnected){
this._scrollConnected=true;
dojo.event.connect(window,"onscroll",this,"onScroll");
}
if(this.lifetime){
this.timeRemaining=this.lifetime;
if(!this.blockDuration){
dojo.event.connect(this.shared.bg,"onclick",this,"hide");
}else{
dojo.event.disconnect(this.shared.bg,"onclick",this,"hide");
}
if(this.timerNode){
this.timerNode.innerHTML=Math.ceil(this.timeRemaining/1000);
}
if(this.blockDuration&&this.closeNode){
if(this.lifetime>this.blockDuration){
this.closeNode.style.visibility="hidden";
}else{
this.closeNode.style.display="none";
}
}
this.timer=setInterval(dojo.lang.hitch(this,"onTick"),100);
}
this.showModalDialog();
dojo.widget.Dialog.superclass.show.call(this);
this.checkSize();
},onLoad:function(){
this.placeModalDialog();
dojo.widget.Dialog.superclass.onLoad.call(this);
},fillInTemplate:function(){
},hide:function(){
this.hideModalDialog();
dojo.widget.Dialog.superclass.hide.call(this);
if(this.timer){
clearInterval(this.timer);
}
if(this._scrollConnected){
this._scrollConnected=false;
dojo.event.disconnect(window,"onscroll",this,"onScroll");
}
},setTimerNode:function(node){
this.timerNode=node;
},setCloseControl:function(node){
this.closeNode=node;
dojo.event.connect(node,"onclick",this,"hide");
},setShowControl:function(node){
dojo.event.connect(node,"onclick",this,"show");
},onTick:function(){
if(this.timer){
this.timeRemaining-=100;
if(this.lifetime-this.timeRemaining>=this.blockDuration){
dojo.event.connect(this.shared.bg,"onclick",this,"hide");
if(this.closeNode){
this.closeNode.style.visibility="visible";
}
}
if(!this.timeRemaining){
clearInterval(this.timer);
this.hide();
}else{
if(this.timerNode){
this.timerNode.innerHTML=Math.ceil(this.timeRemaining/1000);
}
}
}
},onScroll:function(){
var _b95=dojo.html.getScroll().offset;
this.shared.bg.style.top=_b95.y+"px";
this.shared.bg.style.left=_b95.x+"px";
this.placeModalDialog();
},checkSize:function(){
if(this.isShowing()){
this.sizeBackground();
this.placeModalDialog();
this.onResized();
}
}});
dojo.provide("dojo.widget.ToolbarContainer");
dojo.provide("dojo.widget.Toolbar");
dojo.provide("dojo.widget.ToolbarItem");
dojo.provide("dojo.widget.ToolbarButtonGroup");
dojo.provide("dojo.widget.ToolbarButton");
dojo.provide("dojo.widget.ToolbarDialog");
dojo.provide("dojo.widget.ToolbarMenu");
dojo.provide("dojo.widget.ToolbarSeparator");
dojo.provide("dojo.widget.ToolbarSpace");
dojo.provide("dojo.widget.Icon");
dojo.widget.defineWidget("dojo.widget.ToolbarContainer",dojo.widget.HtmlWidget,{isContainer:true,templateString:"<div class=\"toolbarContainer\" dojoAttachPoint=\"containerNode\"></div>",templateCssString:".toolbarContainer {\n	border-bottom : 0;\n	background-color : #def;\n	color : ButtonText;\n	font : Menu;\n	background-image: url(images/toolbar-bg.gif);\n}\n\n.toolbar {\n	padding : 2px 4px;\n	min-height : 26px;\n	_height : 26px;\n}\n\n.toolbarItem {\n	float : left;\n	padding : 1px 2px;\n	margin : 0 2px 1px 0;\n	cursor : pointer;\n}\n\n.toolbarItem.selected, .toolbarItem.down {\n	margin : 1px 1px 0 1px;\n	padding : 0px 1px;\n	border : 1px solid #bbf;\n	background-color : #fafaff;\n}\n\n.toolbarButton img {\n	vertical-align : bottom;\n}\n\n.toolbarButton span {\n	line-height : 16px;\n	vertical-align : middle;\n}\n\n.toolbarButton.hover {\n	padding : 0px 1px;\n	border : 1px solid #99c;\n}\n\n.toolbarItem.disabled {\n	opacity : 0.3;\n	filter : alpha(opacity=30);\n	cursor : default;\n}\n\n.toolbarSeparator {\n	cursor : default;\n}\n\n.toolbarFlexibleSpace {\n}\n",templateCssPath:dojo.uri.dojoUri("src/widget/templates/Toolbar.css"),getItem:function(name){
if(name instanceof dojo.widget.ToolbarItem){
return name;
}
for(var i=0;i<this.children.length;i++){
var _b98=this.children[i];
if(_b98 instanceof dojo.widget.Toolbar){
var item=_b98.getItem(name);
if(item){
return item;
}
}
}
return null;
},getItems:function(){
var _b9a=[];
for(var i=0;i<this.children.length;i++){
var _b9c=this.children[i];
if(_b9c instanceof dojo.widget.Toolbar){
_b9a=_b9a.concat(_b9c.getItems());
}
}
return _b9a;
},enable:function(){
for(var i=0;i<this.children.length;i++){
var _b9e=this.children[i];
if(_b9e instanceof dojo.widget.Toolbar){
_b9e.enable.apply(_b9e,arguments);
}
}
},disable:function(){
for(var i=0;i<this.children.length;i++){
var _ba0=this.children[i];
if(_ba0 instanceof dojo.widget.Toolbar){
_ba0.disable.apply(_ba0,arguments);
}
}
},select:function(name){
for(var i=0;i<this.children.length;i++){
var _ba3=this.children[i];
if(_ba3 instanceof dojo.widget.Toolbar){
_ba3.select(arguments);
}
}
},deselect:function(name){
for(var i=0;i<this.children.length;i++){
var _ba6=this.children[i];
if(_ba6 instanceof dojo.widget.Toolbar){
_ba6.deselect(arguments);
}
}
},getItemsState:function(){
var _ba7={};
for(var i=0;i<this.children.length;i++){
var _ba9=this.children[i];
if(_ba9 instanceof dojo.widget.Toolbar){
dojo.lang.mixin(_ba7,_ba9.getItemsState());
}
}
return _ba7;
},getItemsActiveState:function(){
var _baa={};
for(var i=0;i<this.children.length;i++){
var _bac=this.children[i];
if(_bac instanceof dojo.widget.Toolbar){
dojo.lang.mixin(_baa,_bac.getItemsActiveState());
}
}
return _baa;
},getItemsSelectedState:function(){
var _bad={};
for(var i=0;i<this.children.length;i++){
var _baf=this.children[i];
if(_baf instanceof dojo.widget.Toolbar){
dojo.lang.mixin(_bad,_baf.getItemsSelectedState());
}
}
return _bad;
}});
dojo.widget.defineWidget("dojo.widget.Toolbar",dojo.widget.HtmlWidget,{isContainer:true,templateString:"<div class=\"toolbar\" dojoAttachPoint=\"containerNode\" unselectable=\"on\" dojoOnMouseover=\"_onmouseover\" dojoOnMouseout=\"_onmouseout\" dojoOnClick=\"_onclick\" dojoOnMousedown=\"_onmousedown\" dojoOnMouseup=\"_onmouseup\"></div>",_getItem:function(node){
var _bb1=new Date();
var _bb2=null;
while(node&&node!=this.domNode){
if(dojo.html.hasClass(node,"toolbarItem")){
var _bb3=dojo.widget.manager.getWidgetsByFilter(function(w){
return w.domNode==node;
});
if(_bb3.length==1){
_bb2=_bb3[0];
break;
}else{
if(_bb3.length>1){
dojo.raise("Toolbar._getItem: More than one widget matches the node");
}
}
}
node=node.parentNode;
}
return _bb2;
},_onmouseover:function(e){
var _bb6=this._getItem(e.target);
if(_bb6&&_bb6._onmouseover){
_bb6._onmouseover(e);
}
},_onmouseout:function(e){
var _bb8=this._getItem(e.target);
if(_bb8&&_bb8._onmouseout){
_bb8._onmouseout(e);
}
},_onclick:function(e){
var _bba=this._getItem(e.target);
if(_bba&&_bba._onclick){
_bba._onclick(e);
}
},_onmousedown:function(e){
var _bbc=this._getItem(e.target);
if(_bbc&&_bbc._onmousedown){
_bbc._onmousedown(e);
}
},_onmouseup:function(e){
var _bbe=this._getItem(e.target);
if(_bbe&&_bbe._onmouseup){
_bbe._onmouseup(e);
}
},addChild:function(item,pos,_bc1){
var _bc2=dojo.widget.ToolbarItem.make(item,null,_bc1);
var ret=dojo.widget.Toolbar.superclass.addChild.call(this,_bc2,null,pos,null);
return ret;
},push:function(){
for(var i=0;i<arguments.length;i++){
this.addChild(arguments[i]);
}
},getItem:function(name){
if(name instanceof dojo.widget.ToolbarItem){
return name;
}
for(var i=0;i<this.children.length;i++){
var _bc7=this.children[i];
if(_bc7 instanceof dojo.widget.ToolbarItem&&_bc7._name==name){
return _bc7;
}
}
return null;
},getItems:function(){
var _bc8=[];
for(var i=0;i<this.children.length;i++){
var _bca=this.children[i];
if(_bca instanceof dojo.widget.ToolbarItem){
_bc8.push(_bca);
}
}
return _bc8;
},getItemsState:function(){
var _bcb={};
for(var i=0;i<this.children.length;i++){
var _bcd=this.children[i];
if(_bcd instanceof dojo.widget.ToolbarItem){
_bcb[_bcd._name]={selected:_bcd._selected,enabled:_bcd._enabled};
}
}
return _bcb;
},getItemsActiveState:function(){
var _bce=this.getItemsState();
for(var item in _bce){
_bce[item]=_bce[item].enabled;
}
return _bce;
},getItemsSelectedState:function(){
var _bd0=this.getItemsState();
for(var item in _bd0){
_bd0[item]=_bd0[item].selected;
}
return _bd0;
},enable:function(){
var _bd2=arguments.length?arguments:this.children;
for(var i=0;i<_bd2.length;i++){
var _bd4=this.getItem(_bd2[i]);
if(_bd4 instanceof dojo.widget.ToolbarItem){
_bd4.enable(false,true);
}
}
},disable:function(){
var _bd5=arguments.length?arguments:this.children;
for(var i=0;i<_bd5.length;i++){
var _bd7=this.getItem(_bd5[i]);
if(_bd7 instanceof dojo.widget.ToolbarItem){
_bd7.disable();
}
}
},select:function(){
for(var i=0;i<arguments.length;i++){
var name=arguments[i];
var item=this.getItem(name);
if(item){
item.select();
}
}
},deselect:function(){
for(var i=0;i<arguments.length;i++){
var name=arguments[i];
var item=this.getItem(name);
if(item){
item.disable();
}
}
},setValue:function(){
for(var i=0;i<arguments.length;i+=2){
var name=arguments[i],value=arguments[i+1];
var item=this.getItem(name);
if(item){
if(item instanceof dojo.widget.ToolbarItem){
item.setValue(value);
}
}
}
}});
dojo.widget.defineWidget("dojo.widget.ToolbarItem",dojo.widget.HtmlWidget,{templateString:"<span unselectable=\"on\" class=\"toolbarItem\"></span>",_name:null,getName:function(){
return this._name;
},setName:function(_be1){
return (this._name=_be1);
},getValue:function(){
return this.getName();
},setValue:function(_be2){
return this.setName(_be2);
},_selected:false,isSelected:function(){
return this._selected;
},setSelected:function(is,_be4,_be5){
if(!this._toggleItem&&!_be4){
return;
}
is=Boolean(is);
if(_be4||this._enabled&&this._selected!=is){
this._selected=is;
this.update();
if(!_be5){
this._fireEvent(is?"onSelect":"onDeselect");
this._fireEvent("onChangeSelect");
}
}
},select:function(_be6,_be7){
return this.setSelected(true,_be6,_be7);
},deselect:function(_be8,_be9){
return this.setSelected(false,_be8,_be9);
},_toggleItem:false,isToggleItem:function(){
return this._toggleItem;
},setToggleItem:function(_bea){
this._toggleItem=Boolean(_bea);
},toggleSelected:function(_beb){
return this.setSelected(!this._selected,_beb);
},_enabled:true,isEnabled:function(){
return this._enabled;
},setEnabled:function(is,_bed,_bee){
is=Boolean(is);
if(_bed||this._enabled!=is){
this._enabled=is;
this.update();
if(!_bee){
this._fireEvent(this._enabled?"onEnable":"onDisable");
this._fireEvent("onChangeEnabled");
}
}
return this._enabled;
},enable:function(_bef,_bf0){
return this.setEnabled(true,_bef,_bf0);
},disable:function(_bf1,_bf2){
return this.setEnabled(false,_bf1,_bf2);
},toggleEnabled:function(_bf3,_bf4){
return this.setEnabled(!this._enabled,_bf3,_bf4);
},_icon:null,getIcon:function(){
return this._icon;
},setIcon:function(_bf5){
var icon=dojo.widget.Icon.make(_bf5);
if(this._icon){
this._icon.setIcon(icon);
}else{
this._icon=icon;
}
var _bf7=this._icon.getNode();
if(_bf7.parentNode!=this.domNode){
if(this.domNode.hasChildNodes()){
this.domNode.insertBefore(_bf7,this.domNode.firstChild);
}else{
this.domNode.appendChild(_bf7);
}
}
return this._icon;
},_label:"",getLabel:function(){
return this._label;
},setLabel:function(_bf8){
var ret=(this._label=_bf8);
if(!this.labelNode){
this.labelNode=document.createElement("span");
this.domNode.appendChild(this.labelNode);
}
this.labelNode.innerHTML="";
this.labelNode.appendChild(document.createTextNode(this._label));
this.update();
return ret;
},update:function(){
if(this._enabled){
dojo.html.removeClass(this.domNode,"disabled");
if(this._selected){
dojo.html.addClass(this.domNode,"selected");
}else{
dojo.html.removeClass(this.domNode,"selected");
}
}else{
this._selected=false;
dojo.html.addClass(this.domNode,"disabled");
dojo.html.removeClass(this.domNode,"down");
dojo.html.removeClass(this.domNode,"hover");
}
this._updateIcon();
},_updateIcon:function(){
if(this._icon){
if(this._enabled){
if(this._cssHover){
this._icon.hover();
}else{
if(this._selected){
this._icon.select();
}else{
this._icon.enable();
}
}
}else{
this._icon.disable();
}
}
},_fireEvent:function(evt){
if(typeof this[evt]=="function"){
var args=[this];
for(var i=1;i<arguments.length;i++){
args.push(arguments[i]);
}
this[evt].apply(this,args);
}
},_onmouseover:function(e){
if(!this._enabled){
return;
}
dojo.html.addClass(this.domNode,"hover");
this._fireEvent("onMouseOver");
},_onmouseout:function(e){
dojo.html.removeClass(this.domNode,"hover");
dojo.html.removeClass(this.domNode,"down");
if(!this._selected){
dojo.html.removeClass(this.domNode,"selected");
}
this._fireEvent("onMouseOut");
},_onclick:function(e){
if(this._enabled&&!this._toggleItem){
this._fireEvent("onClick");
}
},_onmousedown:function(e){
if(e.preventDefault){
e.preventDefault();
}
if(!this._enabled){
return;
}
dojo.html.addClass(this.domNode,"down");
if(this._toggleItem){
if(this.parent.preventDeselect&&this._selected){
return;
}
this.toggleSelected();
}
this._fireEvent("onMouseDown");
},_onmouseup:function(e){
dojo.html.removeClass(this.domNode,"down");
this._fireEvent("onMouseUp");
},onClick:function(){
},onMouseOver:function(){
},onMouseOut:function(){
},onMouseDown:function(){
},onMouseUp:function(){
},fillInTemplate:function(args,frag){
if(args.name){
this._name=args.name;
}
if(args.selected){
this.select();
}
if(args.disabled){
this.disable();
}
if(args.label){
this.setLabel(args.label);
}
if(args.icon){
this.setIcon(args.icon);
}
if(args.toggleitem||args.toggleItem){
this.setToggleItem(true);
}
}});
dojo.widget.ToolbarItem.make=function(wh,_c05,_c06){
var item=null;
if(wh instanceof Array){
item=dojo.widget.createWidget("ToolbarButtonGroup",_c06);
item.setName(wh[0]);
for(var i=1;i<wh.length;i++){
item.addChild(wh[i]);
}
}else{
if(wh instanceof dojo.widget.ToolbarItem){
item=wh;
}else{
if(wh instanceof dojo.uri.Uri){
item=dojo.widget.createWidget("ToolbarButton",dojo.lang.mixin(_c06||{},{icon:new dojo.widget.Icon(wh.toString())}));
}else{
if(_c05){
item=dojo.widget.createWidget(wh,_c06);
}else{
if(typeof wh=="string"||wh instanceof String){
switch(wh.charAt(0)){
case "|":
case "-":
case "/":
item=dojo.widget.createWidget("ToolbarSeparator",_c06);
break;
case " ":
if(wh.length==1){
item=dojo.widget.createWidget("ToolbarSpace",_c06);
}else{
item=dojo.widget.createWidget("ToolbarFlexibleSpace",_c06);
}
break;
default:
if(/\.(gif|jpg|jpeg|png)$/i.test(wh)){
item=dojo.widget.createWidget("ToolbarButton",dojo.lang.mixin(_c06||{},{icon:new dojo.widget.Icon(wh.toString())}));
}else{
item=dojo.widget.createWidget("ToolbarButton",dojo.lang.mixin(_c06||{},{label:wh.toString()}));
}
}
}else{
if(wh&&wh.tagName&&/^img$/i.test(wh.tagName)){
item=dojo.widget.createWidget("ToolbarButton",dojo.lang.mixin(_c06||{},{icon:wh}));
}else{
item=dojo.widget.createWidget("ToolbarButton",dojo.lang.mixin(_c06||{},{label:wh.toString()}));
}
}
}
}
}
}
return item;
};
dojo.widget.defineWidget("dojo.widget.ToolbarButtonGroup",dojo.widget.ToolbarItem,{isContainer:true,templateString:"<span unselectable=\"on\" class=\"toolbarButtonGroup\" dojoAttachPoint=\"containerNode\"></span>",defaultButton:"",postCreate:function(){
for(var i=0;i<this.children.length;i++){
this._injectChild(this.children[i]);
}
},addChild:function(item,pos,_c0c){
var _c0d=dojo.widget.ToolbarItem.make(item,null,dojo.lang.mixin(_c0c||{},{toggleItem:true}));
var ret=dojo.widget.ToolbarButtonGroup.superclass.addChild.call(this,_c0d,null,pos,null);
this._injectChild(_c0d);
return ret;
},_injectChild:function(_c0f){
dojo.event.connect(_c0f,"onSelect",this,"onChildSelected");
dojo.event.connect(_c0f,"onDeselect",this,"onChildDeSelected");
if(_c0f._name==this.defaultButton||(typeof this.defaultButton=="number"&&this.children.length-1==this.defaultButton)){
_c0f.select(false,true);
}
},getItem:function(name){
if(name instanceof dojo.widget.ToolbarItem){
return name;
}
for(var i=0;i<this.children.length;i++){
var _c12=this.children[i];
if(_c12 instanceof dojo.widget.ToolbarItem&&_c12._name==name){
return _c12;
}
}
return null;
},getItems:function(){
var _c13=[];
for(var i=0;i<this.children.length;i++){
var _c15=this.children[i];
if(_c15 instanceof dojo.widget.ToolbarItem){
_c13.push(_c15);
}
}
return _c13;
},onChildSelected:function(e){
this.select(e._name);
},onChildDeSelected:function(e){
this._fireEvent("onChangeSelect",this._value);
},enable:function(_c18,_c19){
for(var i=0;i<this.children.length;i++){
var _c1b=this.children[i];
if(_c1b instanceof dojo.widget.ToolbarItem){
_c1b.enable(_c18,_c19);
if(_c1b._name==this._value){
_c1b.select(_c18,_c19);
}
}
}
},disable:function(_c1c,_c1d){
for(var i=0;i<this.children.length;i++){
var _c1f=this.children[i];
if(_c1f instanceof dojo.widget.ToolbarItem){
_c1f.disable(_c1c,_c1d);
}
}
},_value:"",getValue:function(){
return this._value;
},select:function(name,_c21,_c22){
for(var i=0;i<this.children.length;i++){
var _c24=this.children[i];
if(_c24 instanceof dojo.widget.ToolbarItem){
if(_c24._name==name){
_c24.select(_c21,_c22);
this._value=name;
}else{
_c24.deselect(true,true);
}
}
}
if(!_c22){
this._fireEvent("onSelect",this._value);
this._fireEvent("onChangeSelect",this._value);
}
},setValue:this.select,preventDeselect:false});
dojo.widget.defineWidget("dojo.widget.ToolbarButton",dojo.widget.ToolbarItem,{fillInTemplate:function(args,frag){
dojo.widget.ToolbarButton.superclass.fillInTemplate.call(this,args,frag);
dojo.html.addClass(this.domNode,"toolbarButton");
if(this._icon){
this.setIcon(this._icon);
}
if(this._label){
this.setLabel(this._label);
}
if(!this._name){
if(this._label){
this.setName(this._label);
}else{
if(this._icon){
var src=this._icon.getSrc("enabled").match(/[\/^]([^\.\/]+)\.(gif|jpg|jpeg|png)$/i);
if(src){
this.setName(src[1]);
}
}else{
this._name=this._widgetId;
}
}
}
}});
dojo.widget.defineWidget("dojo.widget.ToolbarDialog",dojo.widget.ToolbarButton,{fillInTemplate:function(args,frag){
dojo.widget.ToolbarDialog.superclass.fillInTemplate.call(this,args,frag);
dojo.event.connect(this,"onSelect",this,"showDialog");
dojo.event.connect(this,"onDeselect",this,"hideDialog");
},showDialog:function(e){
dojo.lang.setTimeout(dojo.event.connect,1,document,"onmousedown",this,"deselect");
},hideDialog:function(e){
dojo.event.disconnect(document,"onmousedown",this,"deselect");
}});
dojo.widget.defineWidget("dojo.widget.ToolbarMenu",dojo.widget.ToolbarDialog,{});
dojo.widget.ToolbarMenuItem=function(){
};
dojo.widget.defineWidget("dojo.widget.ToolbarSeparator",dojo.widget.ToolbarItem,{templateString:"<span unselectable=\"on\" class=\"toolbarItem toolbarSeparator\"></span>",defaultIconPath:new dojo.uri.dojoUri("src/widget/templates/buttons/sep.gif"),fillInTemplate:function(args,frag,skip){
dojo.widget.ToolbarSeparator.superclass.fillInTemplate.call(this,args,frag);
this._name=this.widgetId;
if(!skip){
if(!this._icon){
this.setIcon(this.defaultIconPath);
}
this.domNode.appendChild(this._icon.getNode());
}
},_onmouseover:null,_onmouseout:null,_onclick:null,_onmousedown:null,_onmouseup:null});
dojo.widget.defineWidget("dojo.widget.ToolbarSpace",dojo.widget.ToolbarSeparator,{fillInTemplate:function(args,frag,skip){
dojo.widget.ToolbarSpace.superclass.fillInTemplate.call(this,args,frag,true);
if(!skip){
dojo.html.addClass(this.domNode,"toolbarSpace");
}
}});
dojo.widget.defineWidget("dojo.widget.ToolbarSelect",dojo.widget.ToolbarItem,{templateString:"<span class=\"toolbarItem toolbarSelect\" unselectable=\"on\"><select dojoAttachPoint=\"selectBox\" dojoOnChange=\"changed\"></select></span>",fillInTemplate:function(args,frag){
dojo.widget.ToolbarSelect.superclass.fillInTemplate.call(this,args,frag,true);
var keys=args.values;
var i=0;
for(var val in keys){
var opt=document.createElement("option");
opt.setAttribute("value",keys[val]);
opt.innerHTML=val;
this.selectBox.appendChild(opt);
}
},changed:function(e){
this._fireEvent("onSetValue",this.selectBox.value);
},setEnabled:function(is,_c3a,_c3b){
var ret=dojo.widget.ToolbarSelect.superclass.setEnabled.call(this,is,_c3a,_c3b);
this.selectBox.disabled=!this._enabled;
return ret;
},_onmouseover:null,_onmouseout:null,_onclick:null,_onmousedown:null,_onmouseup:null});
dojo.widget.Icon=function(_c3d,_c3e,_c3f,_c40){
if(!arguments.length){
throw new Error("Icon must have at least an enabled state");
}
var _c41=["enabled","disabled","hovered","selected"];
var _c42="enabled";
var _c43=document.createElement("img");
this.getState=function(){
return _c42;
};
this.setState=function(_c44){
if(dojo.lang.inArray(_c41,_c44)){
if(this[_c44]){
_c42=_c44;
var img=this[_c42];
if((dojo.render.html.ie55||dojo.render.html.ie60)&&img.src&&img.src.match(/[.]png$/i)){
_c43.width=img.width||img.offsetWidth;
_c43.height=img.height||img.offsetHeight;
_c43.setAttribute("src",dojo.uri.dojoUri("src/widget/templates/images/blank.gif").uri);
_c43.style.filter="progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+img.src+"',sizingMethod='image')";
}else{
_c43.setAttribute("src",img.src);
}
}
}else{
throw new Error("Invalid state set on Icon (state: "+_c44+")");
}
};
this.setSrc=function(_c46,_c47){
if(/^img$/i.test(_c47.tagName)){
this[_c46]=_c47;
}else{
if(typeof _c47=="string"||_c47 instanceof String||_c47 instanceof dojo.uri.Uri){
this[_c46]=new Image();
this[_c46].src=_c47.toString();
}
}
return this[_c46];
};
this.setIcon=function(icon){
for(var i=0;i<_c41.length;i++){
if(icon[_c41[i]]){
this.setSrc(_c41[i],icon[_c41[i]]);
}
}
this.update();
};
this.enable=function(){
this.setState("enabled");
};
this.disable=function(){
this.setState("disabled");
};
this.hover=function(){
this.setState("hovered");
};
this.select=function(){
this.setState("selected");
};
this.getSize=function(){
return {width:_c43.width||_c43.offsetWidth,height:_c43.height||_c43.offsetHeight};
};
this.setSize=function(w,h){
_c43.width=w;
_c43.height=h;
return {width:w,height:h};
};
this.getNode=function(){
return _c43;
};
this.getSrc=function(_c4c){
if(_c4c){
return this[_c4c].src;
}
return _c43.src||"";
};
this.update=function(){
this.setState(_c42);
};
for(var i=0;i<_c41.length;i++){
var arg=arguments[i];
var _c4f=_c41[i];
this[_c4f]=null;
if(!arg){
continue;
}
this.setSrc(_c4f,arg);
}
this.enable();
};
dojo.widget.Icon.make=function(a,b,c,d){
for(var i=0;i<arguments.length;i++){
if(arguments[i] instanceof dojo.widget.Icon){
return arguments[i];
}
}
return new dojo.widget.Icon(a,b,c,d);
};
dojo.provide("dojo.lfx.shadow");
dojo.lfx.shadow=function(node){
this.shadowPng=dojo.uri.dojoUri("src/html/images/shadow");
this.shadowThickness=8;
this.shadowOffset=15;
this.init(node);
};
dojo.extend(dojo.lfx.shadow,{init:function(node){
this.node=node;
this.pieces={};
var x1=-1*this.shadowThickness;
var y0=this.shadowOffset;
var y1=this.shadowOffset+this.shadowThickness;
this._makePiece("tl","top",y0,"left",x1);
this._makePiece("l","top",y1,"left",x1,"scale");
this._makePiece("tr","top",y0,"left",0);
this._makePiece("r","top",y1,"left",0,"scale");
this._makePiece("bl","top",0,"left",x1);
this._makePiece("b","top",0,"left",0,"crop");
this._makePiece("br","top",0,"left",0);
},_makePiece:function(name,_c5b,_c5c,_c5d,_c5e,_c5f){
var img;
var url=this.shadowPng+name.toUpperCase()+".png";
if(dojo.render.html.ie55||dojo.render.html.ie60){
img=dojo.doc().createElement("div");
img.style.filter="progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+url+"'"+(_c5f?", sizingMethod='"+_c5f+"'":"")+")";
}else{
img=dojo.doc().createElement("img");
img.src=url;
}
img.style.position="absolute";
img.style[_c5b]=_c5c+"px";
img.style[_c5d]=_c5e+"px";
img.style.width=this.shadowThickness+"px";
img.style.height=this.shadowThickness+"px";
this.pieces[name]=img;
this.node.appendChild(img);
},size:function(_c62,_c63){
var _c64=_c63-(this.shadowOffset+this.shadowThickness+1);
if(_c64<0){
_c64=0;
}
if(_c63<1){
_c63=1;
}
if(_c62<1){
_c62=1;
}
with(this.pieces){
l.style.height=_c64+"px";
r.style.height=_c64+"px";
b.style.width=(_c62-1)+"px";
bl.style.top=(_c63-1)+"px";
b.style.top=(_c63-1)+"px";
br.style.top=(_c63-1)+"px";
tr.style.left=(_c62-1)+"px";
r.style.left=(_c62-1)+"px";
br.style.left=(_c62-1)+"px";
}
}});
dojo.provide("dojo.dnd.*");
dojo.provide("dojo.dnd.HtmlDragMove");
dojo.provide("dojo.dnd.HtmlDragMoveSource");
dojo.provide("dojo.dnd.HtmlDragMoveObject");
dojo.declare("dojo.dnd.HtmlDragMoveSource",dojo.dnd.HtmlDragSource,{onDragStart:function(){
var _c65=new dojo.dnd.HtmlDragMoveObject(this.dragObject,this.type);
if(this.constrainToContainer){
_c65.constrainTo(this.constrainingContainer);
}
return _c65;
},onSelected:function(){
for(var i=0;i<this.dragObjects.length;i++){
dojo.dnd.dragManager.selectedSources.push(new dojo.dnd.HtmlDragMoveSource(this.dragObjects[i]));
}
}});
dojo.declare("dojo.dnd.HtmlDragMoveObject",dojo.dnd.HtmlDragObject,{onDragEnd:function(e){
dojo.event.connect(this.domNode,"onclick",this,"squelchOnClick");
},onDragStart:function(e){
dojo.html.clearSelection();
this.dragClone=this.domNode;
this.scrollOffset=dojo.html.getScroll().offset;
this.dragStartPosition=dojo.html.abs(this.domNode,true);
this.dragOffset={y:this.dragStartPosition.y-e.pageY,x:this.dragStartPosition.x-e.pageX};
this.containingBlockPosition=this.domNode.offsetParent?dojo.html.abs(this.domNode.offsetParent,true):{x:0,y:0};
this.dragClone.style.position="absolute";
if(this.constrainToContainer){
this.constraints=this.getConstraints();
}
},setAbsolutePosition:function(x,y){
if(!this.disableY){
this.domNode.style.top=(y-this.containingBlockPosition.y)+"px";
}
if(!this.disableX){
this.domNode.style.left=(x-this.containingBlockPosition.x)+"px";
}
}});
dojo.provide("dojo.widget.ResizeHandle");
dojo.widget.defineWidget("dojo.widget.ResizeHandle",dojo.widget.HtmlWidget,{isSizing:false,startPoint:null,startSize:null,minSize:null,targetElmId:"",templateCssString:".dojoHtmlResizeHandle {\n	float: right;\n	position: absolute;\n	right: 2px;\n	bottom: 2px;\n	width: 13px;\n	height: 13px;\n	z-index: 20;\n	cursor: nw-resize;\n	background-image: url(grabCorner.gif);\n	line-height: 0px;\n}",templateCssPath:dojo.uri.dojoUri("src/widget/templates/ResizeHandle.css"),templateString:"<div class=\"dojoHtmlResizeHandle\"><div></div></div>",postCreate:function(){
dojo.event.connect(this.domNode,"onmousedown",this,"beginSizing");
},beginSizing:function(e){
if(this.isSizing){
return false;
}
this.targetWidget=dojo.widget.byId(this.targetElmId);
this.targetDomNode=this.targetWidget?this.targetWidget.domNode:dojo.byId(this.targetElmId);
if(!this.targetDomNode){
return;
}
this.isSizing=true;
this.startPoint={"x":e.clientX,"y":e.clientY};
var mb=dojo.html.getMarginBox(this.targetDomNode);
this.startSize={"w":mb.width,"h":mb.height};
dojo.event.kwConnect({srcObj:dojo.body(),srcFunc:"onmousemove",targetObj:this,targetFunc:"changeSizing",rate:25});
dojo.event.connect(dojo.body(),"onmouseup",this,"endSizing");
e.preventDefault();
},changeSizing:function(e){
try{
if(!e.clientX||!e.clientY){
return;
}
}
catch(e){
return;
}
var dx=this.startPoint.x-e.clientX;
var dy=this.startPoint.y-e.clientY;
var newW=this.startSize.w-dx;
var newH=this.startSize.h-dy;
if(this.minSize){
var mb=dojo.html.getMarginBox(this.targetDomNode);
if(newW<this.minSize.w){
newW=mb.width;
}
if(newH<this.minSize.h){
newH=mb.height;
}
}
if(this.targetWidget){
this.targetWidget.resizeTo(newW,newH);
}else{
dojo.html.setMarginBox(this.targetDomNode,{width:newW,height:newH});
}
e.preventDefault();
},endSizing:function(e){
dojo.event.disconnect(dojo.body(),"onmousemove",this,"changeSizing");
dojo.event.disconnect(dojo.body(),"onmouseup",this,"endSizing");
this.isSizing=false;
}});
dojo.provide("dojo.widget.FloatingPane");
dojo.declare("dojo.widget.FloatingPaneBase",null,{title:"",iconSrc:"",hasShadow:false,constrainToContainer:false,taskBarId:"",resizable:true,titleBarDisplay:"fancy",windowState:"normal",displayCloseAction:false,displayMinimizeAction:false,displayMaximizeAction:false,maxTaskBarConnectAttempts:5,taskBarConnectAttempts:0,templateString:"<div id=\"${this.widgetId}\" dojoAttachEvent=\"onMouseDown\" class=\"dojoFloatingPane\">\n	<div dojoAttachPoint=\"titleBar\" class=\"dojoFloatingPaneTitleBar\"  style=\"display:none\">\n	  	<img dojoAttachPoint=\"titleBarIcon\"  class=\"dojoFloatingPaneTitleBarIcon\">\n		<div dojoAttachPoint=\"closeAction\" dojoAttachEvent=\"onClick:closeWindow\"\n   	  		class=\"dojoFloatingPaneCloseIcon\"></div>\n		<div dojoAttachPoint=\"restoreAction\" dojoAttachEvent=\"onClick:restoreWindow\"\n   	  		class=\"dojoFloatingPaneRestoreIcon\"></div>\n		<div dojoAttachPoint=\"maximizeAction\" dojoAttachEvent=\"onClick:maximizeWindow\"\n   	  		class=\"dojoFloatingPaneMaximizeIcon\"></div>\n		<div dojoAttachPoint=\"minimizeAction\" dojoAttachEvent=\"onClick:minimizeWindow\"\n   	  		class=\"dojoFloatingPaneMinimizeIcon\"></div>\n	  	<div dojoAttachPoint=\"titleBarText\" class=\"dojoFloatingPaneTitleText\">${this.title}</div>\n	</div>\n\n	<div id=\"${this.widgetId}_container\" dojoAttachPoint=\"containerNode\" class=\"dojoFloatingPaneClient\"></div>\n\n	<div dojoAttachPoint=\"resizeBar\" class=\"dojoFloatingPaneResizebar\" style=\"display:none\"></div>\n</div>",templateCssString:"\n/********** Outer Window ***************/\n\n.dojoFloatingPane {\n	/* essential css */\n	position: absolute;\n	overflow: visible;		/* so drop shadow is displayed */\n	z-index: 10;\n\n	/* styling css */\n	border: 1px solid;\n	border-color: ThreeDHighlight ThreeDShadow ThreeDShadow ThreeDHighlight;\n	background-color: ThreeDFace;\n}\n\n\n/********** Title Bar ****************/\n\n.dojoFloatingPaneTitleBar {\n	vertical-align: top;\n	margin: 2px 2px 2px 2px;\n	z-index: 10;\n	background-color: #7596c6;\n	cursor: default;\n	overflow: hidden;\n	border-color: ThreeDHighlight ThreeDShadow ThreeDShadow ThreeDHighlight;\n	vertical-align: middle;\n}\n\n.dojoFloatingPaneTitleText {\n	float: left;\n	padding: 2px 4px 2px 2px;\n	white-space: nowrap;\n	color: CaptionText;\n	font: small-caption;\n}\n\n.dojoTitleBarIcon {\n	float: left;\n	height: 22px;\n	width: 22px;\n	vertical-align: middle;\n	margin-right: 5px;\n	margin-left: 5px;\n}\n\n.dojoFloatingPaneActions{\n	float: right;\n	position: absolute;\n	right: 2px;\n	top: 2px;\n	vertical-align: middle;\n}\n\n\n.dojoFloatingPaneActionItem {\n	vertical-align: middle;\n	margin-right: 1px;\n	height: 22px;\n	width: 22px;\n}\n\n\n.dojoFloatingPaneTitleBarIcon {\n	/* essential css */\n	float: left;\n\n	/* styling css */\n	margin-left: 2px;\n	margin-right: 4px;\n	height: 22px;\n}\n\n/* minimize/maximize icons are specified by CSS only */\n.dojoFloatingPaneMinimizeIcon,\n.dojoFloatingPaneMaximizeIcon,\n.dojoFloatingPaneRestoreIcon,\n.dojoFloatingPaneCloseIcon {\n	vertical-align: middle;\n	height: 22px;\n	width: 22px;\n	float: right;\n}\n.dojoFloatingPaneMinimizeIcon {\n	background-image: url(images/floatingPaneMinimize.gif);\n}\n.dojoFloatingPaneMaximizeIcon {\n	background-image: url(images/floatingPaneMaximize.gif);\n}\n.dojoFloatingPaneRestoreIcon {\n	background-image: url(images/floatingPaneRestore.gif);\n}\n.dojoFloatingPaneCloseIcon {\n	background-image: url(images/floatingPaneClose.gif);\n}\n\n/* bar at bottom of window that holds resize handle */\n.dojoFloatingPaneResizebar {\n	z-index: 10;\n	height: 13px;\n	background-color: ThreeDFace;\n}\n\n/************* Client Area ***************/\n\n.dojoFloatingPaneClient {\n	position: relative;\n	z-index: 10;\n	border: 1px solid;\n	border-color: ThreeDShadow ThreeDHighlight ThreeDHighlight ThreeDShadow;\n	margin: 2px;\n	background-color: ThreeDFace;\n	padding: 8px;\n	font-family: Verdana, Helvetica, Garamond, sans-serif;\n	font-size: 12px;\n	overflow: auto;\n}\n\n",templateCssPath:dojo.uri.dojoUri("src/widget/templates/FloatingPane.css"),drag:null,fillInFloatingPaneTemplate:function(args,frag){
var _c76=this.getFragNodeRef(frag);
dojo.html.copyStyle(this.domNode,_c76);
dojo.body().appendChild(this.domNode);
if(!this.isShowing()){
this.windowState="minimized";
}
if(this.iconSrc==""){
dojo.html.removeNode(this.titleBarIcon);
}else{
this.titleBarIcon.src=this.iconSrc.toString();
}
if(this.titleBarDisplay!="none"){
this.titleBar.style.display="";
dojo.html.disableSelection(this.titleBar);
this.titleBarIcon.style.display=(this.iconSrc==""?"none":"");
this.minimizeAction.style.display=(this.displayMinimizeAction?"":"none");
this.maximizeAction.style.display=(this.displayMaximizeAction&&this.windowState!="maximized"?"":"none");
this.restoreAction.style.display=(this.displayMaximizeAction&&this.windowState=="maximized"?"":"none");
this.closeAction.style.display=(this.displayCloseAction?"":"none");
this.drag=new dojo.dnd.HtmlDragMoveSource(this.domNode);
if(this.constrainToContainer){
this.drag.constrainTo();
}
this.drag.setDragHandle(this.titleBar);
var self=this;
dojo.event.topic.subscribe("dragMove",function(info){
if(info.source.domNode==self.domNode){
dojo.event.topic.publish("floatingPaneMove",{source:self});
}
});
}
if(this.resizable){
this.resizeBar.style.display="";
this.resizeHandle=dojo.widget.createWidget("ResizeHandle",{targetElmId:this.widgetId,id:this.widgetId+"_resize"});
this.resizeBar.appendChild(this.resizeHandle.domNode);
}
if(this.hasShadow){
this.shadow=new dojo.lfx.shadow(this.domNode);
}
this.bgIframe=new dojo.html.BackgroundIframe(this.domNode);
if(this.taskBarId){
this.taskBarSetup();
}
dojo.body().removeChild(this.domNode);
},postCreate:function(){
if(dojo.hostenv.post_load_){
this.setInitialWindowState();
}else{
dojo.addOnLoad(this,"setInitialWindowState");
}
},maximizeWindow:function(evt){
var mb=dojo.html.getMarginBox(this.domNode);
this.previous={width:mb.width||this.width,height:mb.height||this.height,left:this.domNode.style.left,top:this.domNode.style.top,bottom:this.domNode.style.bottom,right:this.domNode.style.right};
if(this.domNode.parentNode.style.overflow.toLowerCase()!="hidden"){
this.parentPrevious={overflow:this.domNode.parentNode.style.overflow};
dojo.debug(this.domNode.parentNode.style.overflow);
this.domNode.parentNode.style.overflow="hidden";
}
this.domNode.style.left=dojo.html.getPixelValue(this.domNode.parentNode,"padding-left",true)+"px";
this.domNode.style.top=dojo.html.getPixelValue(this.domNode.parentNode,"padding-top",true)+"px";
if((this.domNode.parentNode.nodeName.toLowerCase()=="body")){
var _c7b=dojo.html.getViewport();
var _c7c=dojo.html.getPadding(dojo.body());
this.resizeTo(_c7b.width-_c7c.width,_c7b.height-_c7c.height);
}else{
var _c7d=dojo.html.getContentBox(this.domNode.parentNode);
this.resizeTo(_c7d.width,_c7d.height);
}
this.maximizeAction.style.display="none";
this.restoreAction.style.display="";
if(this.resizeHandle){
this.resizeHandle.domNode.style.display="none";
}
this.drag.setDragHandle(null);
this.windowState="maximized";
},minimizeWindow:function(evt){
this.hide();
for(var attr in this.parentPrevious){
this.domNode.parentNode.style[attr]=this.parentPrevious[attr];
}
this.lastWindowState=this.windowState;
this.windowState="minimized";
},restoreWindow:function(evt){
if(this.windowState=="minimized"){
this.show();
if(this.lastWindowState=="maximized"){
this.domNode.parentNode.style.overflow="hidden";
this.windowState="maximized";
}else{
this.windowState="normal";
}
}else{
if(this.windowState=="maximized"){
for(var attr in this.previous){
this.domNode.style[attr]=this.previous[attr];
}
for(var attr in this.parentPrevious){
this.domNode.parentNode.style[attr]=this.parentPrevious[attr];
}
this.resizeTo(this.previous.width,this.previous.height);
this.previous=null;
this.parentPrevious=null;
this.restoreAction.style.display="none";
this.maximizeAction.style.display=this.displayMaximizeAction?"":"none";
if(this.resizeHandle){
this.resizeHandle.domNode.style.display="";
}
this.drag.setDragHandle(this.titleBar);
this.windowState="normal";
}else{
}
}
},toggleDisplay:function(){
if(this.windowState=="minimized"){
this.restoreWindow();
}else{
this.minimizeWindow();
}
},closeWindow:function(evt){
dojo.html.removeNode(this.domNode);
this.destroy();
},onMouseDown:function(evt){
this.bringToTop();
},bringToTop:function(){
var _c84=dojo.widget.manager.getWidgetsByType(this.widgetType);
var _c85=[];
for(var x=0;x<_c84.length;x++){
if(this.widgetId!=_c84[x].widgetId){
_c85.push(_c84[x]);
}
}
_c85.sort(function(a,b){
return a.domNode.style.zIndex-b.domNode.style.zIndex;
});
_c85.push(this);
var _c89=100;
for(x=0;x<_c85.length;x++){
_c85[x].domNode.style.zIndex=_c89+x*2;
}
},setInitialWindowState:function(){
if(this.isShowing()){
this.width=-1;
var mb=dojo.html.getMarginBox(this.domNode);
this.resizeTo(mb.width,mb.height);
}
if(this.windowState=="maximized"){
this.maximizeWindow();
this.show();
return;
}
if(this.windowState=="normal"){
this.show();
return;
}
if(this.windowState=="minimized"){
this.hide();
return;
}
this.windowState="minimized";
},taskBarSetup:function(){
var _c8b=dojo.widget.getWidgetById(this.taskBarId);
if(!_c8b){
if(this.taskBarConnectAttempts<this.maxTaskBarConnectAttempts){
dojo.lang.setTimeout(this,this.taskBarSetup,50);
this.taskBarConnectAttempts++;
}else{
dojo.debug("Unable to connect to the taskBar");
}
return;
}
_c8b.addChild(this);
},showFloatingPane:function(){
this.bringToTop();
},onFloatingPaneShow:function(){
var mb=dojo.html.getMarginBox(this.domNode);
this.resizeTo(mb.width,mb.height);
},resizeTo:function(w,h){
dojo.html.setMarginBox(this.domNode,{width:w,height:h});
dojo.widget.html.layout(this.domNode,[{domNode:this.titleBar,layoutAlign:"top"},{domNode:this.resizeBar,layoutAlign:"bottom"},{domNode:this.containerNode,layoutAlign:"client"}]);
dojo.widget.html.layout(this.containerNode,this.children,"top-bottom");
this.bgIframe.onResized();
if(this.shadow){
this.shadow.size(w,h);
}
this.onResized();
},checkSize:function(){
}});
dojo.widget.defineWidget("dojo.widget.FloatingPane",[dojo.widget.ContentPane,dojo.widget.FloatingPaneBase],{fillInTemplate:function(args,frag){
this.fillInFloatingPaneTemplate(args,frag);
dojo.widget.FloatingPane.superclass.fillInTemplate.call(this,args,frag);
},postCreate:function(){
dojo.widget.FloatingPaneBase.prototype.postCreate.apply(this,arguments);
dojo.widget.FloatingPane.superclass.postCreate.apply(this,arguments);
},show:function(){
dojo.widget.FloatingPane.superclass.show.apply(this,arguments);
this.showFloatingPane();
},onShow:function(){
dojo.widget.FloatingPane.superclass.onShow.call(this);
this.onFloatingPaneShow();
}});
dojo.widget.defineWidget("dojo.widget.ModalFloatingPane",[dojo.widget.FloatingPane,dojo.widget.ModalDialogBase],{windowState:"minimized",displayCloseAction:true,postCreate:function(){
dojo.widget.ModalDialogBase.prototype.postCreate.call(this);
dojo.widget.ModalFloatingPane.superclass.postCreate.call(this);
},show:function(){
dojo.widget.ModalFloatingPane.superclass.show.apply(this,arguments);
this.showModalDialog();
this.placeModalDialog();
this.shared.bg.style.zIndex=this.domNode.style.zIndex-1;
},hide:function(){
this.hideModalDialog();
dojo.widget.ModalFloatingPane.superclass.hide.apply(this,arguments);
},closeWindow:function(){
this.hide();
dojo.widget.ModalFloatingPane.superclass.closeWindow.apply(this,arguments);
}});
dojo.provide("dojo.collections.Collections");
dojo.collections={Collections:true};
dojo.collections.DictionaryEntry=function(k,v){
this.key=k;
this.value=v;
this.valueOf=function(){
return this.value;
};
this.toString=function(){
return String(this.value);
};
};
dojo.collections.Iterator=function(arr){
var a=arr;
var _c95=0;
this.element=a[_c95]||null;
this.atEnd=function(){
return (_c95>=a.length);
};
this.get=function(){
if(this.atEnd()){
return null;
}
this.element=a[_c95++];
return this.element;
};
this.map=function(fn,_c97){
var s=_c97||dj_global;
if(Array.map){
return Array.map(a,fn,s);
}else{
var arr=[];
for(var i=0;i<a.length;i++){
arr.push(fn.call(s,a[i]));
}
return arr;
}
};
this.reset=function(){
_c95=0;
this.element=a[_c95];
};
};
dojo.collections.DictionaryIterator=function(obj){
var a=[];
var _c9d={};
for(var p in obj){
if(!_c9d[p]){
a.push(obj[p]);
}
}
var _c9f=0;
this.element=a[_c9f]||null;
this.atEnd=function(){
return (_c9f>=a.length);
};
this.get=function(){
if(this.atEnd()){
return null;
}
this.element=a[_c9f++];
return this.element;
};
this.map=function(fn,_ca1){
var s=_ca1||dj_global;
if(Array.map){
return Array.map(a,fn,s);
}else{
var arr=[];
for(var i=0;i<a.length;i++){
arr.push(fn.call(s,a[i]));
}
return arr;
}
};
this.reset=function(){
_c9f=0;
this.element=a[_c9f];
};
};
dojo.provide("dojo.collections.Stack");
dojo.collections.Stack=function(arr){
var q=[];
if(arr){
q=q.concat(arr);
}
this.count=q.length;
this.clear=function(){
q=[];
this.count=q.length;
};
this.clone=function(){
return new dojo.collections.Stack(q);
};
this.contains=function(o){
for(var i=0;i<q.length;i++){
if(q[i]==o){
return true;
}
}
return false;
};
this.copyTo=function(arr,i){
arr.splice(i,0,q);
};
this.forEach=function(fn,_cac){
var s=_cac||dj_global;
if(Array.forEach){
Array.forEach(q,fn,s);
}else{
for(var i=0;i<q.length;i++){
fn.call(s,q[i],i,q);
}
}
};
this.getIterator=function(){
return new dojo.collections.Iterator(q);
};
this.peek=function(){
return q[(q.length-1)];
};
this.pop=function(){
var r=q.pop();
this.count=q.length;
return r;
};
this.push=function(o){
this.count=q.push(o);
};
this.toArray=function(){
return [].concat(q);
};
};

